using System;
using System.Windows.Forms;

namespace Minotti
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new w_ver_medicamentos()); // Cambiá esta línea si querés iniciar con otra window
        }
    }
}