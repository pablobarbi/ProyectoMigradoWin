namespace Minotti
{
    partial class w_carga_reperto_parcial_multiple_bak
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing) { if (disposing && (components != null)) components.Dispose(); base.Dispose(disposing); }
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Name = "w_carga_reperto_parcial_multiple_bak";
            this.Text = "w_carga_reperto_parcial_multiple_bak";
            this.Width = 900;
            this.Height = 600;
        }
    }
}