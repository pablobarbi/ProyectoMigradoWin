using System;
using System.Windows.Forms;
namespace Minotti
{
    public partial class w_reperto_anterior_multiple_lista : Form
    {
        public w_reperto_anterior_multiple_lista() { InitializeComponent(); }
    }
}