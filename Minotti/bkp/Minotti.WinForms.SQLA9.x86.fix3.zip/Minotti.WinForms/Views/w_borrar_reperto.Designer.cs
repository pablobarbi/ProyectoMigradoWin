namespace Minotti
{
    partial class w_borrar_reperto
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing) { if (disposing && (components != null)) components.Dispose(); base.Dispose(disposing); }
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Name = "w_borrar_reperto";
            this.Text = "w_borrar_reperto";
            this.Width = 900;
            this.Height = 600;
        }
    }
}