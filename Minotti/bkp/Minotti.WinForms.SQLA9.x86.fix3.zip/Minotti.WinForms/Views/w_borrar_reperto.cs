using System;
using System.Windows.Forms;
namespace Minotti
{
    public partial class w_borrar_reperto : Form
    {
        public w_borrar_reperto() { InitializeComponent(); }
    }
}