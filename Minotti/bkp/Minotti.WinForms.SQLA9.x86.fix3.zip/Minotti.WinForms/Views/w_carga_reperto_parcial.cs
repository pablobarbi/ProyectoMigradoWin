using System;
using System.Windows.Forms;
namespace Minotti
{
    public partial class w_carga_reperto_parcial : Form
    {
        public w_carga_reperto_parcial() { InitializeComponent(); }
    }
}