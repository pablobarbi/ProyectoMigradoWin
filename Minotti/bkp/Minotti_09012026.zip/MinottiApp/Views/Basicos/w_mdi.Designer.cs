using System.Windows.Forms;

namespace Minotti.Views.Basicos
{
    partial class w_mdi
    {
        private System.ComponentModel.IContainer components = null;

        private MenuStrip menuStrip1;

        // PB-like: los items deben existir con estos nombres
        public ToolStripMenuItem m_confirmar;
        public ToolStripMenuItem m_cancelar;
        public ToolStripMenuItem m_insertar;
        public ToolStripMenuItem m_borrar;
        public ToolStripMenuItem m_iniciarconsulta;
        public ToolStripMenuItem m_procesar;
        public ToolStripMenuItem m_preliminar;
        public ToolStripMenuItem m_imprimir;
        public ToolStripMenuItem m_salvarcomo;
        public ToolStripMenuItem m_salir;

        public ToolStripMenuItem m_primerregistro;
        public ToolStripMenuItem m_siguienteregistro;
        public ToolStripMenuItem m_anteriorregistro;
        public ToolStripMenuItem m_ultimoregistro;

        public ToolStripMenuItem m_layer;
        public ToolStripMenuItem m_mosaico;
        public ToolStripMenuItem m_casacada;
        public ToolStripMenuItem m_acercade;

        public StatusStrip statusStrip1;
        public ToolStripStatusLabel _stMicroHelp;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();

            menuStrip1 = new MenuStrip();

            var m_operaciones = new ToolStripMenuItem("&Operaciones");
            m_confirmar = new ToolStripMenuItem("&Confirmar");
            m_cancelar = new ToolStripMenuItem("Cance&lar");
            m_insertar = new ToolStripMenuItem("&Agregar");
            m_borrar = new ToolStripMenuItem("&Borrar");
            m_iniciarconsulta = new ToolStripMenuItem("&Iniciar Consulta");
            m_procesar = new ToolStripMenuItem("&Procesar");
            m_preliminar = new ToolStripMenuItem("Preliminar");
            m_imprimir = new ToolStripMenuItem("Imprimir");
            m_salvarcomo = new ToolStripMenuItem("Salvar como...");
            m_salir = new ToolStripMenuItem("&Salir");

            m_operaciones.DropDownItems.AddRange(new ToolStripItem[]
            {
                m_confirmar,
                m_cancelar,
                new ToolStripSeparator(),
                m_insertar,
                m_borrar,
                new ToolStripSeparator(),
                m_iniciarconsulta,
                m_procesar,
                new ToolStripSeparator(),
                m_preliminar,
                m_imprimir,
                m_salvarcomo,
                new ToolStripSeparator(),
                m_salir
            });

            var m_navegacion = new ToolStripMenuItem("&Navegación");
            m_primerregistro = new ToolStripMenuItem("Primer Registro");
            m_siguienteregistro = new ToolStripMenuItem("Siguiente Registro");
            m_anteriorregistro = new ToolStripMenuItem("Anterior Registro");
            m_ultimoregistro = new ToolStripMenuItem("Último Registro");

            m_navegacion.DropDownItems.AddRange(new ToolStripItem[]
            {
                m_primerregistro,
                m_siguienteregistro,
                m_anteriorregistro,
                m_ultimoregistro
            });

            var m_ventanas = new ToolStripMenuItem("&Ventanas");
            m_layer = new ToolStripMenuItem("Layer");
            m_mosaico = new ToolStripMenuItem("Mosaico");
            m_casacada = new ToolStripMenuItem("Cascada");

            m_ventanas.DropDownItems.AddRange(new ToolStripItem[]
            {
                m_layer,
                m_mosaico,
                m_casacada
            });

            var m_ayuda = new ToolStripMenuItem("&Ayuda");
            m_acercade = new ToolStripMenuItem("Acerca de...");

            m_ayuda.DropDownItems.Add(m_acercade);

            menuStrip1.Items.AddRange(new ToolStripItem[]
            {
                m_operaciones,
                m_navegacion,
                m_ventanas,
                m_ayuda
            });

            statusStrip1 = new StatusStrip();
            _stMicroHelp = new ToolStripStatusLabel();

            statusStrip1.Items.AddRange(new ToolStripItem[] {
    _stMicroHelp
});


            SuspendLayout();

            // w_mdi
            AutoScaleMode = AutoScaleMode.Font;
            IsMdiContainer = true;
            MainMenuStrip = menuStrip1;
            Controls.Add(menuStrip1);
            Name = "w_mdi";
            Text = "Minotti";


            this.statusStrip1.Dock = DockStyle.Bottom;
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new Size(this.ClientSize.Width, 22);
            this.statusStrip1.TabIndex = 1000;

            // 
            // st_microhelp
            // 
            this._stMicroHelp.Name = "st_microhelp";
            this._stMicroHelp.Text = "";

            // Agregar al form
            this.Controls.Add(this.statusStrip1);

            // vincular con la lógica
            this._stMicroHelp = this._stMicroHelp;




            ResumeLayout(false);
            PerformLayout();
        }
    }
}