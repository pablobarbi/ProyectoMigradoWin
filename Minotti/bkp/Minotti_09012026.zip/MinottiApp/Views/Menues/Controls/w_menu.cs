using Minotti.Data;
using Minotti.Structures;
using Minotti.utils;
using Minotti.Views.Basicos;
using Minotti.Views.Basicos.Models;

namespace Minotti.Views.Pbl.Views
{
    // ==========================
    // PB:
    // global type w_menu from w_sheet
    // ==========================
    public partial class w_menu : w_sheet
    {


        // ==========================
        // PB variables
        // st_nivel s_nvl[]
        // integer nivel_actual
        // DataStore dw_param
        // ==========================
        protected st_nivel[] s_nvl;     // lo uso 1-based (index 1..N)
        public int nivel_actual;
        public datastore? dw_param;

        public w_menu()
        {

           // InitializeComponent();

            // PB: string title = "Menú General de Operaciones"
            this.Text = "Menú General de Operaciones";
        }

        // ==========================
        // PB: event activate; /* No permite que se active el evento cancelar */
        // ==========================
        protected override void OnActivated(EventArgs e)
        {
            // Intencionalmente vacío (PB override para bloquear cancelar)
            base.OnActivated(e);
        }

        // ==========================
        // PB: event close; destruye DataStores creados en Open
        // ==========================
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            base.OnFormClosed(e);

            try
            {
                // For iAux=1 to UpperBound(s_nvl[])
                for (int i = 1; i < s_nvl.Count(); i++)
                {
                    var dw = s_nvl[i]?.dw;
                    if (dw != null)
                    {
                        // PB: Destroy s_nvl[i].Dw
                        dw.Dispose();
                        s_nvl[i].dw = null;
                    }
                }

                if (dw_param != null)
                {
                    dw_param.Dispose();
                    dw_param = null;
                }
            }
            catch
            {
                // PB no suele reventar en close por dispose; lo ignoramos
            }
        }

        // ==========================================================
        // PB: event ue_leer_parametros()
        // ==========================================================
        // =======================
        // PB: event ue_leer_parametros
        // =======================
        protected override void ue_leer_parametros()
        {
            MessageBox.Show("ue_leer_parametros EN w_menu");
            // call super::ue_leer_parametros
            base.ue_leer_parametros();

            cat_usuario at_usuario;
            int iAux, niveles;
            string param;

            // PB: param = f_GetMenu()
            param = f_GetMenu();

            // PB: niveles = integer(wf_ProxParam(param))
            niveles = Convert.ToInt32(wf_ProxParam(param));

            // Redimensiona arreglo de niveles (PB: s_nvl[])
            s_nvl = new st_nivel[niveles];

            for (iAux = 0; iAux < niveles; iAux++)
            {
                s_nvl[iAux] = new st_nivel
                {
                    dw = new datastore(),
                    titulo = wf_ProxParam(param),
                    activo = 1
                };

                // PB: Dw.DataObject = wf_ProxParam(param)
                s_nvl[iAux].dw.DataObject = wf_ProxParam(param);

                // PB: Dw.SetTransObject(SQLCA)
                s_nvl[iAux].dw.SetTransObject(SQLCA.Instance);
            }

            // === DataStore de parámetros ===
            dw_param = new datastore
            {
                DataObject = wf_ProxParam(param)
            };
            dw_param.SetTransObject(SQLCA.Instance);

            // === Retrieve según usuario ===
            at_usuario = guo_app.uof_GetUsuario();

            // PB: s_nvl[1].Dw.Retrieve(at_usuario.usuario)
            s_nvl[0].dw.Retrieve(at_usuario.Usuario);

            // PB: FOR iAux = 2 TO UpperBound(s_nvl[])
            for (iAux = 1; iAux < s_nvl.Count(); iAux++)
            {
                s_nvl[iAux].dw.Retrieve(at_usuario.Perfil);
            }

            // PB: dw_param.Retrieve(at_usuario.perfil)
            dw_param.Retrieve(at_usuario.Perfil);
        }

        

        // ==========================================================
        // PB: event ue_ajustar_posicion()
        // ==========================================================
        public virtual void ue_ajustar_posicion()
        {
            base.ue_ajustar_posicion();

            // This.X=1; This.Y=1
            this.Left = 1;
            this.Top = 1;

            // guo_app.uof_GetMdi().wf_GetAreaTrabajo(ancho_mdi, largo_mdi)
            int ancho_mdi = 0;
            int largo_mdi = 0;

            var mdi = Globales.guo_app?.uof_getmdi();
            if (mdi != null)
            {
                // IMPORTANT: tu w_mdi tiene que implementar esto (out width/height)
                mdi.wf_GetAreaTrabajo(out ancho_mdi, out largo_mdi);
            }
            else
            {
                // fallback razonable
                var wa = Screen.FromControl(this).WorkingArea;
                ancho_mdi = wa.Width;
                largo_mdi = wa.Height;
            }

            // This.Width = ancho_mdi; This.Height = largo_mdi
            this.Width = ancho_mdi;
            this.Height = largo_mdi;
        }

        // ==========================================================
        // PB: event ue_ejecutar(string modulo, string operacion)
        // ==========================================================
        public virtual void ue_ejecutar(string Modulo, string Operacion)
        {
            // cat_operacion at_op
            cat_operacion at_op = new cat_operacion();

            // Lee los datos de la operación que va a ejecutar
            at_op.Modulo = Modulo;
            at_op.Operacion = Operacion;

            if (f_cargar_datos_operacion(at_op) != 1)
            {
                MessageBoxPB.MessageBox(
                    "Atención",
                    "No se encontró la operación.\r\nMódulo: " + Modulo + "\r\nOperación: " + Operacion,
                    MessageBoxIcon.Information,
                    MessageBoxButtons.OK);
                return;
            }

            if (dw_param == null)
            {
                MessageBoxPB.MessageBox("Atención", "No se cargaron los parámetros del menú (dw_param).",
                    MessageBoxIcon.Information, MessageBoxButtons.OK);
                return;
            }

            // dw_param.SetFilter("operacion = '" + operacion + "'")
            dw_param.SetFilter("operacion = '" + Operacion.Replace("'", "''") + "'");
            dw_param.Filter();

            if (dw_param.RowCount() < 1)
            {
                MessageBoxPB.MessageBox(
                    "Atención",
                    "No se encontraron los parámetros de la operación.\r\nOperación: " + Operacion,
                    MessageBoxIcon.Information,
                    MessageBoxButtons.OK);
                return;
            }

            // FOR iAux = 1 TO dw_param.RowCount()
            int rc = (int)dw_param.RowCount();
            for (int iAux = 1; iAux <= rc; iAux++)
            {
                // at_op.at_nvl[iAux]... (PB arrays 1-based)
                at_op.EnsureNivelIndex(iAux);

                at_op.at_nvl[iAux].Objeto = dw_param.GetItemString(iAux, "objeto");
                at_op.at_nvl[iAux].Titulo = dw_param.GetItemString(iAux, "titulo");
                at_op.at_nvl[iAux].Parametros = dw_param.GetItemString(iAux, "parametros");
                at_op.at_nvl[iAux].Cierra = dw_param.GetItemString(iAux, "cierra");
            }

            at_op.Orden = 1;
            at_op.w_anterior = this;

            // ParentWindow().SetMicroHelp(at_op.Descripcion)
            try
            {
                var parent = this.MdiParent ?? this.Owner;
                if (parent is w_mdi mdi)
                {
                    mdi.SetMicroHelp(at_op.Descripcion);
                }
                else
                {
                    // si no es w_mdi, ignoramos (PB no rompe)
                }
            }
            catch { }

            wf_abrir_detalle(at_op);
        }

        // ==========================================================
        // PB: wf_abrir_detalle(at_op)
        // ==========================================================
        public virtual void wf_abrir_detalle(cat_operacion at_op)
        {
            // TODO: Acá tu lógica real abre el sheet/detalle.
            // En PB suele ser: OpenSheetWithParm(... at_op.at_sheet[1].objeto ...)
            // No lo invento.
        }

        // ==========================================================
        // PB helpers: f_GetMenu / wf_ProxParam / f_cargar_datos_operacion
        // ==========================================================
        protected virtual string f_GetMenu()
        {
            // TODO: en PB devuelve un string con tokens:
            // [niveles]|[titulo1]|[dw1]|[titulo2]|[dw2]|...|[dw_param]
            // Pasame el PB de f_GetMenu y wf_ProxParam si querés 1:1 exacto.
            return "0";
        }

        protected virtual string? wf_ProxParam(string param)
        {
            // TODO: parser exacto de parámetros PB.
            // Implementación simple: separador '|'
            if (param == null) return null;

            int idx = param.IndexOf('|');
            if (idx < 0)
            {
                string last = param;
                param = string.Empty;
                return last;
            }

            string token = param.Substring(0, idx);
            param = param.Substring(idx + 1);
            return token;
        }

        protected virtual int f_cargar_datos_operacion(cat_operacion at_op)
        {
            // TODO: implementar usando tu SQLCA y tabla real de operaciones.
            // PB: f_cargar_datos_operacion(at_op)
            return 1;
        }

        // ==========================================================
        // helper 1-based list
        // ==========================================================
        private static void EnsureIndex<T>(List<T> list, int index) where T : new()
        {
            while (list.Count <= index)
                list.Add(new T());
        }
    }

 
}
