using Minotti.Views.Basicos;

namespace Minotti.Views.Menues.Controls
{
    public partial class w_menu : w_sheet
    {
        /// <summary>Required designer variable.</summary>
        private System.ComponentModel.IContainer components = null;

        

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // w_menu
            // 
            this.Name = "w_menu";
            this.Text = "Men�";
            this.ResumeLayout(false);
        }

        #endregion
    }
}
