using Minotti.utils;
using Minotti.Views.Basicos.Models;

namespace Minotti.Views.Menues.Controls
{
    public partial class w_menu_arbol : w_menu
    {

        // =======================
        // PB: st_nivel s_nvl[]
        // =======================
        private readonly List<cat_nivel> s_nvl = new();

        // PB: integer nivel_actual
        private int nivel_actual = 1;

        // PB: DataStore dw_param
        private datastore dw_param = null!;


        public w_menu_arbol()
        {
            InitializeComponent();            
            this.Load += w_menu_arbol_Load;
        }

        public void w_menu_arbol_Load(object? sender, EventArgs e)
        {
            wf_cargar_menu_desde_db();
        }

        // =====================================================
        // PB: wf_cargar_menu / wf_armar_arbol (desde DB)
        // =====================================================
        private void wf_cargar_menu_desde_db()
        {
            tv_1.BeginUpdate();
            tv_1.Nodes.Clear();

            if (s_nvl.Count == 0)
                return;

            // === Nivel 1 ===
            var dwNivel1 = s_nvl[0].Dw;

            for (int i = 1; i <= dwNivel1.RowCount(); i++)
            {
                var nodo = CrearNodo(dwNivel1, i);
                tv_1.Nodes.Add(nodo);

                // === Cargar hijos ===
                CargarHijos(nodo, 2);
            }

            tv_1.ExpandAll();
            tv_1.EndUpdate();
        }

        private void CargarHijos(TreeNode padre, int nivel)
        {
            if (nivel > s_nvl.Count)
                return;

            var dw = s_nvl[nivel - 1].Dw;
            int idPadre = ((MenuNodeTag)padre.Tag).IdMenu;

            for (int i = 1; i <= dw.RowCount(); i++)
            {
                int idMenuPadre = dw.GetItemNumberInt(i, "id_menu_padre");

                if (idMenuPadre != idPadre)
                    continue;

                var nodo = CrearNodo(dw, i);
                padre.Nodes.Add(nodo);

                CargarHijos(nodo, nivel + 1);
            }
        }

        private TreeNode CrearNodo(datastore dw, int row)
        {
            var nodo = new TreeNode
            {
                Text = dw.GetItemString(row, "descripcion"),
                Tag = new MenuNodeTag
                {
                    IdMenu = dw.GetItemNumberInt(row, "id_menu"),
                    WindowName = dw.GetItemString(row, "window_name")
                }
            };

            return nodo;
        }

        internal class MenuNodeTag
        {
            public int IdMenu { get; set; }
            public string WindowName { get; set; } = "";
        }


        // =====================================================
        // PB: evento DoubleClicked()
        // =====================================================
        private void Tv_1_NodeMouseDoubleClick(object? sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Node?.Tag is not MenuNodeTag tag)
                return;

            if (string.IsNullOrWhiteSpace(tag.WindowName))
                return;

          // ue_ejecutar(tag.WindowName, tag.WindowName);

        }
    }
}
