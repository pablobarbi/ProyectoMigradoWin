using System;
using System.Windows.Forms;
namespace Minotti
{
    public partial class w_carga_reperto_parcial_multiple_bak : Form
    {
        public w_carga_reperto_parcial_multiple_bak() { InitializeComponent(); }
    }
}