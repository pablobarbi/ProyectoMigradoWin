namespace Minotti
{
    partial class w_reperto_anterior_multiple_lista
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing) { if (disposing && (components != null)) components.Dispose(); base.Dispose(disposing); }
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.Name = "w_reperto_anterior_multiple_lista";
            this.Text = "w_reperto_anterior_multiple_lista";
            this.Width = 900;
            this.Height = 600;
        }
    }
}