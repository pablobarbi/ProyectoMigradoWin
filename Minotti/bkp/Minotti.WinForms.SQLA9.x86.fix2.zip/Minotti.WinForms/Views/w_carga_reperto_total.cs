using System;
using System.Windows.Forms;
namespace Minotti
{
    public partial class w_carga_reperto_total : Form
    {
        public w_carga_reperto_total() { InitializeComponent(); }
    }
}