using System;
using System.Windows.Forms;
namespace Minotti
{
    public partial class w_borra_reperto_parc : Form
    {
        public w_borra_reperto_parc() { InitializeComponent(); }
    }
}