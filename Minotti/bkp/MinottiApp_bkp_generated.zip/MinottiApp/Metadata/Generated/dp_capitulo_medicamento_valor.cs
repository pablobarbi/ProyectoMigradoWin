﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class dp_capitulo_medicamento_valor : IDataWindowMetadata
    {
        public string DataObject => "dp_capitulo_medicamento_valor";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "capitulo",
                DbName = "capitulacion_med.capitulo",
                Tipo = "decimal(0)",
                Titulo = "Capítulo",
                EsClave = false,
                EsRequerido = false,
                TabOrder = 10,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "medicamento",
                DbName = "capitulacion_med.medicamento",
                Tipo = "char(10)",
                Titulo = "Medicamento",
                EsClave = false,
                EsRequerido = false,
                TabOrder = 20,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "valor",
                DbName = "capitulacion_med.valor",
                Tipo = "long",
                Titulo = "Valor",
                EsClave = false,
                EsRequerido = false,
                TabOrder = 30,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = new[] { "1", "1/2", "2/3", "3" }
            }
        };

        // ⇩ El SRD no define nada adicional ⇩
        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;

        public string Sql => @"
SELECT capitulacion_med.capitulo,
       capitulacion_med.medicamento,
       capitulacion_med.valor
  FROM capitulacion_med
";
    }
}
