﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class d_operaciones_x_perfil_sub_modulo : IDataWindowMetadata
    {
        public string DataObject => "d_operaciones_x_perfil_sub_modulo";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "operacion",
                DbName = "acc_operaciones.operacion",
                Tipo = "char(5)"
            },
            new DataWindowColumn
            {
                Nombre = "nombre",
                DbName = "acc_operaciones.nombre",
                Tipo = "char(40)"
            },
            new DataWindowColumn
            {
                Nombre = "submodulo",
                DbName = "submodulo",
                Tipo = "char(15)"
            },
            new DataWindowColumn
            {
                Nombre = "modulo",
                DbName = "acc_operaciones_x_modulo.modulo",
                Tipo = "char(5)"
            }
        };

        public string Sql => @"
SELECT DISTINCT dba.acc_operaciones.operacion, 
                dba.acc_operaciones.nombre, 
                dba.acc_operaciones_x_modulo.modulo + '*****' + dba.acc_operaciones_x_modulo.submodulo submodulo,
                dba.acc_operaciones_x_modulo.modulo 
           FROM dba.acc_modulos_x_perfil, 
                dba.acc_operaciones_x_modulo, 
                dba.acc_operaciones 
          WHERE dba.acc_operaciones_x_modulo.operacion = dba.acc_operaciones.operacion 
            AND dba.acc_operaciones_x_modulo.modulo = dba.acc_modulos_x_perfil.modulo 
            AND dba.acc_modulos_x_perfil.perfil = :perfil
";

        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
