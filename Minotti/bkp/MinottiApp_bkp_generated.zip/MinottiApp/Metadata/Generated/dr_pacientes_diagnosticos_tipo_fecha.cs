﻿using System.Collections.Generic;
using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class dr_pacientes_diagnosticos_tipo_fecha : IDataWindowMetadata
    {
        public string DataObject => "dr_pacientes_diagnosticos_tipo_fecha";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "paciente",
                DbName = "diagnosticos.paciente",
                Tipo = "long",
                Titulo = "Paciente",
                EsClave = true,
                EsClavePrimaria = true
            },
            new DataWindowColumn
            {
                Nombre = "diagnostico",
                DbName = "diagnosticos.diagnostico",
                Tipo = "long",
                Titulo = "Diagnóstico",
                EsClave = true,
                EsClavePrimaria = true
            },
            new DataWindowColumn
            {
                Nombre = "fecha_visita",
                DbName = "diagnosticos.fecha_visita",
                Tipo = "date",
                Titulo = "Fecha Visita"
            },
            new DataWindowColumn
            {
                Nombre = "curado",
                DbName = "diagnosticos.curado",
                Tipo = "char(1)",
                Titulo = "Curado",
                Valores = new[] { "S", "N" }
            }
        };

        public string[] Estilos => System.Array.Empty<string>();

        public string[] SeleccionFila => System.Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => true;

        public string Sql => @"
SELECT diagnosticos.paciente,
       diagnosticos.diagnostico,
       diagnosticos.fecha_visita,
       diagnosticos.curado
  FROM diagnosticos
 WHERE (   (:tipo_diagnostico = 'N') AND (diagnosticos.diag_nosologico like :diagnostico)
        OR (:tipo_diagnostico = 'M') AND (diagnosticos.diag_medicamentoso like :diagnostico)
        OR (:tipo_diagnostico = 'I') AND (diagnosticos.diag_miasmatico like :diagnostico)
        OR (:tipo_diagnostico = 'O') AND (diagnosticos.diag_otro like :diagnostico) )
   AND diagnosticos.fecha_visita >= YMD(
         SUBSTR(:fecha_desde, 7, 4),
         SUBSTR(:fecha_desde, 4, 2),
         SUBSTR(:fecha_desde, 1, 2)
       )
   AND diagnosticos.fecha_visita <= YMD(
         SUBSTR(:fecha_hasta, 7, 4),
         SUBSTR(:fecha_hasta, 4, 2),
         SUBSTR(:fecha_hasta, 1, 2)
       )
";
    }
}
