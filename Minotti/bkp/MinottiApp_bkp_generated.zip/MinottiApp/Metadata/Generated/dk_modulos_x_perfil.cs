﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    /// <summary>
    /// Metadata para dk_modulos_x_perfil
    /// </summary>
    public class dk_modulos_x_perfil : IDataWindowMetadata
    {
        public string DataObject => "dk_modulos_x_perfil";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "perfil",
                DbName = "acc_modulos_x_perfil.perfil",
                Tipo = "char(5)",
                TabOrder = 32766
            },
            new DataWindowColumn
            {
                Nombre = "modulo",
                DbName = "acc_modulos_x_perfil.modulo",
                Tipo = "char(5)",
                TabOrder = 32766
            },
            new DataWindowColumn
            {
                Nombre = "nombre_modulo",
                DbName = "acc_modulos.nombre_modulo",
                Tipo = "char(20)",
                TabOrder = 32766
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
