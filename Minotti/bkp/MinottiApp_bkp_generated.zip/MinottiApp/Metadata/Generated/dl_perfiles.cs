﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class dl_perfiles : IDataWindowMetadata
    {
        public string DataObject => "dl_perfiles";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "perfil",
                DbName = "acc_perfiles.perfil",
                Tipo = "char(5)",
                Titulo = "Perfíl",
                EsClave = true,
                EsRequerido = false,
                ObjetoSeleccion = null,
                Operacion = null,
                NivelOperacion = null,
                TabOrder = 10,
                EsClavePrimaria = true,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "nombre",
                DbName = "acc_perfiles.nombre",
                Tipo = "char(20)",
                Titulo = "Nombre",
                EsClave = false,
                EsRequerido = false,
                ObjetoSeleccion = null,
                Operacion = null,
                NivelOperacion = null,
                TabOrder = 20,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "bitmap",
                DbName = "acc_perfiles.bitmap",
                Tipo = "char(40)",
                Titulo = string.Empty,
                EsClave = false,
                EsRequerido = false,
                ObjetoSeleccion = null,
                Operacion = null,
                NivelOperacion = null,
                TabOrder = null,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            }
        };

        // ⇩⇩⇩ Solo se completan si el SRD lo define ⇩⇩⇩
        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;

        public string Sql => @"
SELECT dba.acc_perfiles.perfil,
       dba.acc_perfiles.nombre,
       dba.acc_perfiles.bitmap
  FROM dba.acc_perfiles
 ORDER BY dba.acc_perfiles.nombre
";
    }
}
