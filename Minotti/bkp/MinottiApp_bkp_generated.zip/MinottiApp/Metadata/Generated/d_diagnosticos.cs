﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class d_diagnosticos : IDataWindowMetadata
    {
        public string DataObject => "d_diagnosticos";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "paciente",
                DbName = "diagnosticos.paciente",
                Tipo = "long",
                Titulo = "Paciente",
                EsClave = true,
                EsRequerido = true,
                ObjetoSeleccion = "dw_pacientes",
                TabOrder = 10
            },
            new DataWindowColumn
            {
                Nombre = "diagnostico",
                DbName = "diagnosticos.diagnostico",
                Tipo = "long",
                Titulo = "Nro. de diagnóstico",
                EsClave = true,
                EsRequerido = false,
                TabOrder = 20
            },
            new DataWindowColumn
            {
                Nombre = "fecha_visita",
                DbName = "diagnosticos.fecha_visita",
                Tipo = "date",
                Titulo = "Fecha de visita",
                EsClave = false,
                EsRequerido = false,
                TabOrder = 30
            },
            new DataWindowColumn
            {
                Nombre = "diag_nosologico",
                DbName = "diagnosticos.diag_nosologico",
                Tipo = "char(50)",
                Titulo = "Nosológico",
                EsClave = false,
                EsRequerido = false,
                TabOrder = 40
            },
            new DataWindowColumn
            {
                Nombre = "diag_medicamentoso",
                DbName = "diagnosticos.diag_medicamentoso",
                Tipo = "char(50)",
                Titulo = "Medicamentoso",
                EsClave = false,
                EsRequerido = false,
                TabOrder = 50
            },
            new DataWindowColumn
            {
                Nombre = "diag_miasmatico",
                DbName = "diagnosticos.diag_miasmatico",
                Tipo = "char(50)",
                Titulo = "Miasmático",
                EsClave = false,
                EsRequerido = false,
                TabOrder = 60
            },
            new DataWindowColumn
            {
                Nombre = "diag_otro",
                DbName = "diagnosticos.diag_otro",
                Tipo = "char(50)",
                Titulo = "Otro",
                EsClave = false,
                EsRequerido = false,
                TabOrder = 70
            },
            new DataWindowColumn
            {
                Nombre = "repertorizacion",
                DbName = "diagnosticos.repertorizacion",
                Tipo = "long",
                Titulo = "Repertorizacion",
                EsClave = false,
                EsRequerido = false,
                TabOrder = 80
            },
            new DataWindowColumn
            {
                Nombre = "primera",
                DbName = "diagnosticos.primera",
                Tipo = "char(1)",
                Titulo = "Primera",
                EsClave = false,
                EsRequerido = false,
                TabOrder = 90
            },
            new DataWindowColumn
            {
                Nombre = "curado",
                DbName = "diagnosticos.curado",
                Tipo = "char(1)",
                Titulo = "Curado",
                EsClave = false,
                EsRequerido = false,
                TabOrder = 100
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;

        public string Sql => @"
SELECT diagnosticos.paciente,
       diagnosticos.diagnostico,
       diagnosticos.fecha_visita,
       diagnosticos.diag_nosologico,
       diagnosticos.diag_medicamentoso,
       diagnosticos.diag_miasmatico,
       diagnosticos.diag_otro,
       diagnosticos.repertorizacion,
       diagnosticos.primera,
       diagnosticos.curado
  FROM diagnosticos
 WHERE diagnosticos.paciente = :paciente
   AND diagnosticos.diagnostico = :diagnostico
";
    }
}
