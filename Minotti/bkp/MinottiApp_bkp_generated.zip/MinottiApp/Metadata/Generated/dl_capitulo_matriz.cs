﻿using Minotti.Metadata;

namespace MinottiApp.Metadata.Generated
{
    public class dl_capitulo_matriz : IDataWindowMetadata
    {
        public string DataObject => "dl_capitulo_matriz";

        public List<DataWindowColumn> Columns { get; } = new()
        {
            new DataWindowColumn("capitulo_nombre", "char(255)") { DbName = "capitulaciones_matriz.capitulo_nombre" },
            new DataWindowColumn("rubrica_nombre", "char(255)") { DbName = "capitulaciones_matriz.rubrica_nombre" },
            new DataWindowColumn("subrubrica_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica_nombre" },
            new DataWindowColumn("subrubrica01_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica01_nombre" },
            new DataWindowColumn("subrubrica02_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica02_nombre" },
            new DataWindowColumn("subrubrica03_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica03_nombre" },
            new DataWindowColumn("subrubrica04_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica04_nombre" },
            new DataWindowColumn("subrubrica05_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica05_nombre" },
            new DataWindowColumn("subrubrica06_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica06_nombre" },
            new DataWindowColumn("subrubrica07_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica07_nombre" },
            new DataWindowColumn("subrubrica08_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica08_nombre" },
            new DataWindowColumn("subrubrica09_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica09_nombre" },
            new DataWindowColumn("subrubrica10_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica10_nombre" }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => true;
    }
}

