﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class d_agregar_subrubricas : IDataWindowMetadata
    {
        public string DataObject => "d_agregar_subrubricas";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "nombre",
                Tipo = "char(255)",
                Titulo = "Subrubrica:",
                EsClave = false,
                EsRequerido = false,
                //Estilos = null,
                ObjetoSeleccion = null,
                Operacion = null,
                NivelOperacion = null,
                TabOrder = 10
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
