﻿using System.Collections.Generic;

namespace Minotti.Metadata.Generated
{
    public class r_header : IDataWindowMetadata
    {
        public string DataObject => "r_header";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "compute_0001",
                DbName = "compute_0001",
                Tipo = "decimal",
                EsClave = false,
                EsClavePrimaria = false,
                EsIdentity = false
            }
        };

        public string sql => @"
SELECT count(*) 
  FROM dba.acc_usuarios
";

        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
