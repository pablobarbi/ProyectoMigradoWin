﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class d_medicamentos : IDataWindowMetadata
    {
        public string DataObject => "d_medicamentos";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "medicamento",
                DbName = "medicamentos.medicamento",
                Tipo = "char(10)",
                EsClave = true,
                EsRequerido = true,
                TabOrder = 10
            },
            new DataWindowColumn
            {
                Nombre = "descripcion",
                DbName = "medicamentos.descripcion",
                Tipo = "char(50)",
                EsRequerido = true,
                TabOrder = 20
            },
            new DataWindowColumn
            {
                Nombre = "observaciones",
                DbName = "medicamentos.observaciones",
                Tipo = "char(32766)",
                EsRequerido = false,
                TabOrder = 40
            },
            new DataWindowColumn
            {
                Nombre = "imagen_asociada",
                DbName = "medicamentos.imagen_asociada",
                Tipo = "char(255)",
                EsRequerido = false,
                TabOrder = 30
            }
        };

        public string Sql => @"
SELECT medicamentos.medicamento,
       medicamentos.descripcion,
       medicamentos.observaciones,
       medicamentos.imagen_asociada
  FROM medicamentos
 WHERE medicamentos.medicamento = :medicamento
";

        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
