﻿using Minotti.Metadata;

namespace MinottiApp.Metadata.Generated
{
    public class dl_modulos : IDataWindowMetadata
    {
        public string DataObject => "dl_modulos";

        public List<DataWindowColumn> Columns { get; } = new()
        {
            new DataWindowColumn("modulo", "char(5)")
            {
                DbName = "acc_modulos.modulo",
                EsClave = true
            },
            new DataWindowColumn("nombre", "char(20)")
            {
                DbName = "acc_modulos.nombre"
            },
            new DataWindowColumn("bitmap", "char(40)")
            {
                DbName = "acc_modulos.bitmap"
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
