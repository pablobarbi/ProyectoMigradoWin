﻿using System.Collections.Generic;

namespace Minotti.Metadata.Generated
{
    public class dsto_reperto_total : IDataWindowMetadata
    {
        public string DataObject => "dsto_reperto_total";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn("reperto_total", "decimal(0)")
            {
                DbName = "reperto_total.reperto_total",
                EsClave = true
            },
            new DataWindowColumn("reperto_sintoma", "decimal(0)")
            {
                DbName = "reperto_total.reperto_sintoma",
                EsClave = true
            },
            new DataWindowColumn("orden", "long")
            {
                DbName = "reperto_total.orden"
            }
        };

        public string Sql => @"
SELECT reperto_total.reperto_total,
       reperto_total.reperto_sintoma,
       reperto_total.orden
  FROM reperto_total
";

        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
