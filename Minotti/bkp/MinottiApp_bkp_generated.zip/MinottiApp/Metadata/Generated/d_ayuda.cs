﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class d_ayuda : IDataWindowMetadata
    {
        public string DataObject => "d_ayuda";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "titulo",
                Tipo = "char(100)",
                Titulo = "Descripción de los datos de la Ventana",
                EsClave = false,
                EsRequerido = false,
                //Estilos = null,
                ObjetoSeleccion = null,
                Operacion = null,
                NivelOperacion = null,
                TabOrder = 32766
            },
            new DataWindowColumn
            {
                Nombre = "descripcion",
                Tipo = "char(256)",
                Titulo = string.Empty,
                EsClave = false,
                EsRequerido = false,
                //Estilos = null,
                ObjetoSeleccion = null,
                Operacion = null,
                NivelOperacion = null,
                TabOrder = 32766
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
