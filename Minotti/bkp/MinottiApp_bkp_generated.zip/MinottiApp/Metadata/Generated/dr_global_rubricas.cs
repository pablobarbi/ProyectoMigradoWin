﻿using System.Collections.Generic;
using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class dr_global_rubricas : IDataWindowMetadata
    {
        public string DataObject => "dr_global_rubricas";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "capitulo",
                DbName = "capitulos.nombre",
                Tipo = "char(255)",
                Titulo = "Capítulo",
                TabOrder = 1
            },
            new DataWindowColumn
            {
                Nombre = "nombre",
                DbName = "rubricas.nombre",
                Tipo = "char(255)",
                Titulo = "Rúbrica",
                TabOrder = 2
            }
        };

        public string[] Estilos => System.Array.Empty<string>();

        public string[] SeleccionFila => System.Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;

        public string Sql => @"
SELECT capitulos.nombre,
       rubricas.nombre
  FROM rubricas,
       capitulaciones,
       capitulos
 WHERE rubricas.nombre like :campo
   AND rubricas.rubrica = capitulaciones.rubrica
   AND capitulos.capitulo = capitulaciones.capitulo
";
    }
}
