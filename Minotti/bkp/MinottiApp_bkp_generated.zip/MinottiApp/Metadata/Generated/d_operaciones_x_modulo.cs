﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class d_operaciones_x_modulo : IDataWindowMetadata
    {
        public string DataObject => "d_operaciones_x_modulo";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "modulo",
                DbName = "acc_operaciones_x_modulo.modulo",
                Tipo = "char(5)",
                EsClave = true,
                TabOrder = null
            },
            new DataWindowColumn
            {
                Nombre = "operacion",
                DbName = "acc_operaciones_x_modulo.operacion",
                Tipo = "char(5)",
                EsClave = true,
                TabOrder = 10
            },
            new DataWindowColumn
            {
                Nombre = "submodulo",
                DbName = "acc_operaciones_x_modulo.submodulo",
                Tipo = "char(5)",
                TabOrder = 20
            },
            new DataWindowColumn
            {
                Nombre = "alta",
                DbName = "acc_operaciones_x_modulo.alta",
                Tipo = "char(1)",
                TabOrder = 30
            },
            new DataWindowColumn
            {
                Nombre = "baja",
                DbName = "acc_operaciones_x_modulo.baja",
                Tipo = "char(1)",
                TabOrder = 40
            },
            new DataWindowColumn
            {
                Nombre = "modificacion",
                DbName = "acc_operaciones_x_modulo.modificacion",
                Tipo = "char(1)",
                TabOrder = 50
            }
        };

        public string Sql => @"
SELECT dba.acc_operaciones_x_modulo.modulo,
       dba.acc_operaciones_x_modulo.operacion,
       dba.acc_operaciones_x_modulo.submodulo,
       dba.acc_operaciones_x_modulo.alta,
       dba.acc_operaciones_x_modulo.baja,
       dba.acc_operaciones_x_modulo.modificacion
  FROM dba.acc_operaciones_x_modulo
 WHERE dba.acc_operaciones_x_modulo.modulo = :modulo
";

        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
