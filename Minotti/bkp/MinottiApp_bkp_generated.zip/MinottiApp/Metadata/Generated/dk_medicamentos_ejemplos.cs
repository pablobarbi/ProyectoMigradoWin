﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    /// <summary>
    /// Metadata para dk_medicamentos_ejemplos
    /// </summary>
    public class dk_medicamentos_ejemplos : IDataWindowMetadata
    {
        public string DataObject => "dk_medicamentos_ejemplos";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "medicamento",
                DbName = "medicamentos.medicamento",
                Tipo = "char(10)"
            },
            new DataWindowColumn
            {
                Nombre = "descripcion",
                DbName = "medicamentos.descripcion",
                Tipo = "char(50)"
            },
            new DataWindowColumn
            {
                Nombre = "seleccionado",
                DbName = "seleccionado",
                Tipo = "char(1)",
                TabOrder = 10
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
