﻿using Minotti.Metadata;
using System.Collections.Generic;

namespace MinottiApp.Metadata.Generated
{
    public class dsto_reperto_parcial_med : IDataWindowMetadata
    {
        public string DataObject => "dsto_reperto_parcial_med";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn("reperto_parcial", "decimal(0)")
            {
                DbName = "reperto_parcial_med.reperto_parcial",
                EsClave = true
            },
            new DataWindowColumn("orden", "long")
            {
                DbName = "reperto_parcial_med.orden",
                EsClave = true
            },
            new DataWindowColumn("medicamento", "char(10)")
            {
                DbName = "reperto_parcial_med.medicamento"
            },
            new DataWindowColumn("valor", "long")
            {
                DbName = "reperto_parcial_med.valor"
            }
        };

        public string Sql => @"
SELECT reperto_parcial_med.reperto_parcial,
       reperto_parcial_med.orden,
       reperto_parcial_med.medicamento,
       reperto_parcial_med.valor
  FROM reperto_parcial_med
";

        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
