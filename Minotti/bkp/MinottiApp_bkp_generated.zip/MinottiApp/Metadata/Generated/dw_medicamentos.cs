﻿using System.Collections.Generic;
using System.Security.Principal;

namespace Minotti.Metadata.Generated
{
    public class dw_medicamentos : IDataWindowMetadata
    {
        public string DataObject => "dw_medicamentos";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn("medicamento", "string")
            {
                EsClavePrimaria= true,
                EsIdentity= false
            }
        };

        public string sql => @"
SELECT medicamentos.medicamento
  FROM medicamentos
 ORDER BY medicamentos.medicamento
";

        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
