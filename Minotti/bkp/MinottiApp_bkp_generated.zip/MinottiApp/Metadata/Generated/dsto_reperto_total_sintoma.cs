﻿using System.Collections.Generic;

namespace Minotti.Metadata.Generated
{
    public class dsto_reperto_total_sintoma : IDataWindowMetadata
    {
        public string DataObject => "dsto_reperto_total_sintoma";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn("reperto_total", "decimal(0)")
            {
                DbName = "reperto_total_sin.reperto_total",
                EsClave = true
            },
            new DataWindowColumn("reperto_sintoma", "decimal(0)")
            {
                DbName = "reperto_total_sin.reperto_sintoma",
                EsClave = true
            },
            new DataWindowColumn("capitulo", "decimal(0)")
            {
                DbName = "reperto_total_sin.capitulo"
            },
            new DataWindowColumn("rubrica", "decimal(0)")
            {
                DbName = "reperto_total_sin.rubrica"
            },
            new DataWindowColumn("subrubrica", "decimal(0)")
            {
                DbName = "reperto_total_sin.subrubrica"
            },
            new DataWindowColumn("subrubrica2", "decimal(0)")
            {
                DbName = "reperto_total_sin.subrubrica2"
            },
            new DataWindowColumn("subrubrica3", "decimal(0)")
            {
                DbName = "reperto_total_sin.subrubrica3"
            },
            new DataWindowColumn("subrubrica4", "decimal(0)")
            {
                DbName = "reperto_total_sin.subrubrica4"
            },
            new DataWindowColumn("subrubrica5", "decimal(0)")
            {
                DbName = "reperto_total_sin.subrubrica5"
            },
            new DataWindowColumn("subrubrica6", "decimal(0)")
            {
                DbName = "reperto_total_sin.subrubrica6"
            },
            new DataWindowColumn("subrubrica7", "decimal(0)")
            {
                DbName = "reperto_total_sin.subrubrica7"
            },
            new DataWindowColumn("subrubrica8", "decimal(0)")
            {
                DbName = "reperto_total_sin.subrubrica8"
            },
            new DataWindowColumn("subrubrica9", "decimal(0)")
            {
                DbName = "reperto_total_sin.subrubrica9"
            },
            new DataWindowColumn("subrubrica10", "decimal(0)")
            {
                DbName = "reperto_total_sin.subrubrica10"
            }
        };

        public string Sql => @"
SELECT reperto_total_sin.reperto_total,
       reperto_total_sin.reperto_sintoma,
       reperto_total_sin.capitulo,
       reperto_total_sin.rubrica,
       reperto_total_sin.subrubrica,
       reperto_total_sin.subrubrica2,
       reperto_total_sin.subrubrica3,
       reperto_total_sin.subrubrica4,
       reperto_total_sin.subrubrica5,
       reperto_total_sin.subrubrica6,
       reperto_total_sin.subrubrica7,
       reperto_total_sin.subrubrica8,
       reperto_total_sin.subrubrica9,
       reperto_total_sin.subrubrica10
  FROM reperto_total_sin,
       reperto_total
 WHERE reperto_total.reperto_total = :reperto
   AND reperto_total.reperto_total = reperto_total_sin.reperto_total
   AND reperto_total.reperto_sintoma = reperto_total_sin.reperto_sintoma
";

        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
