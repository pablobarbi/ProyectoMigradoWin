﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    /// <summary>
    /// DataWindow usada en w_sortdw
    /// </summary>
    public class d_saveas : IDataWindowMetadata
    {
        public string DataObject => "d_saveas";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "columnname",
                DbName = "columnname",
                Tipo = "char(50)"
            },
            new DataWindowColumn
            {
                Nombre = "displayname",
                DbName = "displayname",
                Tipo = "char(10)"
            },
            new DataWindowColumn
            {
                Nombre = "use_display",
                DbName = "use_display",
                Tipo = "char(1)"
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
