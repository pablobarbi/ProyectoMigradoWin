﻿using Minotti.Metadata;
using System;
using System.Collections.Generic;

namespace Minotti.Metadata.Generated
{
    public class dr_capitulo_matriz : IDataWindowMetadata
    {
        public string DataObject => "dr_capitulo_matriz";

        public List<DataWindowColumn> Columns => new()
        {
            new() { Nombre = "capitulo_nombre", DbName = "capitulaciones_matriz.capitulo_nombre", Tipo = "char(255)" },
            new() { Nombre = "rubrica_nombre", DbName = "capitulaciones_matriz.rubrica_nombre", Tipo = "char(255)" },
            new() { Nombre = "subrubrica_nombre", DbName = "capitulaciones_matriz.subrubrica_nombre", Tipo = "char(255)" },

            new() { Nombre = "subrubrica01_nombre", DbName = "capitulaciones_matriz.subrubrica01_nombre", Tipo = "char(255)" },
            new() { Nombre = "subrubrica02_nombre", DbName = "capitulaciones_matriz.subrubrica02_nombre", Tipo = "char(255)" },
            new() { Nombre = "subrubrica03_nombre", DbName = "capitulaciones_matriz.subrubrica03_nombre", Tipo = "char(255)" },
            new() { Nombre = "subrubrica04_nombre", DbName = "capitulaciones_matriz.subrubrica04_nombre", Tipo = "char(255)" },
            new() { Nombre = "subrubrica05_nombre", DbName = "capitulaciones_matriz.subrubrica05_nombre", Tipo = "char(255)" },
            new() { Nombre = "subrubrica06_nombre", DbName = "capitulaciones_matriz.subrubrica06_nombre", Tipo = "char(255)" },
            new() { Nombre = "subrubrica07_nombre", DbName = "capitulaciones_matriz.subrubrica07_nombre", Tipo = "char(255)" },
            new() { Nombre = "subrubrica08_nombre", DbName = "capitulaciones_matriz.subrubrica08_nombre", Tipo = "char(255)" },
            new() { Nombre = "subrubrica09_nombre", DbName = "capitulaciones_matriz.subrubrica09_nombre", Tipo = "char(255)" },
            new() { Nombre = "subrubrica10_nombre", DbName = "capitulaciones_matriz.subrubrica10_nombre", Tipo = "char(255)" }
        };

        public string Sql => @"
SELECT capitulo_nombre,
       rubrica_nombre,
       subrubrica_nombre,
       subrubrica01_nombre,
       subrubrica02_nombre,
       subrubrica03_nombre,
       subrubrica04_nombre,
       subrubrica05_nombre,
       subrubrica06_nombre,
       subrubrica07_nombre,
       subrubrica08_nombre,
       subrubrica09_nombre,
       subrubrica10_nombre
  FROM capitulaciones_matriz
 WHERE UPPER(capitulo_nombre)     LIKE '%' + UPPER(:filtro) + '%'
    OR UPPER(rubrica_nombre)      LIKE '%' + UPPER(:filtro) + '%'
    OR UPPER(subrubrica_nombre)   LIKE '%' + UPPER(:filtro) + '%'
    OR UPPER(subrubrica01_nombre) LIKE '%' + UPPER(:filtro) + '%'
    OR UPPER(subrubrica02_nombre) LIKE '%' + UPPER(:filtro) + '%'
    OR UPPER(subrubrica03_nombre) LIKE '%' + UPPER(:filtro) + '%'
    OR UPPER(subrubrica04_nombre) LIKE '%' + UPPER(:filtro) + '%'
    OR UPPER(subrubrica05_nombre) LIKE '%' + UPPER(:filtro) + '%'
    OR UPPER(subrubrica06_nombre) LIKE '%' + UPPER(:filtro) + '%'
    OR UPPER(subrubrica07_nombre) LIKE '%' + UPPER(:filtro) + '%'
    OR UPPER(subrubrica08_nombre) LIKE '%' + UPPER(:filtro) + '%'
    OR UPPER(subrubrica09_nombre) LIKE '%' + UPPER(:filtro) + '%'
    OR UPPER(subrubrica10_nombre) LIKE '%' + UPPER(:filtro) + '%'
ORDER BY 1,2,3
";

        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
