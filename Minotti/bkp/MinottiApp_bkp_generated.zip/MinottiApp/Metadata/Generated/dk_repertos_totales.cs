﻿using Minotti.Metadata;

namespace MinottiApp.Metadata.Generated
{
    public class dk_repertos_totales : IDataWindowMetadata
    {
        public string DataObject => "dk_repertos_totales";
        public List<DataWindowColumn> Columns { get; } = new List<DataWindowColumn>
        {
            new DataWindowColumn("reperto_parcial", "decimal(0)"),
            new DataWindowColumn("capitulo", "decimal(0)"),
            new DataWindowColumn("rubrica", "decimal(0)"),
            new DataWindowColumn("subrubrica", "decimal(0)"),
            new DataWindowColumn("subrubrica2", "decimal(0)"),
            new DataWindowColumn("subrubrica3", "decimal(0)"),
            new DataWindowColumn("subrubrica4", "decimal(0)"),
            new DataWindowColumn("subrubrica5", "decimal(0)"),
            new DataWindowColumn("subrubrica6", "decimal(0)"),
            new DataWindowColumn("subrubrica7", "decimal(0)"),
            new DataWindowColumn("subrubrica8", "decimal(0)"),
            new DataWindowColumn("subrubrica9", "decimal(0)"),
            new DataWindowColumn("subrubrica10", "decimal(0)"),
            new DataWindowColumn("seleccionado", "char(1)"),
            new DataWindowColumn("capitulo_nombre", "char(1)"),
            new DataWindowColumn("rubrica_nombre", "char(1)"),
            new DataWindowColumn("subrubrica_nombre", "char(1)"),
            new DataWindowColumn("subrubrica2_nombre", "char(1)"),
            new DataWindowColumn("subrubrica3_nombre", "char(1)"),
            new DataWindowColumn("subrubrica4_nombre", "char(1)"),
            new DataWindowColumn("subrubrica5_nombre", "char(1)"),
            new DataWindowColumn("subrubrica6_nombre", "char(1)"),
            new DataWindowColumn("subrubrica7_nombre", "char(1)"),
            new DataWindowColumn("subrubrica8_nombre", "char(1)"),
            new DataWindowColumn("subrubrica9_nombre", "char(1)"),
            new DataWindowColumn("subrubrica10_nombre", "char(1)")
        };

        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;  // Si no hay operaciones especificadas, lo dejo vacío
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
