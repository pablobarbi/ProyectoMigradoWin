﻿using System.Collections.Generic;
using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class dr_perfiles : IDataWindowMetadata
    {
        public string DataObject => "dr_perfiles";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "perfil",
                DbName = "acc_perfiles.perfil",
                Tipo = "char(5)",
                Titulo = "Perfil",
                EsClave = true
            },
            new DataWindowColumn
            {
                Nombre = "nombre",
                DbName = "acc_perfiles.nombre",
                Tipo = "char(20)",
                Titulo = "Nombre"
            },
            new DataWindowColumn
            {
                Nombre = "bitmap",
                DbName = "acc_perfiles.bitmap",
                Tipo = "char(40)",
                Titulo = "Bitmap"
            }
        };

        public string[] Estilos => System.Array.Empty<string>();

        public string[] SeleccionFila => System.Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;

        public string Sql => @"
SELECT dba.acc_perfiles.perfil,
       dba.acc_perfiles.nombre,
       dba.acc_perfiles.bitmap
  FROM dba.acc_perfiles
 ORDER BY dba.acc_perfiles.nombre
";
    }
}
