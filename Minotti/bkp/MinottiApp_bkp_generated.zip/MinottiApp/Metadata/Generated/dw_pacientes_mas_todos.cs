﻿using System.Collections.Generic;
using System.Security.Principal;

namespace Minotti.Metadata.Generated
{
    public class dw_pacientes_mas_todos : IDataWindowMetadata
    {
        public string DataObject => "dw_pacientes_mas_todos";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn("paciente","long")
            {
                EsClavePrimaria= false,
                EsIdentity= false
            }            ,
            new DataWindowColumn(
                "nombre",
                "string")
            {
                EsClavePrimaria = false,
                EsIdentity = false
            }
    };

        public string sql => @"
SELECT pacientes.paciente,
       pacientes.nombre
  FROM pacientes
UNION
SELECT 0, ' Todos los pacientes'
ORDER BY 2
";

        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
