﻿using Minotti.Metadata;

namespace MinottiApp.Metadata.Generated
{
    public class dk_subrubricas_de_la_rubrica : IDataWindowMetadata
    {
        public string DataObject => "dk_subrubricas_de_la_rubrica";

        public List<DataWindowColumn> Columns { get; } = new()
        {
            new DataWindowColumn("rubricaciones_rubrica", "decimal(0)")
            {
                DbName = "rubricaciones.rubrica",
                EsClave = true
            },
            new DataWindowColumn("rubricaciones_subrubrica", "decimal(0)")
            {
                DbName = "rubricaciones.subrubrica",
                EsClave = true
            },
            new DataWindowColumn("rubricaciones_posicion", "long")
            {
                DbName = "rubricaciones.posicion"
            },
            new DataWindowColumn("subrubricas_nombre", "char(255)")
            {
                DbName = "subrubricas.nombre",
                Titulo = "Subrubricas"
            },
            new DataWindowColumn("subrubricas_nombre_orden", "char(259)")
            {
                DbName = "subrubricas_nombre_orden"
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
