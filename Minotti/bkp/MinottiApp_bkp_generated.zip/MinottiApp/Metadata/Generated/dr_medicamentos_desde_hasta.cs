﻿using System.Collections.Generic;
using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class dr_medicamentos_desde_hasta : IDataWindowMetadata
    {
        public string DataObject => "dr_medicamentos_desde_hasta";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "medicamento",
                DbName = "medicamentos.medicamento",
                Tipo = "char(10)",
                Titulo = "Medicamento",
                EsClave = true,
                EsClavePrimaria = true,
                EsIdentity = false,
                TabOrder = 1
            },
            new DataWindowColumn
            {
                Nombre = "descripcion",
                DbName = "medicamentos.descripcion",
                Tipo = "char(50)",
                Titulo = "Descripción",
                TabOrder = 2
            }
        };

        public string[] Estilos => System.Array.Empty<string>();

        public string[] SeleccionFila => System.Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;

        public string Sql => @"
SELECT medicamentos.medicamento,
       medicamentos.descripcion
  FROM medicamentos
 WHERE medicamentos.medicamento >= :desde
   AND medicamentos.medicamento <= :hasta
ORDER BY 1
";
    }
}
