﻿using Minotti.Metadata;
using System;
using System.Collections.Generic;

namespace Minotti.Metadata.Generated
{
    public class dp_un_medicamento : IDataWindowMetadata
    {
        public string DataObject => "dp_un_medicamento";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "capitulo",
                DbName = "capitulacion_med.capitulo",
                Tipo = "decimal(0)",
                Titulo = "Capítulo",
                EsClave = true,
                EsClavePrimaria = false,
                EsIdentity = false,
                TabOrder = 10,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "medicamento",
                DbName = "capitulacion_med.medicamento",
                Tipo = "char(10)",
                Titulo = "Medicamento",
                EsClave = true,
                EsClavePrimaria = false,
                EsIdentity = false,
                TabOrder = 20,
                Valores = Array.Empty<string>()
            }
        };

        // ⇩ Metadata funcional (no definida en el SRD) ⇩
        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;

        public string Sql => @"
SELECT capitulacion_med.capitulo,
       capitulacion_med.medicamento
  FROM capitulacion_med
";
    }
}
