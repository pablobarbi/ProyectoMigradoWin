﻿using System.Collections.Generic;
using System.Security.Principal;

namespace Minotti.Metadata.Generated
{
    public class dw_rubricas : IDataWindowMetadata
    {
        public string DataObject => "dw_rubricas";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn( "rubrica", "number")
            {
                EsClavePrimaria= true,
                EsIdentity= true
            },
            new DataWindowColumn("nombre", "string")
            {
                EsClavePrimaria= false,
                EsIdentity= false
            }
        };

        public string sql => @"
SELECT rubricas.rubrica,
       rubricas.nombre
  FROM rubricas
ORDER BY 2
";

        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
