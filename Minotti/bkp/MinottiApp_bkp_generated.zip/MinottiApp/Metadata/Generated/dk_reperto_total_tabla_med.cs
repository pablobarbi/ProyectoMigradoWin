﻿using System;
using System.Collections.Generic;

namespace Minotti.Metadata.Generated
{
    public class d_reperto_total_tabla_med : IDataWindowMetadata
    {
        public string DataObject => "dk_reperto_total_tabla_med";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn("reperto_total", "decimal"),
            new DataWindowColumn("reperto_sintoma", "decimal"),
            new DataWindowColumn("medicamento", "string"),
            new DataWindowColumn("puntuacion", "string"),
            new DataWindowColumn("orden", "decimal"),
            new DataWindowColumn("valor", "long")
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;

        public string Sql => @"
            SELECT reperto_total_diag.reperto_total,
                   reperto_total_diag.fecha,
                   reperto_total_diag.comentario,
                   reperto_total_diag.paciente,
                   reperto_total_diag.marca
            FROM reperto_total_diag
        ";

        // Valores adicionales como columnas de tipo long para valorX (ejemplo valor1, valor2, etc.)
        // Son 70 columnas de valores con inicialización a 0
        public List<long> Valores { get; set; } = new List<long>(new long[70]);

        // Puede incluir alguna lógica para manejar la cantidad si es necesario
        public long Cantidad { get; set; } = 0;
    }

   
}
