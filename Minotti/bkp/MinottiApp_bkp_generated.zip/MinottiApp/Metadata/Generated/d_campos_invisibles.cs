﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class d_campos_invisibles : IDataWindowMetadata
    {
        public string DataObject => "d_campos_invisibles";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "campo",
                Tipo = "char(18)",
                Titulo = "Campo",
                EsClave = true,
                EsRequerido = false,
                //Estilos = null,
                ObjetoSeleccion = null,
                Operacion = null,
                NivelOperacion = null,
                TabOrder = 32766
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;

        public string Sql => @"SELECT dba.par_campoinvisible.campo
                               FROM dba.par_campoinvisible";
    }
}
