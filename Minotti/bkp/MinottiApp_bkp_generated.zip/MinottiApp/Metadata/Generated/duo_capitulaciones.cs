﻿using System.Collections.Generic;

namespace Minotti.Metadata.Generated
{
    public class duo_capitulaciones : IDataWindowMetadata
    {
        public string DataObject => "duo_capitulaciones";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn("capitulo", "decimal(0)")
            {
                DbName = "capitulaciones.capitulo"
            },
            new DataWindowColumn("rubrica", "decimal(0)")
            {
                DbName = "capitulaciones.rubrica"
            },
            new DataWindowColumn("capitulo_nombre", "char(255)")
            {
                DbName = "capitulos.nombre"
            },
            new DataWindowColumn("rubrica_nombre", "char(255)")
            {
                DbName = "rubricas.nombre"
            }
        };

        public string Sql => @"
SELECT capitulaciones.capitulo,
       capitulaciones.rubrica,
       capitulos.nombre,
       rubricas.nombre
  FROM capitulaciones,
       rubricas,
       capitulos
 WHERE capitulaciones.rubrica = rubricas.rubrica
   AND capitulaciones.capitulo = capitulos.capitulo
   AND ((capitulaciones.capitulo = :capitulo) OR (:capitulo = 0))
";

        // --- Metadata inferida del SRD ---
        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
