﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class d_carpetas : IDataWindowMetadata
    {
        public string DataObject => "d_carpetas";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "nombre",
                DbName = "acc_carpetas.nombre",
                Tipo = "char(8)",
                Titulo = "Nombre",
                EsClave = true,
                EsRequerido = false,
                TabOrder = 10
            },
            new DataWindowColumn
            {
                Nombre = "pagina",
                DbName = "acc_carpetas.pagina",
                Tipo = "long",
                Titulo = "Pagina",
                EsClave = true,
                EsRequerido = false,
                TabOrder = 20
            },
            new DataWindowColumn
            {
                Nombre = "titulo",
                DbName = "acc_carpetas.titulo",
                Tipo = "char(80)",
                Titulo = "Titulo",
                EsClave = false,
                EsRequerido = false,
                TabOrder = 30
            },
            new DataWindowColumn
            {
                Nombre = "objeto",
                DbName = "acc_carpetas.objeto",
                Tipo = "char(40)",
                Titulo = "Objeto",
                EsClave = false,
                EsRequerido = false,
                TabOrder = 40
            },
            new DataWindowColumn
            {
                Nombre = "parametros",
                DbName = "acc_carpetas.parametros",
                Tipo = "char(255)",
                Titulo = "Parametros",
                EsClave = false,
                EsRequerido = false,
                TabOrder = 50
            },
            new DataWindowColumn
            {
                Nombre = "bitmap",
                DbName = "acc_carpetas.bitmap",
                Tipo = "char(40)",
                Titulo = "Bitmap",
                EsClave = false,
                EsRequerido = false,
                TabOrder = 60
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;

        public string Sql => @"
SELECT dba.acc_carpetas.nombre,
       dba.acc_carpetas.pagina,
       dba.acc_carpetas.titulo,
       dba.acc_carpetas.objeto,
       dba.acc_carpetas.parametros,
       dba.acc_carpetas.bitmap
  FROM dba.acc_carpetas
 WHERE dba.acc_carpetas.nombre = :carpeta
 ORDER BY dba.acc_carpetas.pagina ASC
";
    }
}
