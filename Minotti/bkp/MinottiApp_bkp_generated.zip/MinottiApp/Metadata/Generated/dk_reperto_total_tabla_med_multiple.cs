﻿using System;
using System.Collections.Generic;
using Minotti.Metadata;

namespace MinottiApp.Metadata.Generated
{
    public class dk_reperto_total_tabla_med_multiple : IDataWindowMetadata
    {
        public string DataObject => "dk_reperto_total_tabla_med_multiple";

        public List<DataWindowColumn> Columns { get; } = new List<DataWindowColumn>
        {
            new DataWindowColumn("reperto_total", "decimal(0)") { EsClave = true, DbName = "reperto_total_med.reperto_total" },
            new DataWindowColumn("reperto_sintoma", "decimal(0)") { EsClave = true, DbName = "reperto_total_med.reperto_sintoma" },
            new DataWindowColumn("medicamento", "char(10)") { EsClave = true, DbName = "reperto_total_med.medicamento" },
            new DataWindowColumn("puntuacion", "char(5)") { DbName = "reperto_total_med.puntuacion" },
            new DataWindowColumn("valor1", "long") { DbName = "valor1" },
            new DataWindowColumn("valor2", "long") { DbName = "valor2" },
            new DataWindowColumn("valor3", "long") { DbName = "valor3" },
            new DataWindowColumn("valor4", "long") { DbName = "valor4" },
            new DataWindowColumn("valor5", "long") { DbName = "valor5" },
            new DataWindowColumn("valor6", "long") { DbName = "valor6" },
            new DataWindowColumn("valor7", "long") { DbName = "valor7" },
            new DataWindowColumn("valor8", "long") { DbName = "valor8" },
            new DataWindowColumn("valor9", "long") { DbName = "valor9" },
            new DataWindowColumn("valor10", "long") { DbName = "valor10" },
            new DataWindowColumn("valor11", "long") { DbName = "valor11" },
            new DataWindowColumn("valor12", "long") { DbName = "valor12" },
            new DataWindowColumn("valor13", "long") { DbName = "valor13" },
            new DataWindowColumn("valor14", "long") { DbName = "valor14" },
            new DataWindowColumn("valor15", "long") { DbName = "valor15" },
            new DataWindowColumn("valor16", "long") { DbName = "valor16" },
            new DataWindowColumn("valor17", "long") { DbName = "valor17" },
            new DataWindowColumn("valor18", "long") { DbName = "valor18" },
            new DataWindowColumn("valor19", "long") { DbName = "valor19" },
            new DataWindowColumn("valor20", "long") { DbName = "valor20" },
            new DataWindowColumn("valor21", "long") { DbName = "valor21" },
            new DataWindowColumn("valor22", "long") { DbName = "valor22" },
            new DataWindowColumn("valor23", "long") { DbName = "valor23" },
            new DataWindowColumn("valor24", "long") { DbName = "valor24" },
            new DataWindowColumn("valor25", "long") { DbName = "valor25" },
            new DataWindowColumn("valor26", "long") { DbName = "valor26" },
            new DataWindowColumn("valor27", "long") { DbName = "valor27" },
            new DataWindowColumn("valor28", "long") { DbName = "valor28" },
            new DataWindowColumn("valor29", "long") { DbName = "valor29" },
            new DataWindowColumn("valor30", "long") { DbName = "valor30" },
            new DataWindowColumn("valor31", "long") { DbName = "valor31" },
            new DataWindowColumn("orden", "decimal(5)") { DbName = "reperto_total_med.orden" },
            new DataWindowColumn("valor", "long") { DbName = "reperto_total_med.valor" }
        };

        public string[] Estilos => new string[] { /* Aquí van tus estilos */ };
        public string[] SeleccionFila => new string[] { /* Aquí van tus filas seleccionadas */ };

        public string Operaciones => "Operación de Reperto Total Med Multiple";

        public bool UsaUsuario => true;

        public bool UsaFecha => true;
    }
}
