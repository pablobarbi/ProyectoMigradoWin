﻿using System.Collections.Generic;
using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class dr_operaciones_por_modulo : IDataWindowMetadata
    {
        public string DataObject => "dr_operaciones_por_modulo";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "modulo",
                DbName = "acc_operaciones_x_modulo.modulo",
                Tipo = "char(5)",
                Titulo = "Módulo",
                EsClave = true
            },
            new DataWindowColumn
            {
                Nombre = "nombre_modulo",
                DbName = "acc_modulos.nombre",
                Tipo = "char(20)",
                Titulo = "Nombre Módulo"
            },
            new DataWindowColumn
            {
                Nombre = "bitmap_modulo",
                DbName = "acc_modulos.bitmap",
                Tipo = "char(40)",
                Titulo = "Bitmap Módulo"
            },
            new DataWindowColumn
            {
                Nombre = "operacion",
                DbName = "acc_operaciones_x_modulo.operacion",
                Tipo = "char(5)",
                Titulo = "Operación",
                EsClave = true
            },
            new DataWindowColumn
            {
                Nombre = "nombre_operacion",
                DbName = "acc_operaciones.nombre",
                Tipo = "char(30)",
                Titulo = "Nombre Operación"
            },
            new DataWindowColumn
            {
                Nombre = "bitmap_operacion",
                DbName = "acc_operaciones.bitmap",
                Tipo = "char(40)",
                Titulo = "Bitmap Operación"
            },
            new DataWindowColumn
            {
                Nombre = "alta",
                DbName = "alta",
                Tipo = "char(1)",
                Titulo = "Alta",
                Valores = new[] { "S", "N" }
            },
            new DataWindowColumn
            {
                Nombre = "baja",
                DbName = "baja",
                Tipo = "char(1)",
                Titulo = "Baja",
                Valores = new[] { "S", "N" }
            },
            new DataWindowColumn
            {
                Nombre = "modificacion",
                DbName = "modificacion",
                Tipo = "char(1)",
                Titulo = "Modificación",
                Valores = new[] { "S", "N" }
            }
        };

        public string[] Estilos => System.Array.Empty<string>();

        public string[] SeleccionFila => System.Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;

        public string Sql => @"
SELECT dba.acc_operaciones_x_modulo.modulo,
       dba.acc_modulos.nombre,
       dba.acc_modulos.bitmap,
       dba.acc_operaciones_x_modulo.operacion,
       dba.acc_operaciones.nombre,
       dba.acc_operaciones.bitmap,
       upper(dba.acc_operaciones_x_modulo.alta) alta,
       upper(dba.acc_operaciones_x_modulo.baja) baja,
       upper(dba.acc_operaciones_x_modulo.modificacion) modificacion
  FROM dba.acc_modulos,
       dba.acc_operaciones,
       dba.acc_operaciones_x_modulo
 WHERE dba.acc_modulos.modulo = dba.acc_operaciones_x_modulo.modulo
   AND dba.acc_operaciones_x_modulo.operacion = dba.acc_operaciones.operacion
 ORDER BY dba.acc_modulos.nombre,
          dba.acc_operaciones.nombre
";
    }
}
