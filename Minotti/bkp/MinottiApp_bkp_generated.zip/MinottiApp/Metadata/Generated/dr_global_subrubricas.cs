﻿using System.Collections.Generic;
using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class dr_global_subrubricas : IDataWindowMetadata
    {
        public string DataObject => "dr_global_subrubricas";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "capitulo",
                DbName = "capitulos.nombre",
                Tipo = "char(255)",
                Titulo = "Capitulo",
                TabOrder = 1
            },
            new DataWindowColumn
            {
                Nombre = "rubrica",
                DbName = "rubricas.nombre",
                Tipo = "char(255)",
                Titulo = "Rubrica",
                TabOrder = 2
            },
            new DataWindowColumn
            {
                Nombre = "subrubrica",
                DbName = "subrubricas.nombre",
                Tipo = "char(255)",
                Titulo = "Subrubrica",
                TabOrder = 3
            }
        };

        public string[] Estilos => System.Array.Empty<string>();

        public string[] SeleccionFila => System.Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;

        public string Sql => @"
SELECT capitulos.nombre,
       rubricas.nombre,
       subrubricas.nombre
  FROM subrubricas,
       subrubricaciones,
       rubricaciones,
       rubricas,
       capitulaciones,
       capitulos
 WHERE subrubricas.nombre like :campo
   AND rubricas.rubrica = capitulaciones.rubrica
   AND capitulos.capitulo = capitulaciones.capitulo
   AND rubricaciones.rubrica = rubricas.rubrica
   AND rubricaciones.subrubrica = subrubricaciones.subrubrica_padre
   AND (
        (subrubricaciones.subrubrica_padre = subrubricas.subrubrica)
     OR (subrubricaciones.subrubrica_hija  = subrubricas.subrubrica)
       )
";
    }
}
