﻿using Minotti.Metadata;
using System;
using System.Collections.Generic;

namespace Minotti.Metadata.Generated
{
    public class dp_pacientes : IDataWindowMetadata
    {
        public string DataObject => "dp_pacientes";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "paciente",
                DbName = "pacientes.paciente",
                Tipo = "long",
                Titulo = "Paciente",
                EsClave = true,
                EsClavePrimaria = true,
                EsIdentity = true,
                EsRequerido = false,
                TabOrder = 10,
                Valores = Array.Empty<string>()
            }
        };

        // ⇩ No hay metadata explícita en el SRD ⇩
        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;

        public string Sql => @"
SELECT pacientes.paciente
  FROM pacientes
";
    }
}
