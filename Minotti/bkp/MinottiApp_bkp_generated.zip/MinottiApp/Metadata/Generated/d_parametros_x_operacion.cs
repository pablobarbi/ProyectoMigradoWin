﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class d_parametros_x_operacion : IDataWindowMetadata
    {
        public string DataObject => "d_parametros_x_operacion";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "operacion",
                DbName = "acc_parametros.operacion",
                Tipo = "char(8)"
            },
            new DataWindowColumn
            {
                Nombre = "orden",
                DbName = "acc_parametros.orden",
                Tipo = "long"
            },
            new DataWindowColumn
            {
                Nombre = "titulo",
                DbName = "acc_parametros.titulo",
                Tipo = "char(80)"
            },
            new DataWindowColumn
            {
                Nombre = "objeto",
                DbName = "acc_parametros.objeto",
                Tipo = "char(40)"
            },
            new DataWindowColumn
            {
                Nombre = "parametros",
                DbName = "acc_parametros.parametros",
                Tipo = "char(255)"
            },
            new DataWindowColumn
            {
                Nombre = "cierra",
                DbName = "acc_parametros.cierra",
                Tipo = "char(1)"
            }
        };

        public string Sql => @"
SELECT dba.acc_parametros.operacion,   
       dba.acc_parametros.orden,   
       dba.acc_parametros.titulo,   
       dba.acc_parametros.objeto,   
       dba.acc_parametros.parametros,   
       dba.acc_parametros.cierra  
  FROM dba.acc_parametros  
 WHERE dba.acc_parametros.operacion = :operacion
";

        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
