﻿using System.Collections.Generic;

namespace Minotti.Metadata.Generated
{
    public class duo_rubricaciones_med : IDataWindowMetadata
    {
        public string DataObject => "duo_rubricaciones_med";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn("rubrica", "decimal(0)")
            {
                DbName = "rubricacion_med.rubrica",
                 EsClavePrimaria = true,
    EsIdentity = true
            },
            new DataWindowColumn("subrubrica", "decimal(0)")
            {
                DbName = "rubricacion_med.subrubrica",
                 EsClavePrimaria = true,
                EsIdentity = true
            },
            new DataWindowColumn("medicamento", "char(10)")
            {
                DbName = "rubricacion_med.medicamento",
                EsClavePrimaria = true, EsIdentity = true
            },
            new DataWindowColumn("valor", "long")
            {
                DbName = "rubricacion_med.valor"
            }
        };

        public string Sql => @"
SELECT rubricacion_med.rubrica,
       rubricacion_med.subrubrica,
       rubricacion_med.medicamento,
       rubricacion_med.valor
  FROM rubricacion_med
 WHERE rubricacion_med.rubrica = :rubrica
   AND rubricacion_med.subrubrica = :subrubrica
";

        public Dictionary<string, string> Arguments => new()
        {
            { "rubrica", "string" },
            { "subrubrica", "string" }
        };

        // --- Metadata ---
        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
