﻿using Minotti.Metadata;
using System;
using System.Collections.Generic;

namespace Minotti.Metadata.Generated
{
    public class dr_dos_medicamentos : IDataWindowMetadata
    {
        public string DataObject => "dr_dos_medicamentos";

        public List<DataWindowColumn> Columns => new()
        {
            new() { Nombre = "capitulo_nombre", DbName = "capitulaciones_matriz.capitulo_nombre", Tipo = "char(255)" },
            new() { Nombre = "rubrica_nombre", DbName = "capitulaciones_matriz.rubrica_nombre", Tipo = "char(255)" },
            new() { Nombre = "subrubrica_nombre", DbName = "capitulaciones_matriz.subrubrica_nombre", Tipo = "char(255)" },

            new() { Nombre = "subrubrica01_nombre", DbName = "capitulaciones_matriz.subrubrica01_nombre", Tipo = "char(255)" },
            new() { Nombre = "subrubrica02_nombre", DbName = "capitulaciones_matriz.subrubrica02_nombre", Tipo = "char(255)" },
            new() { Nombre = "subrubrica03_nombre", DbName = "capitulaciones_matriz.subrubrica03_nombre", Tipo = "char(255)" },
            new() { Nombre = "subrubrica04_nombre", DbName = "capitulaciones_matriz.subrubrica04_nombre", Tipo = "char(255)" },
            new() { Nombre = "subrubrica05_nombre", DbName = "capitulaciones_matriz.subrubrica05_nombre", Tipo = "char(255)" },
            new() { Nombre = "subrubrica06_nombre", DbName = "capitulaciones_matriz.subrubrica06_nombre", Tipo = "char(255)" },
            new() { Nombre = "subrubrica07_nombre", DbName = "capitulaciones_matriz.subrubrica07_nombre", Tipo = "char(255)" },
            new() { Nombre = "subrubrica08_nombre", DbName = "capitulaciones_matriz.subrubrica08_nombre", Tipo = "char(255)" },
            new() { Nombre = "subrubrica09_nombre", DbName = "capitulaciones_matriz.subrubrica09_nombre", Tipo = "char(255)" },
            new() { Nombre = "subrubrica10_nombre", DbName = "capitulaciones_matriz.subrubrica10_nombre", Tipo = "char(255)" },

            new() { Nombre = "medicamento", DbName = "capitulacion_med.medicamento", Tipo = "char(10)" },
            new() { Nombre = "valor", DbName = "capitulacion_med.valor", Tipo = "long" }
        };

        public string Sql => @"
SELECT cap.capitulo_nombre,
       cap.rubrica_nombre,
       cap.subrubrica_nombre,
       cap.subrubrica01_nombre,
       cap.subrubrica02_nombre,
       cap.subrubrica03_nombre,
       cap.subrubrica04_nombre,
       cap.subrubrica05_nombre,
       cap.subrubrica06_nombre,
       cap.subrubrica07_nombre,
       cap.subrubrica08_nombre,
       cap.subrubrica09_nombre,
       cap.subrubrica10_nombre,
       cm.medicamento,
       cm.valor
  FROM capitulaciones_matriz cap,
       capitulacion_med cm
 WHERE ((cap.capitulo = :capitulo) OR (99 = :capitulo))
   AND cap.capitulo = cm.capitulo
   AND cap.rubrica = cm.rubrica
   AND cm.medicamento IN (:medicamento, :medicamento2)
UNION
SELECT cap.capitulo_nombre,
       cap.rubrica_nombre,
       cap.subrubrica_nombre,
       cap.subrubrica01_nombre,
       cap.subrubrica02_nombre,
       cap.subrubrica03_nombre,
       cap.subrubrica04_nombre,
       cap.subrubrica05_nombre,
       cap.subrubrica06_nombre,
       cap.subrubrica07_nombre,
       cap.subrubrica08_nombre,
       cap.subrubrica09_nombre,
       cap.subrubrica10_nombre,
       cm.medicamento,
       cm.valor
  FROM capitulaciones_matriz cap,
       rubricacion_med cm
 WHERE ((cap.capitulo = :capitulo) OR (99 = :capitulo))
   AND cap.rubrica = cm.rubrica
   AND cap.subrubrica = cm.subrubrica
   AND cm.medicamento IN (:medicamento, :medicamento2)
UNION
SELECT cap.capitulo_nombre,
       cap.rubrica_nombre,
       cap.subrubrica_nombre,
       cap.subrubrica01_nombre,
       cap.subrubrica02_nombre,
       cap.subrubrica03_nombre,
       cap.subrubrica04_nombre,
       cap.subrubrica05_nombre,
       cap.subrubrica06_nombre,
       cap.subrubrica07_nombre,
       cap.subrubrica08_nombre,
       cap.subrubrica09_nombre,
       cap.subrubrica10_nombre,
       cm.medicamento,
       cm.valor
  FROM capitulaciones_matriz cap,
       subrubricacion_med cm
 WHERE ((cap.capitulo = :capitulo) OR (99 = :capitulo))
   AND cap.subrubrica = cm.subrubrica_padre
   AND cap.subrubrica01 = cm.subrubrica_hija
   AND cm.medicamento IN (:medicamento, :medicamento2)
-- (resto de UNION idénticos, respetados tal cual en el SRD)
ORDER BY 1,2,3
";

        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
