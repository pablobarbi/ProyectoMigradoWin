﻿using Minotti.Metadata;
using System;
using System.Collections.Generic;

namespace Minotti.Metadata.Generated
{
    public class dp_dos_medicamentos_valor : IDataWindowMetadata
    {
        public string DataObject => "dp_dos_medicamentos_valor";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "capitulo",
                DbName = "capitulacion_med.capitulo",
                Tipo = "decimal(0)",
                Titulo = "Capítulo",
                EsClave = true,
                EsRequerido = true,
                TabOrder = 10,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "medicamento",
                DbName = "capitulacion_med.medicamento",
                Tipo = "char(10)",
                Titulo = "Medicamento",
                EsClave = true,
                EsRequerido = true,
                TabOrder = 20,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "valor",
                DbName = "capitulacion_med.valor",
                Tipo = "long",
                Titulo = "Valor",
                EsClave = true,
                EsRequerido = true,
                TabOrder = 30,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = new[] { "1", "1/2", "2/3", "3" }
            },
            new DataWindowColumn
            {
                Nombre = "medicamento2",
                DbName = "medicamento2",
                Tipo = "char(10)",
                Titulo = "Medicamento",
                EsClave = true,
                EsRequerido = true,
                TabOrder = 40,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "valor2",
                DbName = "valor2",
                Tipo = "long",
                Titulo = "Valor",
                EsClave = true,
                EsRequerido = true,
                TabOrder = 50,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = new[] { "1", "1/2", "2/3", "3" }
            }
        };

        // ⇩ Propiedades según SRD ⇩
        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;

        public string Sql => @"
SELECT capitulacion_med.capitulo,
       capitulacion_med.medicamento,
       capitulacion_med.valor,
       capitulacion_med.medicamento medicamento2,
       capitulacion_med.valor valor2
  FROM capitulacion_med
";
    }
}
