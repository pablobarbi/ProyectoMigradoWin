﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class d_perfil : IDataWindowMetadata
    {
        public string DataObject => "d_perfil";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "perfil",
                DbName = "acc_perfiles.perfil",
                Tipo = "char(8)"
            },
            new DataWindowColumn
            {
                Nombre = "nombre",
                DbName = "acc_perfiles.nombre",
                Tipo = "char(20)"
            },
            new DataWindowColumn
            {
                Nombre = "bitmap",
                DbName = "acc_perfiles.bitmap",
                Tipo = "char(40)"
            }
        };

        public string Sql => @"
SELECT dba.acc_perfiles.perfil,
       dba.acc_perfiles.nombre,
       dba.acc_perfiles.bitmap
  FROM dba.acc_perfiles
 WHERE dba.acc_perfiles.perfil = :perfil
";

        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
