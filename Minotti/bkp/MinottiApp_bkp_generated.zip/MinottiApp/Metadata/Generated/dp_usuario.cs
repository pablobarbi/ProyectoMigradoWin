﻿using Minotti.Metadata;
using System;
using System.Collections.Generic;

namespace Minotti.Metadata.Generated
{
    public class dp_usuario : IDataWindowMetadata
    {
        public string DataObject => "dp_usuario";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "usuario",
                DbName = "usuario",
                Tipo = "char(5)",
                Titulo = "Usuario",
                EsClave = false,
                EsClavePrimaria = false,
                EsIdentity = false,
                EsRequerido = false,
                TabOrder = 10,
                Valores = Array.Empty<string>()
            }
        };

        // ⇩ Metadata funcional no definida en el SRD ⇩
        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;

        // ⇩ No hay SQL retrieve en el SRD ⇩
        public string Sql => string.Empty;
    }
}
