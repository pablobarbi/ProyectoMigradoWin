﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    /// <summary>
    /// Metadata para dk_pacientes
    /// </summary>
    public class dk_pacientes : IDataWindowMetadata
    {
        public string DataObject => "dk_pacientes";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "paciente",
                DbName = "pacientes.paciente",
                Tipo = "long",
                EsClave = true,
                EsClavePrimaria = true,
                TabOrder = 32766
            },
            new DataWindowColumn
            {
                Nombre = "nombre",
                DbName = "pacientes.nombre",
                Tipo = "char(50)",
                TabOrder = 32766
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
