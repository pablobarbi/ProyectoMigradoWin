﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class d_reperto_total_diagnosticos : IDataWindowMetadata
    {
        public string DataObject => "d_reperto_total_diagnosticos";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "reperto_total",
                DbName = "reperto_total_diag.reperto_total",
                Tipo = "decimal(0)"
            },
            new DataWindowColumn
            {
                Nombre = "fecha",
                DbName = "reperto_total_diag.fecha",
                Tipo = "date"
            },
            new DataWindowColumn
            {
                Nombre = "comentario",
                DbName = "reperto_total_diag.comentario",
                Tipo = "char(50)"
            },
            new DataWindowColumn
            {
                Nombre = "paciente",
                DbName = "reperto_total_diag.paciente",
                Tipo = "long"
            },
            new DataWindowColumn
            {
                Nombre = "marca",
                DbName = "reperto_total_diag.marca",
                Tipo = "char(1)"
            }
        };

        public string Sql => @"
SELECT reperto_total_diag.reperto_total,
       reperto_total_diag.fecha,
       reperto_total_diag.comentario,
       reperto_total_diag.paciente,
       reperto_total_diag.marca
  FROM reperto_total_diag
 WHERE reperto_total_diag.reperto_total = :reperto_total
";

        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
