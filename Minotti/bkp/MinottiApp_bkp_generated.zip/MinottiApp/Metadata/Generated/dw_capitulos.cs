﻿using System.Collections.Generic;

namespace Minotti.Metadata.Generated
{
    public class dw_capitulos : IDataWindowMetadata
    {
        public string DataObject => "dw_capitulos";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn("capitulo", "decimal"),
            new DataWindowColumn("nombre", "string")
        };

        public string sql => @"
SELECT 99 AS capitulo,
       ' TODOS' AS nombre
  FROM capitulos
UNION
SELECT capitulos.capitulo,
       capitulos.nombre
  FROM capitulos
 ORDER BY 2
";

        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
