﻿using System.Collections.Generic;

namespace Minotti.Metadata.Generated
{
    public class duo_capitulaciones_med : IDataWindowMetadata
    {
        public string DataObject => "duo_capitulaciones_med";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn("capitulo", "decimal(0)")
            {
                DbName = "capitulacion_med.capitulo",
                EsClave = true
            },
            new DataWindowColumn("rubrica", "decimal(0)")
            {
                DbName = "capitulacion_med.rubrica",
                EsClave = true
            },
            new DataWindowColumn("medicamento", "char(10)")
            {
                DbName = "capitulacion_med.medicamento",
                EsClave = true
            },
            new DataWindowColumn("valor", "long")
            {
                DbName = "capitulacion_med.valor"
            }
        };

        public string Sql => @"
SELECT capitulacion_med.capitulo,
       capitulacion_med.rubrica,
       capitulacion_med.medicamento,
       capitulacion_med.valor
  FROM capitulacion_med
 WHERE capitulacion_med.capitulo = :capitulo
   AND capitulacion_med.rubrica = :rubrica
";

        // --- Metadata inferida estrictamente del SRD ---
        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
