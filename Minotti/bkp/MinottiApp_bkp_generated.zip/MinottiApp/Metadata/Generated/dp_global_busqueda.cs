﻿using Minotti.Metadata;
using System;
using System.Collections.Generic;

namespace Minotti.Metadata.Generated
{
    public class dp_global_busqueda : IDataWindowMetadata
    {
        public string DataObject => "dp_global_busqueda";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "campo",
                DbName = "campo",
                Tipo = "char(255)",
                Titulo = "Campo",
                EsClave = true,
                EsRequerido = false,
                TabOrder = 10,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            }
        };

        // ⇩ NO hay información en el SRD para estas propiedades ⇩
        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;

        // DataWindow sin retrieve (input puro)
        public string Sql => string.Empty;
    }
}
