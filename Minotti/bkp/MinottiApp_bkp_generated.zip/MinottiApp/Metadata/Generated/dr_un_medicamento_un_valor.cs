﻿using Minotti.Metadata;
using System.Collections.Generic;

namespace MinottiApp.Metadata.Generated
{
    public class dr_un_medicamento_un_valor : IDataWindowMetadata
    {
        public string DataObject => "dr_un_medicamento_un_valor";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn("capitulo_nombre", "char(255)") { DbName = "capitulaciones_matriz.capitulo_nombre" },
            new DataWindowColumn("rubrica_nombre", "char(255)") { DbName = "capitulaciones_matriz.rubrica_nombre" },
            new DataWindowColumn("subrubrica_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica_nombre" },
            new DataWindowColumn("subrubrica01_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica01_nombre" },
            new DataWindowColumn("subrubrica02_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica02_nombre" },
            new DataWindowColumn("subrubrica03_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica03_nombre" },
            new DataWindowColumn("subrubrica04_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica04_nombre" },
            new DataWindowColumn("subrubrica05_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica05_nombre" },
            new DataWindowColumn("subrubrica06_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica06_nombre" },
            new DataWindowColumn("subrubrica07_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica07_nombre" },
            new DataWindowColumn("subrubrica08_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica08_nombre" },
            new DataWindowColumn("subrubrica09_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica09_nombre" },
            new DataWindowColumn("subrubrica10_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica10_nombre" },
            new DataWindowColumn("valor", "long") { DbName = "capitulacion_med.valor" }
        };

        public string Sql => @"
SELECT cap.capitulo_nombre,
       cap.rubrica_nombre,
       cap.subrubrica_nombre,
       cap.subrubrica01_nombre,
       cap.subrubrica02_nombre,
       cap.subrubrica03_nombre,
       cap.subrubrica04_nombre,
       cap.subrubrica05_nombre,
       cap.subrubrica06_nombre,
       cap.subrubrica07_nombre,
       cap.subrubrica08_nombre,
       cap.subrubrica09_nombre,
       cap.subrubrica10_nombre,
       cm.valor
  FROM capitulaciones_matriz cap,
       capitulacion_med cm
 WHERE ((cap.capitulo = :capitulo) OR (99 = :capitulo))
   AND cap.capitulo = cm.capitulo
   AND cap.rubrica = cm.rubrica
   AND cm.medicamento = :medicamento
   AND cm.valor = :valor

UNION
SELECT cap.capitulo_nombre,
       cap.rubrica_nombre,
       cap.subrubrica_nombre,
       cap.subrubrica01_nombre,
       cap.subrubrica02_nombre,
       cap.subrubrica03_nombre,
       cap.subrubrica04_nombre,
       cap.subrubrica05_nombre,
       cap.subrubrica06_nombre,
       cap.subrubrica07_nombre,
       cap.subrubrica08_nombre,
       cap.subrubrica09_nombre,
       cap.subrubrica10_nombre,
       cm.valor
  FROM capitulaciones_matriz cap,
       rubricacion_med cm
 WHERE ((cap.capitulo = :capitulo) OR (99 = :capitulo))
   AND cap.rubrica = cm.rubrica
   AND cap.subrubrica = cm.subrubrica
   AND cm.medicamento = :medicamento
   AND cm.valor = :valor

UNION
SELECT cap.capitulo_nombre,
       cap.rubrica_nombre,
       cap.subrubrica_nombre,
       cap.subrubrica01_nombre,
       cap.subrubrica02_nombre,
       cap.subrubrica03_nombre,
       cap.subrubrica04_nombre,
       cap.subrubrica05_nombre,
       cap.subrubrica06_nombre,
       cap.subrubrica07_nombre,
       cap.subrubrica08_nombre,
       cap.subrubrica09_nombre,
       cap.subrubrica10_nombre,
       cm.valor
  FROM capitulaciones_matriz cap,
       subrubricacion_med cm
 WHERE ((cap.capitulo = :capitulo) OR (99 = :capitulo))
   AND cap.subrubrica = cm.subrubrica_padre
   AND cap.subrubrica01 = cm.subrubrica_hija
   AND cm.medicamento = :medicamento
   AND cm.valor = :valor

UNION
SELECT cap.capitulo_nombre,
       cap.rubrica_nombre,
       cap.subrubrica_nombre,
       cap.subrubrica01_nombre,
       cap.subrubrica02_nombre,
       cap.subrubrica03_nombre,
       cap.subrubrica04_nombre,
       cap.subrubrica05_nombre,
       cap.subrubrica06_nombre,
       cap.subrubrica07_nombre,
       cap.subrubrica08_nombre,
       cap.subrubrica09_nombre,
       cap.subrubrica10_nombre,
       cm.valor
  FROM capitulaciones_matriz cap,
       subrubricacion_med cm
 WHERE ((cap.capitulo = :capitulo) OR (99 = :capitulo))
   AND cap.subrubrica01 = cm.subrubrica_padre
   AND cap.subrubrica02 = cm.subrubrica_hija
   AND cm.medicamento = :medicamento
   AND cm.valor = :valor

UNION
SELECT cap.capitulo_nombre,
       cap.rubrica_nombre,
       cap.subrubrica_nombre,
       cap.subrubrica01_nombre,
       cap.subrubrica02_nombre,
       cap.subrubrica03_nombre,
       cap.subrubrica04_nombre,
       cap.subrubrica05_nombre,
       cap.subrubrica06_nombre,
       cap.subrubrica07_nombre,
       cap.subrubrica08_nombre,
       cap.subrubrica09_nombre,
       cap.subrubrica10_nombre,
       cm.valor
  FROM capitulaciones_matriz cap,
       subrubricacion_med cm
 WHERE ((cap.capitulo = :capitulo) OR (99 = :capitulo))
   AND cap.subrubrica02 = cm.subrubrica_padre
   AND cap.subrubrica03 = cm.subrubrica_hija
   AND cm.medicamento = :medicamento
   AND cm.valor = :valor

UNION
SELECT cap.capitulo_nombre,
       cap.rubrica_nombre,
       cap.subrubrica_nombre,
       cap.subrubrica01_nombre,
       cap.subrubrica02_nombre,
       cap.subrubrica03_nombre,
       cap.subrubrica04_nombre,
       cap.subrubrica05_nombre,
       cap.subrubrica06_nombre,
       cap.subrubrica07_nombre,
       cap.subrubrica08_nombre,
       cap.subrubrica09_nombre,
       cap.subrubrica10_nombre,
       cm.valor
  FROM capitulaciones_matriz cap,
       subrubricacion_med cm
 WHERE ((cap.capitulo = :capitulo) OR (99 = :capitulo))
   AND cap.subrubrica03 = cm.subrubrica_padre
   AND cap.subrubrica04 = cm.subrubrica_hija
   AND cm.medicamento = :medicamento
   AND cm.valor = :valor

UNION
SELECT cap.capitulo_nombre,
       cap.rubrica_nombre,
       cap.subrubrica_nombre,
       cap.subrubrica01_nombre,
       cap.subrubrica02_nombre,
       cap.subrubrica03_nombre,
       cap.subrubrica04_nombre,
       cap.subrubrica05_nombre,
       cap.subrubrica06_nombre,
       cap.subrubrica07_nombre,
       cap.subrubrica08_nombre,
       cap.subrubrica09_nombre,
       cap.subrubrica10_nombre,
       cm.valor
  FROM capitulaciones_matriz cap,
       subrubricacion_med cm
 WHERE ((cap.capitulo = :capitulo) OR (99 = :capitulo))
   AND cap.subrubrica04 = cm.subrubrica_padre
   AND cap.subrubrica05 = cm.subrubrica_hija
   AND cm.medicamento = :medicamento
   AND cm.valor = :valor

UNION
SELECT cap.capitulo_nombre,
       cap.rubrica_nombre,
       cap.subrubrica_nombre,
       cap.subrubrica01_nombre,
       cap.subrubrica02_nombre,
       cap.subrubrica03_nombre,
       cap.subrubrica04_nombre,
       cap.subrubrica05_nombre,
       cap.subrubrica06_nombre,
       cap.subrubrica07_nombre,
       cap.subrubrica08_nombre,
       cap.subrubrica09_nombre,
       cap.subrubrica10_nombre,
       cm.valor
  FROM capitulaciones_matriz cap,
       subrubricacion_med cm
 WHERE ((cap.capitulo = :capitulo) OR (99 = :capitulo))
   AND cap.subrubrica05 = cm.subrubrica_padre
   AND cap.subrubrica06 = cm.subrubrica_hija
   AND cm.medicamento = :medicamento
   AND cm.valor = :valor

UNION
SELECT cap.capitulo_nombre,
       cap.rubrica_nombre,
       cap.subrubrica_nombre,
       cap.subrubrica01_nombre,
       cap.subrubrica02_nombre,
       cap.subrubrica03_nombre,
       cap.subrubrica04_nombre,
       cap.subrubrica05_nombre,
       cap.subrubrica06_nombre,
       cap.subrubrica07_nombre,
       cap.subrubrica08_nombre,
       cap.subrubrica09_nombre,
       cap.subrubrica10_nombre,
       cm.valor
  FROM capitulaciones_matriz cap,
       subrubricacion_med cm
 WHERE ((cap.capitulo = :capitulo) OR (99 = :capitulo))
   AND cap.subrubrica06 = cm.subrubrica_padre
   AND cap.subrubrica07 = cm.subrubrica_hija
   AND cm.medicamento = :medicamento
   AND cm.valor = :valor

UNION
SELECT cap.capitulo_nombre,
       cap.rubrica_nombre,
       cap.subrubrica_nombre,
       cap.subrubrica01_nombre,
       cap.subrubrica02_nombre,
       cap.subrubrica03_nombre,
       cap.subrubrica04_nombre,
       cap.subrubrica05_nombre,
       cap.subrubrica06_nombre,
       cap.subrubrica07_nombre,
       cap.subrubrica08_nombre,
       cap.subrubrica09_nombre,
       cap.subrubrica10_nombre,
       cm.valor
  FROM capitulaciones_matriz cap,
       subrubricacion_med cm
 WHERE ((cap.capitulo = :capitulo) OR (99 = :capitulo))
   AND cap.subrubrica07 = cm.subrubrica_padre
   AND cap.subrubrica08 = cm.subrubrica_hija
   AND cm.medicamento = :medicamento
   AND cm.valor = :valor

UNION
SELECT cap.capitulo_nombre,
       cap.rubrica_nombre,
       cap.subrubrica_nombre,
       cap.subrubrica01_nombre,
       cap.subrubrica02_nombre,
       cap.subrubrica03_nombre,
       cap.subrubrica04_nombre,
       cap.subrubrica05_nombre,
       cap.subrubrica06_nombre,
       cap.subrubrica07_nombre,
       cap.subrubrica08_nombre,
       cap.subrubrica09_nombre,
       cap.subrubrica10_nombre,
       cm.valor
  FROM capitulaciones_matriz cap,
       subrubricacion_med cm
 WHERE ((cap.capitulo = :capitulo) OR (99 = :capitulo))
   AND cap.subrubrica08 = cm.subrubrica_padre
   AND cap.subrubrica09 = cm.subrubrica_hija
   AND cm.medicamento = :medicamento
   AND cm.valor = :valor

UNION
SELECT cap.capitulo_nombre,
       cap.rubrica_nombre,
       cap.subrubrica_nombre,
       cap.subrubrica01_nombre,
       cap.subrubrica02_nombre,
       cap.subrubrica03_nombre,
       cap.subrubrica04_nombre,
       cap.subrubrica05_nombre,
       cap.subrubrica06_nombre,
       cap.subrubrica07_nombre,
       cap.subrubrica08_nombre,
       cap.subrubrica09_nombre,
       cap.subrubrica10_nombre,
       cm.valor
  FROM capitulaciones_matriz cap,
       subrubricacion_med cm
 WHERE ((cap.capitulo = :capitulo) OR (99 = :capitulo))
   AND cap.subrubrica09 = cm.subrubrica_padre
   AND cap.subrubrica10 = cm.subrubrica_hija
   AND cm.medicamento = :medicamento
   AND cm.valor = :valor

ORDER BY 1, 2, 3
";

        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
