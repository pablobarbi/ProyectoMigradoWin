﻿using System.Collections.Generic;
using System.Security.Principal;

namespace Minotti.Metadata.Generated
{
    public class dw_operaciones : IDataWindowMetadata
    {
        public string DataObject => "dw_operaciones";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn("operacion", "string")
            {
                EsClavePrimaria= true,
                EsIdentity= false
            },
            new DataWindowColumn("nombre", "string")
            {
                EsClavePrimaria= false,
                EsIdentity= false
            }
        };

        public string sql => @"
SELECT dba.acc_operaciones.operacion,
       dba.acc_operaciones.nombre
  FROM dba.acc_operaciones
 ORDER BY dba.acc_operaciones.nombre
";

        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
