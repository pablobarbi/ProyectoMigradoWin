﻿using Minotti.Metadata;

namespace MinottiApp.Metadata.Generated
{
    public class dl_medicamentos_desde_hasta : IDataWindowMetadata
    {
        public string DataObject => "dl_medicamentos_desde_hasta";

        public List<DataWindowColumn> Columns { get; } = new()
        {
            new DataWindowColumn("medicamento", "char(10)")
            {
                DbName = "medicamentos.medicamento",
                EsClave = true
            },
            new DataWindowColumn("descripcion", "char(50)")
            {
                DbName = "medicamentos.descripcion"
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => true;
    }
}
