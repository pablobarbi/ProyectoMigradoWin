﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class dl_pacientes_diagnosticos_tipo_fecha : IDataWindowMetadata
    {
        public string DataObject => "dl_pacientes_diagnosticos_tipo_fecha";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "paciente",
                DbName = "diagnosticos.paciente",
                Tipo = "long",
                Titulo = "Paciente",
                EsClave = true,
                EsRequerido = false,
                ObjetoSeleccion = "dw_pacientes",
                Operacion = null,
                NivelOperacion = null,
                TabOrder = 32766,
                EsClavePrimaria = true,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "diagnostico",
                DbName = "diagnosticos.diagnostico",
                Tipo = "long",
                Titulo = string.Empty,
                EsClave = true,
                EsRequerido = false,
                ObjetoSeleccion = null,
                Operacion = null,
                NivelOperacion = null,
                TabOrder = null,
                EsClavePrimaria = true,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "fecha_visita",
                DbName = "diagnosticos.fecha_visita",
                Tipo = "date",
                Titulo = "Fecha de visita",
                EsClave = false,
                EsRequerido = false,
                ObjetoSeleccion = null,
                Operacion = null,
                NivelOperacion = null,
                TabOrder = 32766,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "curado",
                DbName = "diagnosticos.curado",
                Tipo = "char(1)",
                Titulo = "Curado",
                EsClave = false,
                EsRequerido = false,
                ObjetoSeleccion = null,
                Operacion = null,
                NivelOperacion = null,
                TabOrder = 32766,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = new[] { "Si\tS", "No\tN" }
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;

        public string Sql => @"
SELECT diagnosticos.paciente,
       diagnosticos.diagnostico,
       diagnosticos.fecha_visita,
       diagnosticos.curado
  FROM diagnosticos
 WHERE (   (:tipo_diagnostico = 'N') AND (diagnosticos.diag_nosologico like :diagnostico)
        OR (:tipo_diagnostico = 'M') AND (diagnosticos.diag_medicamentoso like :diagnostico)
        OR (:tipo_diagnostico = 'I') AND (diagnosticos.diag_miasmatico like :diagnostico)
        OR (:tipo_diagnostico = 'O') AND (diagnosticos.diag_otro like :diagnostico) )
   AND diagnosticos.fecha_visita >=
       YMD(SUBSTR(:fecha_desde, 7, 4), SUBSTR(:fecha_desde, 4, 2), SUBSTR(:fecha_desde, 1, 2))
   AND diagnosticos.fecha_visita <=
       YMD(SUBSTR(:fecha_hasta, 7, 4), SUBSTR(:fecha_hasta, 4, 2), SUBSTR(:fecha_hasta, 1, 2))
";
    }
}
