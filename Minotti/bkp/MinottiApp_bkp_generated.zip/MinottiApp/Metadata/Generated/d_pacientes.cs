﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class d_pacientes : IDataWindowMetadata
    {
        public string DataObject => "d_pacientes";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "paciente",
                DbName = "pacientes.paciente",
                Tipo = "long",
                EsClavePrimaria = true,
                EsIdentity = true
            },
            new DataWindowColumn
            {
                Nombre = "nombre",
                DbName = "pacientes.nombre",
                Tipo = "char(50)"
            },
            new DataWindowColumn
            {
                Nombre = "domicilio",
                DbName = "pacientes.domicilio",
                Tipo = "char(50)"
            },
            new DataWindowColumn
            {
                Nombre = "telefono",
                DbName = "pacientes.telefono",
                Tipo = "char(15)"
            },
            new DataWindowColumn
            {
                Nombre = "sexo",
                DbName = "pacientes.sexo",
                Tipo = "char(1)"
            },
            new DataWindowColumn
            {
                Nombre = "fecha_nacimiento",
                DbName = "pacientes.fecha_nacimiento",
                Tipo = "date"
            },
            new DataWindowColumn
            {
                Nombre = "ultima_visita",
                DbName = "pacientes.ultima_visita",
                Tipo = "date"
            },
            new DataWindowColumn
            {
                Nombre = "ocupacion",
                DbName = "pacientes.ocupacion",
                Tipo = "char(50)"
            },
            new DataWindowColumn
            {
                Nombre = "estado_civil",
                DbName = "pacientes.estado_civil",
                Tipo = "long"
            },
            new DataWindowColumn
            {
                Nombre = "cantidad_hijos",
                DbName = "pacientes.cantidad_hijos",
                Tipo = "long"
            }
        };

        public string Sql => @"
SELECT pacientes.paciente,
       pacientes.nombre,
       pacientes.domicilio,
       pacientes.telefono,
       pacientes.sexo,
       pacientes.fecha_nacimiento,
       pacientes.ultima_visita,
       pacientes.ocupacion,
       pacientes.estado_civil,
       pacientes.cantidad_hijos
  FROM pacientes
 WHERE pacientes.paciente = :paciente
";

        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
