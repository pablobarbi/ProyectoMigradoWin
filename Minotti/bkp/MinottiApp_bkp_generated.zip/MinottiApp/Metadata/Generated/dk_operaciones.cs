﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    /// <summary>
    /// Metadata para dk_operaciones
    /// </summary>
    public class dk_operaciones : IDataWindowMetadata
    {
        public string DataObject => "dk_operaciones";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "operacion",
                DbName = "acc_operaciones.operacion",
                Tipo = "char(5)",
                TabOrder = 32766
            },
            new DataWindowColumn
            {
                Nombre = "nombre",
                DbName = "acc_operaciones.nombre",
                Tipo = "char(30)",
                TabOrder = 32766
            },
            new DataWindowColumn
            {
                Nombre = "bitmap",
                DbName = "acc_operaciones.bitmap",
                Tipo = "char(40)",
                TabOrder = 32766
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
