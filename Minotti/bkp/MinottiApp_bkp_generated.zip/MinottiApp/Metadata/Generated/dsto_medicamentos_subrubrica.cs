﻿using Minotti.Metadata;
using System.Collections.Generic;

namespace MinottiApp.Metadata.Generated
{
    public class dsto_medicamentos_subrubrica : IDataWindowMetadata
    {
        public string DataObject => "dsto_medicamentos_subrubrica";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn("rubrica", "decimal(0)")
            {
                DbName = "rubricacion_med.rubrica",
                EsClave = true
            },
            new DataWindowColumn("subrubrica", "decimal(0)")
            {
                DbName = "rubricacion_med.subrubrica",
                EsClave = true
            },
            new DataWindowColumn("medicamento", "char(10)")
            {
                DbName = "rubricacion_med.medicamento",
                EsClave = true
            },
            new DataWindowColumn("valor", "long")
            {
                DbName = "rubricacion_med.valor"
            }
        };

        public string Sql => @"
SELECT rubricacion_med.rubrica,
       rubricacion_med.subrubrica,
       rubricacion_med.medicamento,
       rubricacion_med.valor
  FROM rubricacion_med
 WHERE rubricacion_med.rubrica = :rubrica
   AND rubricacion_med.subrubrica = :subrubrica
";

        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
