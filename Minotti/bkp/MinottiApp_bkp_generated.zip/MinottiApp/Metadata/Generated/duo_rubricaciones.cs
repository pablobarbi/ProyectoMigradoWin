﻿using System.Collections.Generic;

namespace Minotti.Metadata.Generated
{
    public class duo_rubricaciones : IDataWindowMetadata
    {
        public string DataObject => "duo_rubricaciones";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn("rubrica", "decimal(0)")
            {
                DbName = "rubricaciones.rubrica"
            },
            new DataWindowColumn("subrubrica", "decimal(0)")
            {
                DbName = "rubricaciones.subrubrica"
            },
            new DataWindowColumn("posicion", "long")
            {
                DbName = "rubricaciones.posicion"
            },
            new DataWindowColumn("subrubrica_nombre", "char(255)")
            {
                DbName = "subrubricas.nombre"
            }
        };

        public string Sql => @"
SELECT rubricaciones.rubrica,
       rubricaciones.subrubrica,
       rubricaciones.posicion,
       subrubricas.nombre
  FROM rubricaciones,
       subrubricas
 WHERE rubricaciones.subrubrica = subrubricas.subrubrica
   AND rubricaciones.rubrica = :rubrica
 ORDER BY rubricaciones.posicion
";

        public Dictionary<string, string> Arguments => new()
        {
            { "rubrica", "string" }
        };

        // --- Metadata ---
        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
