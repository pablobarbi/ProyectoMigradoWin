﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class d_agregar_rubricas : IDataWindowMetadata
    {
        public string DataObject => "d_agregar_rubricas";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "nombre",
                Tipo = "char(255)",
                Titulo = "Rubrica:",
                EsClave = false,
                EsRequerido = false,
                //Estilos = null,
                ObjetoSeleccion = null,
                Operacion = null,
                NivelOperacion = null,
                TabOrder = 10
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;

        public string SQL = @"SELECT rubricas.nombre
                                     FROM rubricas";
    }
}
