﻿using System.Collections.Generic;
using System.Security.Principal;

namespace Minotti.Metadata.Generated
{
    public class dw_usuarios : IDataWindowMetadata
    {
        public string DataObject => "dw_usuarios";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn("usuario", "string")
            {
                EsClavePrimaria= true,
                EsIdentity= false
            },
            new DataWindowColumn(
                 "nombre",
                 "string")
            {
                EsClavePrimaria= false,
                EsIdentity= false
            }   
        };

        public string sql => @"
SELECT dba.acc_usuarios.usuario,
       dba.acc_usuarios.nombre
  FROM dba.acc_usuarios
 ORDER BY dba.acc_usuarios.nombre
";

        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
