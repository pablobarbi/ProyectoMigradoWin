﻿using Minotti.Metadata;
using System;
using System.Collections.Generic;

namespace Minotti.Metadata.Generated
{
    public class dp_dos_medicamentos : IDataWindowMetadata
    {
        public string DataObject => "dp_dos_medicamentos";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "capitulo",
                DbName = "capitulacion_med.capitulo",
                Tipo = "decimal(0)",
                Titulo = "Capítulo",
                EsClave = true,
                EsRequerido = true,
                TabOrder = 10,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "medicamento",
                DbName = "capitulacion_med.medicamento",
                Tipo = "char(10)",
                Titulo = "Medicamento",
                EsClave = true,
                EsRequerido = true,
                TabOrder = 20,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "medicamento2",
                DbName = "medicamento2",
                Tipo = "char(10)",
                Titulo = "Medicamento",
                EsClave = true,
                EsRequerido = true,
                TabOrder = 40,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            }
        };

        // ⇩ El SRD no define nada adicional ⇩
        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;

        public string Sql => @"
SELECT capitulacion_med.capitulo,
       capitulacion_med.medicamento,
       capitulacion_med.medicamento medicamento2
  FROM capitulacion_med
";
    }
}
