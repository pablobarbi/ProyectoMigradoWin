﻿using System.Collections.Generic;
using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class dr_global_medicamentos : IDataWindowMetadata
    {
        public string DataObject => "dr_global_medicamentos";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "medicamento",
                DbName = "medicamentos.medicamento",
                Tipo = "char(10)",
                Titulo = "Medicamento",
                EsClave = true,
                EsClavePrimaria = true,
                TabOrder = 1
            },
            new DataWindowColumn
            {
                Nombre = "descripcion",
                DbName = "medicamentos.descripcion",
                Tipo = "char(50)",
                Titulo = "Descripcion",
                TabOrder = 2
            },
            new DataWindowColumn
            {
                Nombre = "observaciones",
                DbName = "medicamentos.observaciones",
                Tipo = "char(32766)",
                Titulo = "Observaciones",
                TabOrder = 3
            }
        };

        public string[] Estilos => System.Array.Empty<string>();

        public string[] SeleccionFila => System.Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;

        public string Sql => @"
SELECT medicamentos.medicamento,
       medicamentos.descripcion,
       medicamentos.observaciones
  FROM medicamentos
 WHERE medicamentos.descripcion like :campo  OR  
       medicamentos.observaciones like :campo
";
    }
}
