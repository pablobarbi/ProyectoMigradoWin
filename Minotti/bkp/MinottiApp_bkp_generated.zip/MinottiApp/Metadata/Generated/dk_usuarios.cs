﻿using Minotti.Metadata;

namespace MinottiApp.Metadata.Generated
{
    public class dk_usuarios : IDataWindowMetadata
    {
        public string DataObject => "dk_usuarios";

        public List<DataWindowColumn> Columns { get; } = new()
        {
            new DataWindowColumn("usuario", "char(5)")
            {
                DbName = "acc_usuarios.usuario",
                EsClave = true
            },
            new DataWindowColumn("nombre", "char(50)")
            {
                DbName = "acc_usuarios.nombre"
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
