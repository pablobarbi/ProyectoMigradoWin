﻿using System.Collections.Generic;
using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class dr_modulos : IDataWindowMetadata
    {
        public string DataObject => "dr_modulos";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "modulo",
                DbName = "acc_modulos.modulo",
                Tipo = "char(5)",
                Titulo = "Módulo",
                EsClave = true,
                EsClavePrimaria = true,
                EsIdentity = false,
                TabOrder = 10
            },
            new DataWindowColumn
            {
                Nombre = "nombre",
                DbName = "acc_modulos.nombre",
                Tipo = "char(20)",
                Titulo = "Nombre",
                TabOrder = 20
            },
            new DataWindowColumn
            {
                Nombre = "bitmap",
                DbName = "acc_modulos.bitmap",
                Tipo = "char(40)",
                Titulo = "Bitmap"
            }
        };

        public string[] Estilos => System.Array.Empty<string>();

        public string[] SeleccionFila => System.Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;

        public string Sql => @"
SELECT dba.acc_modulos.modulo,
       dba.acc_modulos.nombre,
       dba.acc_modulos.bitmap
  FROM dba.acc_modulos
 ORDER BY dba.acc_modulos.nombre
";
    }
}
