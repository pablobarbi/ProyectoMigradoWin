﻿using Minotti.Metadata;

namespace MinottiApp.Metadata.Generated
{
    public class dk_submodulos : IDataWindowMetadata
    {
        public string DataObject => "dk_submodulos";

        public List<DataWindowColumn> Columns { get; } = new()
        {
            new DataWindowColumn("submodulo", "char(8)") { EsClave = true },
            new DataWindowColumn("nombre", "char(20)"),
            new DataWindowColumn("bitmap", "char(40)")
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
