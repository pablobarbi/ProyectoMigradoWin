﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    /// <summary>
    /// Metadata para dk_modulos
    /// </summary>
    public class dk_modulos : IDataWindowMetadata
    {
        public string DataObject => "dk_modulos";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "modulo",
                DbName = "acc_modulos.modulo",
                Tipo = "char(5)",
                TabOrder = 32766
            },
            new DataWindowColumn
            {
                Nombre = "nombre",
                DbName = "acc_modulos.nombre",
                Tipo = "char(40)",
                TabOrder = 32766
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
