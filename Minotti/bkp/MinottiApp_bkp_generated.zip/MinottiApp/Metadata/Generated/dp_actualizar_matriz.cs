﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class dp_actualizar_matriz : IDataWindowMetadata
    {
        public string DataObject => "dp_actualizar_matriz";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "variable",
                DbName = "variable",
                Tipo = "char(10)",
                Titulo = string.Empty,
                EsClave = false,
                EsRequerido = false,
                TabOrder = null,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            }
        };

        // ⇩ El SRD no define nada de esto ⇩
        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;

        // No hay retrieve en el SRD
        public string Sql => string.Empty;
    }
}
