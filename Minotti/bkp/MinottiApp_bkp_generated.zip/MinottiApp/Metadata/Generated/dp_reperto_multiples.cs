﻿using Minotti.Metadata;
using System;
using System.Collections.Generic;

namespace Minotti.Metadata.Generated
{
    public class dp_reperto_multiples : IDataWindowMetadata
    {
        public string DataObject => "dp_reperto_multiples";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "reperto_desde",
                DbName = "reperto_total_diag.reperto_desde",
                Tipo = "decimal(0)",
                Titulo = "Desde",
                EsClave = true,
                EsClavePrimaria = false,
                EsIdentity = false,
                TabOrder = 10,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "reperto_hasta",
                DbName = "reperto_total_diag.reperto_hasta",
                Tipo = "decimal(0)",
                Titulo = "Hasta",
                EsClave = true,
                EsClavePrimaria = false,
                EsIdentity = false,
                TabOrder = 20,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "fecha_desde",
                DbName = "reperto_total_diag.fecha_desde",
                Tipo = "date",
                Titulo = "Desde",
                EsClave = true,
                EsClavePrimaria = false,
                EsIdentity = false,
                TabOrder = 30,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "fecha_hasta",
                DbName = "reperto_total_diag.fecha_hasta",
                Tipo = "date",
                Titulo = "Hasta",
                EsClave = true,
                EsClavePrimaria = false,
                EsIdentity = false,
                TabOrder = 40,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "paciente",
                DbName = "reperto_total_diag.paciente",
                Tipo = "long",
                Titulo = "Paciente",
                EsClave = true,
                EsClavePrimaria = false,
                EsIdentity = false,
                TabOrder = 50,
                Valores = Array.Empty<string>()
            }
        };

        // ⇩ No hay metadata funcional declarada en el SRD ⇩
        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;

        public string Sql => @"
SELECT reperto_total_diag.reperto_total AS reperto_desde,
       reperto_total_diag.reperto_total AS reperto_hasta,
       reperto_total_diag.fecha AS fecha_desde,
       reperto_total_diag.fecha AS fecha_hasta,
       reperto_total_diag.paciente
  FROM reperto_total_diag
";
    }
}
