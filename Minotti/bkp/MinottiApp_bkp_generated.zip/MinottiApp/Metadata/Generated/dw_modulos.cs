﻿using System.Collections.Generic;
using System.Security.Principal;

namespace Minotti.Metadata.Generated
{
    public class dw_modulos : IDataWindowMetadata
    {
        public string DataObject => "dw_modulos";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn("modulo","string")
            {
                    EsClavePrimaria= true,
                EsIdentity= false
            },
            new DataWindowColumn("nombre", "string")
            {
                EsClavePrimaria= false,
                EsIdentity= false
            }
        };

        public string sql => @"
SELECT dba.acc_modulos.modulo,
       dba.acc_modulos.nombre
  FROM dba.acc_modulos
 ORDER BY dba.acc_modulos.nombre
";

        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
