﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    /// <summary>
    /// Metadata para d_submodulos
    /// </summary>
    public class d_submodulos : IDataWindowMetadata
    {
        public string DataObject => "d_submodulos";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "submodulo",
                DbName = "acc_submodulos.submodulo",
                Tipo = "char(8)",
                EsClave = true
            },
            new DataWindowColumn
            {
                Nombre = "nombre",
                DbName = "acc_submodulos.nombre",
                Tipo = "char(20)",
                EsRequerido = true
            },
            new DataWindowColumn
            {
                Nombre = "bitmap",
                DbName = "acc_submodulos.bitmap",
                Tipo = "char(40)"
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
