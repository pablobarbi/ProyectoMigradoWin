﻿using System.Collections.Generic;
using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class dr_global_diagnosticos : IDataWindowMetadata
    {
        public string DataObject => "dr_global_diagnosticos";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "paciente",
                DbName = "diagnosticos.paciente",
                Tipo = "long",
                Titulo = "Paciente",
                TabOrder = 1
            },
            new DataWindowColumn
            {
                Nombre = "fecha_visita",
                DbName = "diagnosticos.fecha_visita",
                Tipo = "date",
                Titulo = "Fecha Visita",
                TabOrder = 2
            },
            new DataWindowColumn
            {
                Nombre = "diag_nosologico",
                DbName = "diagnosticos.diag_nosologico",
                Tipo = "char(50)",
                Titulo = "Diag Nosologico",
                TabOrder = 3
            },
            new DataWindowColumn
            {
                Nombre = "diag_medicamentoso",
                DbName = "diagnosticos.diag_medicamentoso",
                Tipo = "char(50)",
                Titulo = "Diag Medicamentoso",
                TabOrder = 4
            },
            new DataWindowColumn
            {
                Nombre = "diag_miasmatico",
                DbName = "diagnosticos.diag_miasmatico",
                Tipo = "char(50)",
                Titulo = "Diag Miasmatico",
                TabOrder = 5
            },
            new DataWindowColumn
            {
                Nombre = "diag_otro",
                DbName = "diagnosticos.diag_otro",
                Tipo = "char(50)",
                Titulo = "Diag Otro",
                TabOrder = 6
            }
        };

        public string[] Estilos => System.Array.Empty<string>();

        public string[] SeleccionFila => System.Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => true;

        public string Sql => @"
SELECT diagnosticos.paciente,
       diagnosticos.fecha_visita,
       diagnosticos.diag_nosologico,
       diagnosticos.diag_medicamentoso,
       diagnosticos.diag_miasmatico,
       diagnosticos.diag_otro
  FROM diagnosticos
 WHERE diagnosticos.diag_nosologico like :campo  OR  
       diagnosticos.diag_medicamentoso like :campo  OR  
       diagnosticos.diag_miasmatico like :campo  OR  
       diagnosticos.diag_otro like :campo
";
    }
}
