﻿using System.Collections.Generic;

namespace Minotti.Metadata.Generated
{
    public class dw_calendar_anterior : IDataWindowMetadata
    {
        public string DataObject => "dw_calendar_anterior";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn("t1", "number"),
            new DataWindowColumn("t2", "number"),
            new DataWindowColumn("t3", "number"),
            new DataWindowColumn("t4", "number"),
            new DataWindowColumn("t5", "number"),
            new DataWindowColumn("t6", "number"),
            new DataWindowColumn("t7", "number"),
            new DataWindowColumn("t8", "number"),
            new DataWindowColumn("t9", "number"),
            new DataWindowColumn("t10", "number"),
            new DataWindowColumn("t11", "number"),
            new DataWindowColumn("t12", "number"),
            new DataWindowColumn("t13", "number"),
            new DataWindowColumn("t14", "number"),
            new DataWindowColumn("t15", "number"),
            new DataWindowColumn("t16", "number"),
            new DataWindowColumn("t17", "number"),
            new DataWindowColumn("t18", "number"),
            new DataWindowColumn("t19", "number"),
            new DataWindowColumn("t20", "number"),
            new DataWindowColumn("t21", "number"),
            new DataWindowColumn("t22", "number"),
            new DataWindowColumn("t23", "number"),
            new DataWindowColumn("t24", "number"),
            new DataWindowColumn("t25", "number"),
            new DataWindowColumn("t26", "number"),
            new DataWindowColumn("t27", "number"),
            new DataWindowColumn("t28", "number"),
            new DataWindowColumn("t29", "number"),
            new DataWindowColumn("t30", "number"),
            new DataWindowColumn("t31", "number"),
            new DataWindowColumn("t32", "number"),
            new DataWindowColumn("t33", "number"),
            new DataWindowColumn("t34", "number"),
            new DataWindowColumn("t35", "number"),
            new DataWindowColumn("t36", "number"),
            new DataWindowColumn("t37", "number"),
            new DataWindowColumn("t38", "number"),
            new DataWindowColumn("t39", "number"),
            new DataWindowColumn("t40", "number"),
            new DataWindowColumn("t41", "number"),
            new DataWindowColumn("t42", "number"),

            new DataWindowColumn("month", "number"),
            new DataWindowColumn("year", "number"),
            new DataWindowColumn("curday", "number")
        };

        // DataWindow sin SQL (visual / calculado)
        public string sql => string.Empty;

        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
