﻿using Minotti.Metadata;
using System.Collections.Generic;

namespace MinottiApp.Metadata.Generated
{
    public class dr_usuarios : IDataWindowMetadata
    {
        public string DataObject => "dr_usuarios";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn("usuario", "char(5)")
            {
                DbName = "acc_usuarios.usuario"
            },
            new DataWindowColumn("nombre", "char(50)")
            {
                DbName = "acc_usuarios.nombre"
            },
            new DataWindowColumn("clave", "char(40)")
            {
                DbName = "acc_usuarios.clave"
            },
            new DataWindowColumn("perfil", "char(5)")
            {
                DbName = "acc_usuarios.perfil"
            },
            new DataWindowColumn("nombre_perfil", "char(20)")
            {
                DbName = "acc_perfiles.nombre_perfil"
            }
        };

        public string Sql => @"SELECT dba.acc_usuarios.usuario,
                                       dba.acc_usuarios.nombre,
                                       dba.acc_usuarios.clave,
                                       dba.acc_usuarios.perfil,
                                       dba.acc_perfiles.nombre nombre_perfil
                                  FROM dba.acc_usuarios,
                                       dba.acc_perfiles
                                 WHERE dba.acc_usuarios.perfil = dba.acc_perfiles.perfil
                                 ORDER BY dba.acc_usuarios.nombre";

        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
