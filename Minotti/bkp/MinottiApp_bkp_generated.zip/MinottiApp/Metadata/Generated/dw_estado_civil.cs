﻿using System.Collections.Generic;
using System.Security.Principal;

namespace Minotti.Metadata.Generated
{
    public class dw_estado_civil : IDataWindowMetadata
    {
        public string DataObject => "dw_estado_civil";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn("estado_civil", "decimal")
            {
                EsClavePrimaria= true,
                EsIdentity= true
            },
            new DataWindowColumn("descripcion", "string")
        };

        public string sql => @"
SELECT mdp_estado_civil.estado_civil,
       mdp_estado_civil.descripcion
  FROM mdp_estado_civil
";

        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
