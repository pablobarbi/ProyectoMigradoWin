﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class dl_usuarios : IDataWindowMetadata
    {
        public string DataObject => "dl_usuarios";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "usuario",
                DbName = "acc_usuarios.usuario",
                Tipo = "char(5)",
                Titulo = "Usuario",
                EsClave = false,
                EsRequerido = false,
                TabOrder = 10,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "nombre",
                DbName = "acc_usuarios.nombre",
                Tipo = "char(50)",
                Titulo = "Nombre",
                EsClave = false,
                EsRequerido = false,
                TabOrder = 20,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "clave",
                DbName = "acc_usuarios.clave",
                Tipo = "char(40)",
                Titulo = string.Empty,
                EsClave = false,
                EsRequerido = false,
                TabOrder = null,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "perfil",
                DbName = "acc_usuarios.perfil",
                Tipo = "char(5)",
                Titulo = "Perfíl",
                EsClave = false,
                EsRequerido = false,
                TabOrder = null,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "nombre_perfil",
                DbName = "acc_perfiles.nombre_perfil",
                Tipo = "char(20)",
                Titulo = "Perfíl",
                EsClave = false,
                EsRequerido = false,
                TabOrder = 32766,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            }
        };

        // ⇩ Solo si el SRD lo define explícitamente ⇩
        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;

        public string Sql => @"
SELECT dba.acc_usuarios.usuario,
       dba.acc_usuarios.nombre,
       dba.acc_usuarios.clave,
       dba.acc_usuarios.perfil,
       dba.acc_perfiles.nombre nombre_perfil
  FROM dba.acc_usuarios,
       dba.acc_perfiles
 WHERE dba.acc_usuarios.perfil = dba.acc_perfiles.perfil
 ORDER BY dba.acc_usuarios.nombre
";
    }
}
