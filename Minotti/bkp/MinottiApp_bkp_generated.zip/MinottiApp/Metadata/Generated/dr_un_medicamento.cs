﻿using System.Collections.Generic;
using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class dr_un_medicamento : IDataWindowMetadata
    {
        public string DataObject => "dr_un_medicamento";

        public List<DataWindowColumn> Columns => new()
        {
            new("capitulo_nombre", "char(255)") { DbName = "capitulaciones_matriz.capitulo_nombre" },
            new("rubrica_nombre", "char(255)") { DbName = "capitulaciones_matriz.rubrica_nombre" },
            new("subrubrica_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica_nombre" },
            new("subrubrica01_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica01_nombre" },
            new("subrubrica02_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica02_nombre" },
            new("subrubrica03_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica03_nombre" },
            new("subrubrica04_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica04_nombre" },
            new("subrubrica05_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica05_nombre" },
            new("subrubrica06_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica06_nombre" },
            new("subrubrica07_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica07_nombre" },
            new("subrubrica08_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica08_nombre" },
            new("subrubrica09_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica09_nombre" },
            new("subrubrica10_nombre", "char(255)") { DbName = "capitulaciones_matriz.subrubrica10_nombre" },
            new("valor", "long") { DbName = "capitulacion_med.valor" }
        };

        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;

        public string Sql => @"
SELECT cap.capitulo_nombre,
       cap.rubrica_nombre,
       cap.subrubrica_nombre,
       cap.subrubrica01_nombre,
       cap.subrubrica02_nombre,
       cap.subrubrica03_nombre,
       cap.subrubrica04_nombre,
       cap.subrubrica05_nombre,
       cap.subrubrica06_nombre,
       cap.subrubrica07_nombre,
       cap.subrubrica08_nombre,
       cap.subrubrica09_nombre,
       cap.subrubrica10_nombre,
       cm.valor
  FROM capitulaciones_matriz cap,
       capitulacion_med cm
 WHERE ((cap.capitulo = :capitulo) OR (99 = :capitulo))
   AND cap.capitulo = cm.capitulo
   AND cap.rubrica = cm.rubrica
   AND cm.medicamento = :medicamento

UNION
SELECT cap.capitulo_nombre,
       cap.rubrica_nombre,
       cap.subrubrica_nombre,
       cap.subrubrica01_nombre,
       cap.subrubrica02_nombre,
       cap.subrubrica03_nombre,
       cap.subrubrica04_nombre,
       cap.subrubrica05_nombre,
       cap.subrubrica06_nombre,
       cap.subrubrica07_nombre,
       cap.subrubrica08_nombre,
       cap.subrubrica09_nombre,
       cap.subrubrica10_nombre,
       cm.valor
  FROM capitulaciones_matriz cap,
       rubricacion_med cm
 WHERE ((cap.capitulo = :capitulo) OR (99 = :capitulo))
   AND cap.rubrica = cm.rubrica
   AND cap.subrubrica = cm.subrubrica
   AND cm.medicamento = :medicamento

UNION
SELECT cap.capitulo_nombre,
       cap.rubrica_nombre,
       cap.subrubrica_nombre,
       cap.subrubrica01_nombre,
       cap.subrubrica02_nombre,
       cap.subrubrica03_nombre,
       cap.subrubrica04_nombre,
       cap.subrubrica05_nombre,
       cap.subrubrica06_nombre,
       cap.subrubrica07_nombre,
       cap.subrubrica08_nombre,
       cap.subrubrica09_nombre,
       cap.subrubrica10_nombre,
       cm.valor
  FROM capitulaciones_matriz cap,
       subrubricacion_med cm
 WHERE ((cap.capitulo = :capitulo) OR (99 = :capitulo))
   AND cap.subrubrica = cm.subrubrica_padre
   AND cap.subrubrica01 = cm.subrubrica_hija
   AND cm.medicamento = :medicamento

UNION
SELECT cap.capitulo_nombre,
       cap.rubrica_nombre,
       cap.subrubrica_nombre,
       cap.subrubrica01_nombre,
       cap.subrubrica02_nombre,
       cap.subrubrica03_nombre,
       cap.subrubrica04_nombre,
       cap.subrubrica05_nombre,
       cap.subrubrica06_nombre,
       cap.subrubrica07_nombre,
       cap.subrubrica08_nombre,
       cap.subrubrica09_nombre,
       cap.subrubrica10_nombre,
       cm.valor
  FROM capitulaciones_matriz cap,
       subrubricacion_med cm
 WHERE ((cap.capitulo = :capitulo) OR (99 = :capitulo))
   AND cap.subrubrica01 = cm.subrubrica_padre
   AND cap.subrubrica02 = cm.subrubrica_hija
   AND cm.medicamento = :medicamento

UNION
SELECT cap.capitulo_nombre,
       cap.rubrica_nombre,
       cap.subrubrica_nombre,
       cap.subrubrica01_nombre,
       cap.subrubrica02_nombre,
       cap.subrubrica03_nombre,
       cap.subrubrica04_nombre,
       cap.subrubrica05_nombre,
       cap.subrubrica06_nombre,
       cap.subrubrica07_nombre,
       cap.subrubrica08_nombre,
       cap.subrubrica09_nombre,
       cap.subrubrica10_nombre,
       cm.valor
  FROM capitulaciones_matriz cap,
       subrubricacion_med cm
 WHERE ((cap.capitulo = :capitulo) OR (99 = :capitulo))
   AND cap.subrubrica02 = cm.subrubrica_padre
   AND cap.subrubrica03 = cm.subrubrica_hija
   AND cm.medicamento = :medicamento

UNION
SELECT cap.capitulo_nombre,
       cap.rubrica_nombre,
       cap.subrubrica_nombre,
       cap.subrubrica01_nombre,
       cap.subrubrica02_nombre,
       cap.subrubrica03_nombre,
       cap.subrubrica04_nombre,
       cap.subrubrica05_nombre,
       cap.subrubrica06_nombre,
       cap.subrubrica07_nombre,
       cap.subrubrica08_nombre,
       cap.subrubrica09_nombre,
       cap.subrubrica10_nombre,
       cm.valor
  FROM capitulaciones_matriz cap,
       subrubricacion_med cm
 WHERE ((cap.capitulo = :capitulo) OR (99 = :capitulo))
   AND cap.subrubrica03 = cm.subrubrica_padre
   AND cap.subrubrica04 = cm.subrubrica_hija
   AND cm.medicamento = :medicamento

UNION
SELECT cap.capitulo_nombre,
       cap.rubrica_nombre,
       cap.subrubrica_nombre,
       cap.subrubrica01_nombre,
       cap.subrubrica02_nombre,
       cap.subrubrica03_nombre,
       cap.subrubrica04_nombre,
       cap.subrubrica05_nombre,
       cap.subrubrica06_nombre,
       cap.subrubrica07_nombre,
       cap.subrubrica08_nombre,
       cap.subrubrica09_nombre,
       cap.subrubrica10_nombre,
       cm.valor
  FROM capitulaciones_matriz cap,
       subrubricacion_med cm
 WHERE ((cap.capitulo = :capitulo) OR (99 = :capitulo))
   AND cap.subrubrica04 = cm.subrubrica_padre
   AND cap.subrubrica05 = cm.subrubrica_hija
   AND cm.medicamento = :medicamento

UNION
SELECT cap.capitulo_nombre,
       cap.rubrica_nombre,
       cap.subrubrica_nombre,
       cap.subrubrica01_nombre,
       cap.subrubrica02_nombre,
       cap.subrubrica03_nombre,
       cap.subrubrica04_nombre,
       cap.subrubrica05_nombre,
       cap.subrubrica06_nombre,
       cap.subrubrica07_nombre,
       cap.subrubrica08_nombre,
       cap.subrubrica09_nombre,
       cap.subrubrica10_nombre,
       cm.valor
  FROM capitulaciones_matriz cap,
       subrubricacion_med cm
 WHERE ((cap.capitulo = :capitulo) OR (99 = :capitulo))
   AND cap.subrubrica05 = cm.subrubrica_padre
   AND cap.subrubrica06 = cm.subrubrica_hija
   AND cm.medicamento = :medicamento

UNION
SELECT cap.capitulo_nombre,
       cap.rubrica_nombre,
       cap.subrubrica_nombre,
       cap.subrubrica01_nombre,
       cap.subrubrica02_nombre,
       cap.subrubrica03_nombre,
       cap.subrubrica04_nombre,
       cap.subrubrica05_nombre,
       cap.subrubrica06_nombre,
       cap.subrubrica07_nombre,
       cap.subrubrica08_nombre,
       cap.subrubrica09_nombre,
       cap.subrubrica10_nombre,
       cm.valor
  FROM capitulaciones_matriz cap,
       subrubricacion_med cm
 WHERE ((cap.capitulo = :capitulo) OR (99 = :capitulo))
   AND cap.subrubrica06 = cm.subrubrica_padre
   AND cap.subrubrica07 = cm.subrubrica_hija
   AND cm.medicamento = :medicamento

UNION
SELECT cap.capitulo_nombre,
       cap.rubrica_nombre,
       cap.subrubrica_nombre,
       cap.subrubrica01_nombre,
       cap.subrubrica02_nombre,
       cap.subrubrica03_nombre,
       cap.subrubrica04_nombre,
       cap.subrubrica05_nombre,
       cap.subrubrica06_nombre,
       cap.subrubrica07_nombre,
       cap.subrubrica08_nombre,
       cap.subrubrica09_nombre,
       cap.subrubrica10_nombre,
       cm.valor
  FROM capitulaciones_matriz cap,
       subrubricacion_med cm
 WHERE ((cap.capitulo = :capitulo) OR (99 = :capitulo))
   AND cap.subrubrica07 = cm.subrubrica_padre
   AND cap.subrubrica08 = cm.subrubrica_hija
   AND cm.medicamento = :medicamento

UNION
SELECT cap.capitulo_nombre,
       cap.rubrica_nombre,
       cap.subrubrica_nombre,
       cap.subrubrica01_nombre,
       cap.subrubrica02_nombre,
       cap.subrubrica03_nombre,
       cap.subrubrica04_nombre,
       cap.subrubrica05_nombre,
       cap.subrubrica06_nombre,
       cap.subrubrica07_nombre,
       cap.subrubrica08_nombre,
       cap.subrubrica09_nombre,
       cap.subrubrica10_nombre,
       cm.valor
  FROM capitulaciones_matriz cap,
       subrubricacion_med cm
 WHERE ((cap.capitulo = :capitulo) OR (99 = :capitulo))
   AND cap.subrubrica08 = cm.subrubrica_padre
   AND cap.subrubrica09 = cm.subrubrica_hija
   AND cm.medicamento = :medicamento

UNION
SELECT cap.capitulo_nombre,
       cap.rubrica_nombre,
       cap.subrubrica_nombre,
       cap.subrubrica01_nombre,
       cap.subrubrica02_nombre,
       cap.subrubrica03_nombre,
       cap.subrubrica04_nombre,
       cap.subrubrica05_nombre,
       cap.subrubrica06_nombre,
       cap.subrubrica07_nombre,
       cap.subrubrica08_nombre,
       cap.subrubrica09_nombre,
       cap.subrubrica10_nombre,
       cm.valor
  FROM capitulaciones_matriz cap,
       subrubricacion_med cm
 WHERE ((cap.capitulo = :capitulo) OR (99 = :capitulo))
   AND cap.subrubrica09 = cm.subrubrica_padre
   AND cap.subrubrica10 = cm.subrubrica_hija
   AND cm.medicamento = :medicamento

ORDER BY 1, 2, 3
";
    }
}
