﻿using Minotti.Metadata;
using System.Collections.Generic;

namespace MinottiApp.Metadata.Generated
{
    public class dsto_actualiza_rubricas : IDataWindowMetadata
    {
        public string DataObject => "dsto_actualiza_rubricas";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn("rubrica", "decimal(0)")
            {
                DbName = "rubricas.rubrica",
                EsClave = true,
                EsIdentity = true
            },
            new DataWindowColumn("nombre", "char(255)")
            {
                DbName = "rubricas.nombre"
            }
        };

        public string Sql => @"
SELECT rubricas.rubrica,
       rubricas.nombre
  FROM rubricas
";

        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
