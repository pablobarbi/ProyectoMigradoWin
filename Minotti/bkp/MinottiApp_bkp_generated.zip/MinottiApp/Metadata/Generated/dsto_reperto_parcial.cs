﻿using Minotti.Metadata;
using System.Collections.Generic;

namespace MinottiApp.Metadata.Generated
{
    public class dsto_reperto_parcial : IDataWindowMetadata
    {
        public string DataObject => "dsto_reperto_parcial";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn("reperto_parcial", "decimal(0)")
            {
                DbName = "reperto_parcial.reperto_parcial",
                EsClave = true
            },
            new DataWindowColumn("capitulo", "decimal(0)")
            {
                DbName = "reperto_parcial.capitulo"
            },
            new DataWindowColumn("rubrica", "decimal(0)")
            {
                DbName = "reperto_parcial.rubrica"
            },
            new DataWindowColumn("subrubrica", "decimal(0)")
            {
                DbName = "reperto_parcial.subrubrica"
            },
            new DataWindowColumn("subrubrica2", "decimal(0)")
            {
                DbName = "reperto_parcial.subrubrica2"
            },
            new DataWindowColumn("subrubrica3", "decimal(0)")
            {
                DbName = "reperto_parcial.subrubrica3"
            },
            new DataWindowColumn("subrubrica4", "decimal(0)")
            {
                DbName = "reperto_parcial.subrubrica4"
            },
            new DataWindowColumn("subrubrica5", "decimal(0)")
            {
                DbName = "reperto_parcial.subrubrica5"
            },
            new DataWindowColumn("subrubrica6", "decimal(0)")
            {
                DbName = "reperto_parcial.subrubrica6"
            },
            new DataWindowColumn("subrubrica7", "decimal(0)")
            {
                DbName = "reperto_parcial.subrubrica7"
            },
            new DataWindowColumn("subrubrica8", "decimal(0)")
            {
                DbName = "reperto_parcial.subrubrica8"
            },
            new DataWindowColumn("subrubrica9", "decimal(0)")
            {
                DbName = "reperto_parcial.subrubrica9"
            },
            new DataWindowColumn("subrubrica10", "decimal(0)")
            {
                DbName = "reperto_parcial.subrubrica10"
            }
        };

        public string Sql => @"
SELECT reperto_parcial.reperto_parcial,
       reperto_parcial.capitulo,
       reperto_parcial.rubrica,
       reperto_parcial.subrubrica,
       reperto_parcial.subrubrica2,
       reperto_parcial.subrubrica3,
       reperto_parcial.subrubrica4,
       reperto_parcial.subrubrica5,
       reperto_parcial.subrubrica6,
       reperto_parcial.subrubrica7,
       reperto_parcial.subrubrica8,
       reperto_parcial.subrubrica9,
       reperto_parcial.subrubrica10
  FROM reperto_parcial
";

        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
