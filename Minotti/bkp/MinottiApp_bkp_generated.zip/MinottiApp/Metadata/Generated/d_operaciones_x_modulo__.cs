﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class d_operaciones_x_modulo__ : IDataWindowMetadata
    {
        public string DataObject => "d_operaciones_x_modulo__";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "modulo",
                DbName = "acc_operaciones_x_modulo.modulo",
                Tipo = "char(5)",
                EsClave = true
            },
            new DataWindowColumn
            {
                Nombre = "operacion",
                DbName = "acc_operaciones_x_modulo.operacion",
                Tipo = "char(5)",
                EsClave = true
            },
            new DataWindowColumn
            {
                Nombre = "alta",
                DbName = "acc_operaciones_x_modulo.alta",
                Tipo = "char(1)"
            },
            new DataWindowColumn
            {
                Nombre = "baja",
                DbName = "acc_operaciones_x_modulo.baja",
                Tipo = "char(1)"
            },
            new DataWindowColumn
            {
                Nombre = "modificacion",
                DbName = "acc_operaciones_x_modulo.modificacion",
                Tipo = "char(1)"
            },
            new DataWindowColumn
            {
                Nombre = "xx_descripcion",
                DbName = "acc_operaciones.nombre",
                Tipo = "char(30)"
            }
        };

        public string Sql => @"
SELECT dba.acc_operaciones_x_modulo.modulo,
       dba.acc_operaciones_x_modulo.operacion,
       dba.acc_operaciones_x_modulo.alta,
       dba.acc_operaciones_x_modulo.baja,
       dba.acc_operaciones_x_modulo.modificacion,
       dba.acc_operaciones.nombre
  FROM dba.acc_operaciones_x_modulo,
       dba.acc_operaciones
 WHERE dba.acc_operaciones_x_modulo.operacion = dba.acc_operaciones.operacion
   AND dba.acc_operaciones_x_modulo.modulo = :modulo
";

        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
