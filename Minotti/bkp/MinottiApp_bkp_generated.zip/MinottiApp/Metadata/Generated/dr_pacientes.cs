﻿using System.Collections.Generic;
using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class dr_pacientes : IDataWindowMetadata
    {
        public string DataObject => "dr_pacientes";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "paciente",
                DbName = "pacientes.paciente",
                Tipo = "long",
                Titulo = "Paciente",
                EsClave = true,
                EsClavePrimaria = true,
                EsIdentity = true
            },
            new DataWindowColumn
            {
                Nombre = "nombre",
                DbName = "pacientes.nombre",
                Tipo = "char(50)",
                Titulo = "Nombre y Apellido",
                EsRequerido = true
            },
            new DataWindowColumn
            {
                Nombre = "domicilio",
                DbName = "pacientes.domicilio",
                Tipo = "char(50)",
                Titulo = "Domicilio"
            },
            new DataWindowColumn
            {
                Nombre = "telefono",
                DbName = "pacientes.telefono",
                Tipo = "char(15)",
                Titulo = "Teléfono"
            },
            new DataWindowColumn
            {
                Nombre = "sexo",
                DbName = "pacientes.sexo",
                Tipo = "char(1)",
                Titulo = "Sexo",
                Valores = new[] { "M", "F" }
            },
            new DataWindowColumn
            {
                Nombre = "fecha_nacimiento",
                DbName = "pacientes.fecha_nacimiento",
                Tipo = "date",
                Titulo = "Fecha Nacimiento"
            },
            new DataWindowColumn
            {
                Nombre = "ultima_visita",
                DbName = "pacientes.ultima_visita",
                Tipo = "date",
                Titulo = "Última Visita"
            },
            new DataWindowColumn
            {
                Nombre = "ocupacion",
                DbName = "pacientes.ocupacion",
                Tipo = "char(50)",
                Titulo = "Ocupación"
            },
            new DataWindowColumn
            {
                Nombre = "estado_civil",
                DbName = "pacientes.estado_civil",
                Tipo = "long",
                Titulo = "Estado Civil"
            },
            new DataWindowColumn
            {
                Nombre = "cantidad_hijos",
                DbName = "pacientes.cantidad_hijos",
                Tipo = "long",
                Titulo = "Cantidad Hijos"
            }
        };

        public string[] Estilos => System.Array.Empty<string>();

        public string[] SeleccionFila => System.Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;

        public string Sql => @"
SELECT pacientes.paciente,
       pacientes.nombre,
       pacientes.domicilio,
       pacientes.telefono,
       pacientes.sexo,
       pacientes.fecha_nacimiento,
       pacientes.ultima_visita,
       pacientes.ocupacion,
       pacientes.estado_civil,
       pacientes.cantidad_hijos
  FROM pacientes
 WHERE (pacientes.paciente = :paciente)
    OR (:paciente = '0')
";
    }
}
