﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class dp_diagnosticos : IDataWindowMetadata
    {
        public string DataObject => "dp_diagnosticos";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "paciente",
                DbName = "diagnosticos.paciente",
                Tipo = "long",
                Titulo = string.Empty,
                EsClave = false,
                EsRequerido = false,
                TabOrder = null,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "fecha_desde",
                DbName = "diagnosticos.fecha_desde",
                Tipo = "date",
                Titulo = "Fecha Desde",
                EsClave = true,
                EsRequerido = false,
                TabOrder = 20,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "fecha_hasta",
                DbName = "diagnosticos.fecha_hasta",
                Tipo = "date",
                Titulo = "Fecha Hasta",
                EsClave = true,
                EsRequerido = false,
                TabOrder = 30,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "diag_nosologico",
                DbName = "diagnosticos.diag_nosologico",
                Tipo = "char(50)",
                Titulo = "Diagnóstico",
                EsClave = true,
                EsRequerido = false,
                TabOrder = 50,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "tipo_diagnostico",
                DbName = "tipo_diagnostico",
                Tipo = "char(1)",
                Titulo = "Tipo de diagnóstico",
                EsClave = true,
                EsRequerido = false,
                TabOrder = 40,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = new[]
                {
                    "Nosológico|N",
                    "Medicamentoso|M",
                    "Miasmático|I",
                    "Otro|O"
                }
            }
        };

        // ⇩ El SRD no define nada adicional ⇩
        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;

        public string Sql => @"
SELECT diagnosticos.paciente,
       diagnosticos.fecha_visita fecha_desde,
       diagnosticos.fecha_visita fecha_hasta,
       diagnosticos.diag_nosologico,
       'N' tipo_diagnostico
  FROM diagnosticos
";
    }
}
