﻿using System.Collections.Generic;
using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class dr_pacientes_historia_clinica : IDataWindowMetadata
    {
        public string DataObject => "dr_pacientes_historia_clinica";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "paciente",
                DbName = "pacientes_historias.paciente",
                Tipo = "long",
                Titulo = "Paciente",
                EsClave = true
            },
            new DataWindowColumn
            {
                Nombre = "hist_clin",
                DbName = "pacientes_historias.hist_clin",
                Tipo = "char(32766)",
                Titulo = "Historia Clinica"
            }
        };

        public string[] Estilos => System.Array.Empty<string>();

        public string[] SeleccionFila => System.Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;

        public string Sql => @"
SELECT pacientes_historias.paciente,
       pacientes_historias.hist_clin
  FROM pacientes_historias
 WHERE pacientes_historias.paciente = :paciente
";
    }
}
