﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    /// <summary>
    /// Metadata para dk_capitulos
    /// </summary>
    public class dk_capitulos : IDataWindowMetadata
    {
        public string DataObject => "dk_capitulos";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "capitulo",
                DbName = "capitulos.capitulo",
                Tipo = "decimal(0)",
                EsClave = true,
                TabOrder = 10
            },
            new DataWindowColumn
            {
                Nombre = "nombre",
                DbName = "capitulos.nombre",
                Tipo = "char(255)",
                TabOrder = 20
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
