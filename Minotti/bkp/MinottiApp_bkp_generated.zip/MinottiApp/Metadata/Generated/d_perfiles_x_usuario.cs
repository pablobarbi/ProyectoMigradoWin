﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class d_perfiles_x_usuario : IDataWindowMetadata
    {
        public string DataObject => "d_perfiles_x_usuario";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "acc_perfiles_perfil",
                DbName = "acc_perfiles.perfil",
                Tipo = "char(5)"
            },
            new DataWindowColumn
            {
                Nombre = "acc_perfiles_nombre",
                DbName = "acc_perfiles.nombre",
                Tipo = "char(50)"
            }
        };

        public string Sql => @"
SELECT DISTINCT acc_perfiles.perfil, 
                acc_perfiles.nombre 
  FROM acc_perfiles, 
       acc_usuarios 
 WHERE acc_perfiles.perfil = acc_usuarios.perfil 
   AND acc_usuarios.usuario = :usuario
";

        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
