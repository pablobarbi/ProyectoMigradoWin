﻿using Minotti.Metadata;
using System;
using System.Collections.Generic;

namespace Minotti.Metadata.Generated
{
    public class dp_filtro_todo : IDataWindowMetadata
    {
        public string DataObject => "dp_filtro_todo";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "nombre",
                DbName = "capitulos.nombre",
                Tipo = "char(255)",
                Titulo = "Nombre",
                EsClave = true,
                EsRequerido = true,
                TabOrder = 10,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            }
        };

        // ⇩ Propiedades SIN información en el SRD ⇩
        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;

        public string Sql => @"
SELECT capitulos.nombre
  FROM capitulos
";
    }
}
