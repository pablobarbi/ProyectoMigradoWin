﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class dl_pacientes_estadisticas : IDataWindowMetadata
    {
        public string DataObject => "dl_pacientes_estadisticas";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "paciente",
                DbName = "diagnosticos.paciente",
                Tipo = "long",
                Titulo = string.Empty,
                EsClave = false,
                EsRequerido = false,
                ObjetoSeleccion = null,
                Operacion = null,
                NivelOperacion = null,
                TabOrder = 32766,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "primera",
                DbName = "diagnosticos.primera",
                Tipo = "char(1)",
                Titulo = string.Empty,
                EsClave = false,
                EsRequerido = false,
                ObjetoSeleccion = null,
                Operacion = null,
                NivelOperacion = null,
                TabOrder = 32766,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;

        public string Sql => @"
SELECT diagnosticos.paciente,
       diagnosticos.primera
  FROM diagnosticos
 WHERE diagnosticos.fecha_visita >=
       YMD(SUBSTR(:fecha_desde, 7, 4), SUBSTR(:fecha_desde, 4, 2), SUBSTR(:fecha_desde, 1, 2))
   AND diagnosticos.fecha_visita <=
       YMD(SUBSTR(:fecha_hasta, 7, 4), SUBSTR(:fecha_hasta, 4, 2), SUBSTR(:fecha_hasta, 1, 2))
 ORDER BY diagnosticos.paciente
";
    }
}
