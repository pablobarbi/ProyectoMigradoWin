﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class d_reperto_total_medicamentos : IDataWindowMetadata
    {
        public string DataObject => "d_reperto_total_medicamentos";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "reperto_total",
                DbName = "reperto_total_med.reperto_total",
                Tipo = "decimal(0)"
            },
            new DataWindowColumn
            {
                Nombre = "reperto_sintoma",
                DbName = "reperto_total_med.reperto_sintoma",
                Tipo = "decimal(0)"
            },
            new DataWindowColumn
            {
                Nombre = "medicamento",
                DbName = "reperto_total_med.medicamento",
                Tipo = "char(10)"
            },
            new DataWindowColumn
            {
                Nombre = "orden",
                DbName = "reperto_total_med.orden",
                Tipo = "decimal(5)"
            },
            new DataWindowColumn
            {
                Nombre = "puntuacion",
                DbName = "reperto_total_med.puntuacion",
                Tipo = "char(5)"
            }
        };

        public string Sql => @"
SELECT reperto_total_med.reperto_total,
       reperto_total_med.reperto_sintoma,
       reperto_total_med.medicamento,
       reperto_total_med.orden,
       reperto_total_med.puntuacion
  FROM reperto_total_med
 WHERE reperto_total_med.reperto_total = :reperto_total
   AND reperto_total_med.reperto_sintoma = :reperto_sintoma
";

        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
