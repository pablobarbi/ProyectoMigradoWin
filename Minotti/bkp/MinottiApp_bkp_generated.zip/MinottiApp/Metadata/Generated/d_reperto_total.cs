﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class d_reperto_total : IDataWindowMetadata
    {
        public string DataObject => "d_reperto_total";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "reperto_total",
                DbName = "reperto_total.reperto_total",
                Tipo = "decimal(0)"
            },
            new DataWindowColumn
            {
                Nombre = "reperto_sintoma",
                DbName = "reperto_total.reperto_sintoma",
                Tipo = "decimal(0)"
            },
            new DataWindowColumn
            {
                Nombre = "orden",
                DbName = "reperto_total.orden",
                Tipo = "long"
            }
        };

        public string Sql => @"
SELECT reperto_total.reperto_total,
       reperto_total.reperto_sintoma,
       reperto_total.orden
  FROM reperto_total
 WHERE reperto_total.reperto_total = :rep_total
";

        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
