﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    /// <summary>
    /// Metadata para dk_medicamentos_de_la_subrubrica
    /// </summary>
    public class dk_medicamentos_de_la_subrubrica : IDataWindowMetadata
    {
        public string DataObject => "dk_medicamentos_de_la_subrubrica";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "medicamento",
                DbName = "rubricacion_med.medicamento",
                Tipo = "char(10)"
            },
            new DataWindowColumn
            {
                Nombre = "descripcion",
                DbName = "medicamentos.descripcion",
                Tipo = "char(50)"
            },
            new DataWindowColumn
            {
                Nombre = "valor",
                DbName = "rubricacion_med.valor",
                Tipo = "decimal(6)",
                TabOrder = 10
            },
            new DataWindowColumn
            {
                Nombre = "seleccionado",
                DbName = "seleccionado",
                Tipo = "char(1)"
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
