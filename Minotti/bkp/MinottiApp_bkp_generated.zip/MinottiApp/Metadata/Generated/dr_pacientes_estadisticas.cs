﻿using System.Collections.Generic;
using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class dr_pacientes_estadisticas : IDataWindowMetadata
    {
        public string DataObject => "dr_pacientes_estadisticas";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "paciente",
                DbName = "diagnosticos.paciente",
                Tipo = "long",
                Titulo = "Paciente"
            },
            new DataWindowColumn
            {
                Nombre = "primera",
                DbName = "diagnosticos.primera",
                Tipo = "char(1)",
                Titulo = "Primera",
                Valores = new[] { "S", "N" }
            }
        };

        public string[] Estilos => System.Array.Empty<string>();

        public string[] SeleccionFila => System.Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => true;

        public string Sql => @"
SELECT diagnosticos.paciente,
       diagnosticos.primera
  FROM diagnosticos
 WHERE diagnosticos.fecha_visita >= YMD(
         SUBSTR(:fecha_desde, 7, 4),
         SUBSTR(:fecha_desde, 4, 2),
         SUBSTR(:fecha_desde, 1, 2)
       )
   AND diagnosticos.fecha_visita <= YMD(
         SUBSTR(:fecha_hasta, 7, 4),
         SUBSTR(:fecha_hasta, 4, 2),
         SUBSTR(:fecha_hasta, 1, 2)
       )
 ORDER BY diagnosticos.paciente
";
    }
}
