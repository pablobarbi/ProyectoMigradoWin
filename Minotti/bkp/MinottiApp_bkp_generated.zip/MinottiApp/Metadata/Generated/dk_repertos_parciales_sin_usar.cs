﻿using Minotti.Metadata;
using System.Collections.Generic;

public class dk_repertos_parciales_sin_usar : IDataWindowMetadata
{
    public string DataObject => "dk_repertos_parciales_sin_usar";

    public List<DataWindowColumn> Columns { get; } = new()
    {
        new DataWindowColumn("reperto_parcial", "decimal(0)") { DbName = "reperto_parcial.reperto_parcial", EsClave = true, EsIdentity = true },
        new DataWindowColumn("capitulo", "decimal(0)") { DbName = "reperto_parcial.capitulo" },
        new DataWindowColumn("rubrica", "decimal(0)") { DbName = "reperto_parcial.rubrica" },
        new DataWindowColumn("subrubrica", "decimal(0)") { DbName = "reperto_parcial.subrubrica" },
        new DataWindowColumn("subrubrica2", "decimal(0)") { DbName = "subrubrica2" },
        new DataWindowColumn("subrubrica3", "decimal(0)") { DbName = "subrubrica3" },
        new DataWindowColumn("subrubrica4", "decimal(0)") { DbName = "subrubrica4" },
        new DataWindowColumn("subrubrica5", "decimal(0)") { DbName = "subrubrica5" },
        new DataWindowColumn("subrubrica6", "decimal(0)") { DbName = "subrubrica6" },
        new DataWindowColumn("subrubrica7", "decimal(0)") { DbName = "subrubrica7" },
        new DataWindowColumn("subrubrica8", "decimal(0)") { DbName = "subrubrica8" },
        new DataWindowColumn("subrubrica9", "decimal(0)") { DbName = "subrubrica9" },
        new DataWindowColumn("subrubrica10", "decimal(0)") { DbName = "subrubrica10" },
        new DataWindowColumn("seleccionado", "char(1)") { DbName = "seleccionado" },
        new DataWindowColumn("capitulo_nombre", "char(1)") { DbName = "capitulo_nombre" },
        new DataWindowColumn("rubrica_nombre", "char(1)") { DbName = "rubrica_nombre" },
        new DataWindowColumn("subrubrica_nombre", "char(1)") { DbName = "subrubrica_nombre" },
        new DataWindowColumn("subrubrica2_nombre", "char(1)") { DbName = "subrubrica2_nombre" },
        new DataWindowColumn("subrubrica3_nombre", "char(1)") { DbName = "subrubrica3_nombre" },
        new DataWindowColumn("subrubrica4_nombre", "char(1)") { DbName = "subrubrica4_nombre" },
        new DataWindowColumn("subrubrica5_nombre", "char(1)") { DbName = "subrubrica5_nombre" },
        new DataWindowColumn("subrubrica6_nombre", "char(1)") { DbName = "subrubrica6_nombre" },
        new DataWindowColumn("subrubrica7_nombre", "char(1)") { DbName = "subrubrica7_nombre" },
        new DataWindowColumn("subrubrica8_nombre", "char(1)") { DbName = "subrubrica8_nombre" },
        new DataWindowColumn("subrubrica9_nombre", "char(1)") { DbName = "subrubrica9_nombre" },
        new DataWindowColumn("subrubrica10_nombre", "char(1)") { DbName = "subrubrica10_nombre" },
    };

    public string[] Estilos => new[] { "seleccionado" };

    public string[] SeleccionFila => new[] { "capitulo", "rubrica", "subrubrica" };

    public string Operaciones => string.Empty;

    public bool UsaUsuario => false;

    public bool UsaFecha => false;
}
