﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    /// <summary>
    /// Metadata para d_valor_inicial
    /// </summary>
    public class d_valor_inicial : IDataWindowMetadata
    {
        public string DataObject => "d_valor_inicial";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "campo",
                DbName = "par_valor_inicial.campo",
                Tipo = "char(18)",
                EsClave = true,
                TabOrder = 10
            },
            new DataWindowColumn
            {
                Nombre = "valor_inicial",
                DbName = "par_valor_inicial.valor_inicial",
                Tipo = "char(60)",
                EsRequerido = false,
                TabOrder = 20
            }
        };


        public string Sql => @" SELECT dba.par_valor_inicial.campo,   
                                     dba.par_valor_inicial.valor_inicial  
                               FROM dba.par_valor_inicial";

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
