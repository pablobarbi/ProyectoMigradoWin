﻿using Minotti.Metadata;

namespace MinottiApp.Metadata.Generated
{
    public class dl_operaciones_por_modulo : IDataWindowMetadata
    {
        public string DataObject => "dl_operaciones_por_modulo";

        public List<DataWindowColumn> Columns { get; } = new()
        {
            new DataWindowColumn("modulo", "char(5)")
            {
                DbName = "acc_operaciones_x_modulo.modulo"
            },
            new DataWindowColumn("nombre_modulo", "char(20)")
            {
                DbName = "acc_modulos.nombre"
            },
            new DataWindowColumn("bitmap_modulo", "char(40)")
            {
                DbName = "acc_modulos.bitmap"
            },
            new DataWindowColumn("operacion", "char(5)")
            {
                DbName = "acc_operaciones_x_modulo.operacion"
            },
            new DataWindowColumn("nombre_operacion", "char(30)")
            {
                DbName = "acc_operaciones.nombre"
            },
            new DataWindowColumn("bitmap_operacion", "char(40)")
            {
                DbName = "acc_operaciones.bitmap"
            },
            new DataWindowColumn("alta", "char(1)")
            {
                DbName = "alta"
            },
            new DataWindowColumn("baja", "char(1)")
            {
                DbName = "baja"
            },
            new DataWindowColumn("modificacion", "char(1)")
            {
                DbName = "modificacion"
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => "operacion";

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
