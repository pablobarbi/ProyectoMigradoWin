﻿using Minotti.Metadata;

namespace MinottiApp.Metadata.Generated
{
    public class dk_subrubricas_de_la_subrubrica : IDataWindowMetadata
    {
        public string DataObject => "dk_subrubricas_de_la_subrubrica";

        public List<DataWindowColumn> Columns { get; } = new()
        {
            new DataWindowColumn("subrubrica_padre", "decimal(0)")
            {
                DbName = "subrubricaciones.subrubrica_padre",
                EsClave = true
            },
            new DataWindowColumn("subrubrica_hija", "decimal(0)")
            {
                DbName = "subrubricaciones.subrubrica_hija",
                EsClave = true
            },
            new DataWindowColumn("subrubricas_nombre", "char(255)")
            {
                DbName = "subrubricas.nombre"
            },
            new DataWindowColumn("posicion", "long")
            {
                DbName = "subrubricaciones.posicion"
            },
            new DataWindowColumn("subrubricas_nombre_orden", "char(259)")
            {
                DbName = "subrubricas_nombre_orden"
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
