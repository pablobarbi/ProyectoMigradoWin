﻿using Minotti.Metadata;
using System;
using System.Collections.Generic;

namespace Minotti.Metadata.Generated
{
    public class dp_medicamentos_desde_hasta : IDataWindowMetadata
    {
        public string DataObject => "dp_medicamentos_desde_hasta";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "med1",
                DbName = "med1",
                Tipo = "char(10)",
                Titulo = "Medicamento Desde",
                EsClave = true,
                EsRequerido = false,
                TabOrder = 10,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "med2",
                DbName = "med2",
                Tipo = "char(10)",
                Titulo = "Medicamento Hasta",
                EsClave = true,
                EsRequerido = true,
                TabOrder = 20,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            }
        };

        // ⇩ No hay metadata en el SRD para estas propiedades ⇩
        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;

        public string Sql => @"
SELECT medicamentos.medicamento AS med1,
       medicamentos.medicamento AS med2
  FROM medicamentos
";
    }
}
