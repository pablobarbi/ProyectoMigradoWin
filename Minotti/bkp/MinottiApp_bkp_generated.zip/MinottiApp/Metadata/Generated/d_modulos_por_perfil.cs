﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class d_modulos_por_perfil : IDataWindowMetadata
    {
        public string DataObject => "d_modulos_por_perfil";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "perfil",
                DbName = "acc_modulos_x_perfil.perfil",
                Tipo = "char(5)",
                EsClave = true,
                TabOrder = 10
            },
            new DataWindowColumn
            {
                Nombre = "modulo",
                DbName = "acc_modulos_x_perfil.modulo",
                Tipo = "char(5)",
                EsClave = true,
                TabOrder = 20
            }
        };

        public string Sql => @"
SELECT dba.acc_modulos_x_perfil.perfil,
       dba.acc_modulos_x_perfil.modulo
  FROM dba.acc_modulos_x_perfil
 WHERE dba.acc_modulos_x_perfil.perfil = :perfil
";

        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
