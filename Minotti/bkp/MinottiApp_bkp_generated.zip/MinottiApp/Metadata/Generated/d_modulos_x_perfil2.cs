﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class d_modulos_x_perfil2 : IDataWindowMetadata
    {
        public string DataObject => "d_modulos_x_perfil2";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "perfil",
                DbName = "acc_modulos_x_perfil.perfil",
                Tipo = "char(5)",
                EsClave = true,
                TabOrder = 10
            },
            new DataWindowColumn
            {
                Nombre = "modulo",
                DbName = "acc_modulos_x_perfil.modulo",
                Tipo = "char(5)",
                EsClave = true,
                TabOrder = 20
            },
            new DataWindowColumn
            {
                Nombre = "nombre",
                DbName = "acc_modulos.nombre",
                Tipo = "char(40)",
                TabOrder = 30
            }
        };

        public string Sql => @"
  SELECT dba.acc_modulos_x_perfil.perfil,
         dba.acc_modulos_x_perfil.modulo,   
         dba.acc_modulos.nombre
    FROM dba.acc_modulos_x_perfil,   
         dba.acc_modulos  
   WHERE dba.acc_modulos.modulo = dba.acc_modulos_x_perfil.modulo 
     AND dba.acc_modulos_x_perfil.perfil = :perf
";

        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
