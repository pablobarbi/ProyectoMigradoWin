﻿using Minotti.Metadata;

namespace MinottiApp.Metadata.Generated
{
    public class dk_rubricas_del_capitulo : IDataWindowMetadata
    {
        public string DataObject => "dk_rubricas_del_capitulo";

        public List<DataWindowColumn> Columns { get; } = new()
        {
            new DataWindowColumn("capitulaciones_capitulo", "decimal(0)") { EsClave = true },
            new DataWindowColumn("capitulaciones_rubrica", "decimal(0)") { EsClave = true },
            new DataWindowColumn("rubricas_nombre", "char(255)")
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
