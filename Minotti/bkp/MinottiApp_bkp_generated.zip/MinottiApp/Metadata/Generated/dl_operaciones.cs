﻿using Minotti.Metadata;

namespace MinottiApp.Metadata.Generated
{
    public class dl_operaciones : IDataWindowMetadata
    {
        public string DataObject => "dl_operaciones";

        public List<DataWindowColumn> Columns { get; } = new()
        {
            new DataWindowColumn("operacion", "char(8)")
            {
                DbName = "acc_operaciones.operacion",
                EsClave = true
            },
            new DataWindowColumn("nombre", "char(40)")
            {
                DbName = "acc_operaciones.nombre"
            },
            new DataWindowColumn("bitmap", "char(40)")
            {
                DbName = "acc_operaciones.bitmap"
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => "operacion";

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
