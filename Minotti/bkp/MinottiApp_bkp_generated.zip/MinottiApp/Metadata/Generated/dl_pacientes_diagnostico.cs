﻿using Minotti.Metadata;

namespace MinottiApp.Metadata.Generated
{
    public class dl_pacientes_diagnostico : IDataWindowMetadata
    {
        public string DataObject => "dl_pacientes_diagnostico";

        public List<DataWindowColumn> Columns { get; } = new()
        {
            new DataWindowColumn("paciente", "long") { DbName = "diagnosticos.paciente" },
            new DataWindowColumn("diagnostico", "long") { DbName = "diagnosticos.diagnostico" },
            new DataWindowColumn("fecha_visita", "date") { DbName = "diagnosticos.fecha_visita" },
            new DataWindowColumn("diag_nosologico", "char(50)") { DbName = "diagnosticos.diag_nosologico" },
            new DataWindowColumn("diag_medicamentoso", "char(50)") { DbName = "diagnosticos.diag_medicamentoso" },
            new DataWindowColumn("diag_miasmatico", "char(50)") { DbName = "diagnosticos.diag_miasmatico" },
            new DataWindowColumn("diag_otro", "char(50)") { DbName = "diagnosticos.diag_otro" },
            new DataWindowColumn("repertorizacion", "long") { DbName = "diagnosticos.repertorizacion" },
            new DataWindowColumn("primera", "char(1)") { DbName = "diagnosticos.primera" },
            new DataWindowColumn("curado", "char(1)") { DbName = "diagnosticos.curado" }
        };

        public string Sql => @"
            SELECT diagnosticos.paciente,
                   diagnosticos.diagnostico,
                   diagnosticos.fecha_visita,
                   diagnosticos.diag_nosologico,
                   diagnosticos.diag_medicamentoso,
                   diagnosticos.diag_miasmatico,
                   diagnosticos.diag_otro,
                   diagnosticos.repertorizacion,
                   diagnosticos.primera,
                   diagnosticos.curado
            FROM diagnosticos
            WHERE diagnosticos.paciente = :paciente
        ";

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => "diagnostico";

        public bool UsaUsuario => false;

        public bool UsaFecha => true;
    }
}
