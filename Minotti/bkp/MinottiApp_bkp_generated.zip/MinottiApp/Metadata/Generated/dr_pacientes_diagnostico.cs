﻿using System.Collections.Generic;
using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class dr_pacientes_diagnostico : IDataWindowMetadata
    {
        public string DataObject => "dr_pacientes_diagnostico";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "paciente",
                DbName = "diagnosticos.paciente",
                Tipo = "long",
                Titulo = "Paciente",
                EsClave = true,
                EsClavePrimaria = true
            },
            new DataWindowColumn
            {
                Nombre = "diagnostico",
                DbName = "diagnosticos.diagnostico",
                Tipo = "long",
                Titulo = "Diagnóstico",
                EsClave = true,
                EsClavePrimaria = true
            },
            new DataWindowColumn
            {
                Nombre = "fecha_visita",
                DbName = "diagnosticos.fecha_visita",
                Tipo = "date",
                Titulo = "Fecha Visita"
            },
            new DataWindowColumn
            {
                Nombre = "diag_nosologico",
                DbName = "diagnosticos.diag_nosologico",
                Tipo = "char(50)",
                Titulo = "Nosológico"
            },
            new DataWindowColumn
            {
                Nombre = "diag_medicamentoso",
                DbName = "diagnosticos.diag_medicamentoso",
                Tipo = "char(50)",
                Titulo = "Medicamentoso"
            },
            new DataWindowColumn
            {
                Nombre = "diag_miasmatico",
                DbName = "diagnosticos.diag_miasmatico",
                Tipo = "char(50)",
                Titulo = "Miasmático"
            },
            new DataWindowColumn
            {
                Nombre = "diag_otro",
                DbName = "diagnosticos.diag_otro",
                Tipo = "char(50)",
                Titulo = "Otro"
            },
            new DataWindowColumn
            {
                Nombre = "repertorizacion",
                DbName = "diagnosticos.repertorizacion",
                Tipo = "long",
                Titulo = "Repertorización"
            },
            new DataWindowColumn
            {
                Nombre = "primera",
                DbName = "diagnosticos.primera",
                Tipo = "char(1)",
                Titulo = "Primera Visita",
                Valores = new[] { "S", "N" }
            },
            new DataWindowColumn
            {
                Nombre = "curado",
                DbName = "diagnosticos.curado",
                Tipo = "char(1)",
                Titulo = "Curado",
                Valores = new[] { "S", "N" }
            }
        };

        public string[] Estilos => System.Array.Empty<string>();

        public string[] SeleccionFila => System.Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => true;

        public string Sql => @"
SELECT diagnosticos.paciente,
       diagnosticos.diagnostico,
       diagnosticos.fecha_visita,
       diagnosticos.diag_nosologico,
       diagnosticos.diag_medicamentoso,
       diagnosticos.diag_miasmatico,
       diagnosticos.diag_otro,
       diagnosticos.repertorizacion,
       diagnosticos.primera,
       diagnosticos.curado
  FROM diagnosticos
 WHERE diagnosticos.paciente = :paciente
";
    }
}
