﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    /// <summary>
    /// Metadata para dk_diagnosticos
    /// </summary>
    public class dk_diagnosticos : IDataWindowMetadata
    {
        public string DataObject => "dk_diagnosticos";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "paciente",
                DbName = "diagnosticos.paciente",
                Tipo = "long",
                EsClave = true,
                TabOrder = 10
            },
            new DataWindowColumn
            {
                Nombre = "diagnostico",
                DbName = "diagnosticos.diagnostico",
                Tipo = "long",
                EsClave = true,
                TabOrder = 20
            },
            new DataWindowColumn
            {
                Nombre = "fecha_visita",
                DbName = "diagnosticos.fecha_visita",
                Tipo = "date",
                TabOrder = 30
            },
            new DataWindowColumn
            {
                Nombre = "pacientes_nombre",
                DbName = "pacientes.nombre",
                Tipo = "char(50)",
                TabOrder = 40
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
