﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    /// <summary>
    /// Metadata para dk_perfiles
    /// </summary>
    public class dk_perfiles : IDataWindowMetadata
    {
        public string DataObject => "dk_perfiles";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "perfil",
                DbName = "acc_perfiles.perfil",
                Tipo = "char(5)",
                EsClave = true,
                EsClavePrimaria = true,
                TabOrder = 32766
            },
            new DataWindowColumn
            {
                Nombre = "nombre",
                DbName = "acc_perfiles.nombre",
                Tipo = "char(20)",
                TabOrder = 32766
            },
            new DataWindowColumn
            {
                Nombre = "bitmap",
                DbName = "acc_perfiles.bitmap",
                Tipo = "char(40)",
                TabOrder = 32766
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}