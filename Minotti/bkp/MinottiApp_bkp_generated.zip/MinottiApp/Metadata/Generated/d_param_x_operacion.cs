﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class d_param_x_operacion : IDataWindowMetadata
    {
        public string DataObject => "d_param_x_operacion";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "operacion",
                DbName = "acc_parametros.operacion",
                Tipo = "char(5)"
            },
            new DataWindowColumn
            {
                Nombre = "orden",
                DbName = "acc_parametros.orden",
                Tipo = "long"
            },
            new DataWindowColumn
            {
                Nombre = "titulo",
                DbName = "acc_parametros.titulo",
                Tipo = "char(80)"
            },
            new DataWindowColumn
            {
                Nombre = "objeto",
                DbName = "acc_parametros.objeto",
                Tipo = "char(40)"
            },
            new DataWindowColumn
            {
                Nombre = "parametros",
                DbName = "acc_parametros.parametros",
                Tipo = "char(256)"
            },
            new DataWindowColumn
            {
                Nombre = "cierra",
                DbName = "acc_parametros.cierra",
                Tipo = "char(1)"
            }
        };

        public string Sql => @"
SELECT DISTINCT 
       dba.acc_parametros.operacion,
       dba.acc_parametros.orden,
       dba.acc_parametros.titulo,
       dba.acc_parametros.objeto,
       dba.acc_parametros.parametros,
       dba.acc_parametros.cierra
  FROM dba.acc_parametros,
       dba.acc_operaciones_x_modulo,
       dba.acc_modulos_x_perfil
 WHERE dba.acc_operaciones_x_modulo.operacion = dba.acc_parametros.operacion
   AND dba.acc_operaciones_x_modulo.modulo = dba.acc_modulos_x_perfil.modulo
   AND dba.acc_modulos_x_perfil.perfil = :perfil
 ORDER BY dba.acc_parametros.operacion,
          dba.acc_parametros.orden
";

        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
