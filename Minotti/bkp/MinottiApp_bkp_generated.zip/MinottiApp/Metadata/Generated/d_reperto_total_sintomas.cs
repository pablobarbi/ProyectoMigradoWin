﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class d_reperto_total_sintomas : IDataWindowMetadata
    {
        public string DataObject => "d_reperto_total_sintomas";

        public List<DataWindowColumn> Columns => new()
    {
        new DataWindowColumn { Nombre = "reperto_total_orden", Tipo = "long", Titulo = "Orden", EsClave = false },
        // etc.
    };

        public string[] Estilos => new[] { "v", "n", "v", "v" };
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => "";
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }

}
