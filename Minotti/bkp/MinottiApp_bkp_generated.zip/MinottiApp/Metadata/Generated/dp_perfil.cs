﻿using Minotti.Metadata;
using System;
using System.Collections.Generic;

namespace Minotti.Metadata.Generated
{
    public class dp_perfil : IDataWindowMetadata
    {
        public string DataObject => "dp_perfil";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "perfil",
                DbName = "perfil",
                Tipo = "char(5)",
                Titulo = "Perfíl",
                EsClave = false,
                EsClavePrimaria = false,
                EsIdentity = false,
                EsRequerido = false,
                TabOrder = 10,
                Valores = Array.Empty<string>()
            }
        };

        // ⇩ El SRD no define metadata funcional ⇩
        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;

        // ⇩ No hay retrieve SQL en el SRD ⇩
        public string Sql => string.Empty;
    }
}
