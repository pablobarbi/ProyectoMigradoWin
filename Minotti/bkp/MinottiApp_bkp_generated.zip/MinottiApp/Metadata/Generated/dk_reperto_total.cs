﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    /// <summary>
    /// Metadata para dk_reperto_total
    /// </summary>
    public class dk_reperto_total : IDataWindowMetadata
    {
        public string DataObject => "dk_reperto_total";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "reperto_total",
                DbName = "reperto_total_diag.reperto_total",
                Tipo = "decimal(0)",
                EsClave = true,
                EsClavePrimaria = true,
                TabOrder = 32766
            },
            new DataWindowColumn
            {
                Nombre = "fecha",
                DbName = "reperto_total_diag.fecha",
                Tipo = "date",
                TabOrder = 32766
            },
            new DataWindowColumn
            {
                Nombre = "comentario",
                DbName = "reperto_total_diag.comentario",
                Tipo = "char(50)",
                TabOrder = 32766
            },
            new DataWindowColumn
            {
                Nombre = "paciente",
                DbName = "reperto_total_diag.paciente",
                Tipo = "long",
                ObjetoSeleccion = "dw_pacientes",
                TabOrder = 32766
            },
            new DataWindowColumn
            {
                Nombre = "marca",
                DbName = "reperto_total_diag.marca",
                Tipo = "char(1)",
                TabOrder = 32766
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => true;
    }
}
