﻿using Minotti.Metadata;
using System;
using System.Collections.Generic;

namespace Minotti.Metadata.Generated
{
    public class dp_un_medicamento_valor : IDataWindowMetadata
    {
        public string DataObject => "dp_un_medicamento_valor";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "capitulo",
                DbName = "capitulacion_med.capitulo",
                Tipo = "decimal(0)",
                Titulo = "Capítulo",
                EsClave = true,
                EsClavePrimaria = false,
                EsIdentity = false,
                TabOrder = 10,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "medicamento",
                DbName = "capitulacion_med.medicamento",
                Tipo = "char(10)",
                Titulo = "Medicamento",
                EsClave = true,
                EsClavePrimaria = false,
                EsIdentity = false,
                TabOrder = 20,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "valor",
                DbName = "capitulacion_med.valor",
                Tipo = "long",
                Titulo = "Valor",
                EsClave = true,
                EsClavePrimaria = false,
                EsIdentity = false,
                TabOrder = 30,
                Valores = new[] { "1", "1/2", "2/3", "3/" }
            }
        };

        // ⇩ Metadata funcional (no definida en el SRD) ⇩
        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;

        public string Sql => @"
SELECT capitulacion_med.capitulo,
       capitulacion_med.medicamento,
       capitulacion_med.valor
  FROM capitulacion_med
";
    }
}
