﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class d_modulo : IDataWindowMetadata
    {
        public string DataObject => "d_modulo";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "modulo",
                DbName = "acc_modulos.modulo",
                Tipo = "char(8)",
                EsClave = true,
                TabOrder = 10
            },
            new DataWindowColumn
            {
                Nombre = "nombre",
                DbName = "acc_modulos.nombre",
                Tipo = "char(40)",
                TabOrder = 20
            },
            new DataWindowColumn
            {
                Nombre = "bitmap",
                DbName = "acc_modulos.bitmap",
                Tipo = "char(40)"
            }
        };

        public string Sql => @"
SELECT dba.acc_modulos.modulo,   
       dba.acc_modulos.nombre,   
       dba.acc_modulos.bitmap  
  FROM dba.acc_modulos  
 WHERE dba.acc_modulos.modulo = :modulo
";

        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
