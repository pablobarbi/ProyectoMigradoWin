﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class dl_un_medicamento_un_valor : IDataWindowMetadata
    {
        public string DataObject => "dl_un_medicamento_un_valor";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn { Nombre = "capitulo_nombre",     DbName = "capitulaciones_matriz.capitulo_nombre",     Tipo = "char(255)", Titulo = "Capítulo:",     TabOrder = 32766, Valores = Array.Empty<string>() },
            new DataWindowColumn { Nombre = "rubrica_nombre",      DbName = "capitulaciones_matriz.rubrica_nombre",      Tipo = "char(255)", Titulo = "Rubrica:",      TabOrder = 32766, Valores = Array.Empty<string>() },
            new DataWindowColumn { Nombre = "subrubrica_nombre",   DbName = "capitulaciones_matriz.subrubrica_nombre",   Tipo = "char(255)", Titulo = "Subrubrica  0:", TabOrder = 32766, Valores = Array.Empty<string>() },
            new DataWindowColumn { Nombre = "subrubrica01_nombre", DbName = "capitulaciones_matriz.subrubrica01_nombre", Tipo = "char(255)", Titulo = "Subrubrica  1:", TabOrder = 32766, Valores = Array.Empty<string>() },
            new DataWindowColumn { Nombre = "subrubrica02_nombre", DbName = "capitulaciones_matriz.subrubrica02_nombre", Tipo = "char(255)", Titulo = "Subrubrica  2:", TabOrder = 32766, Valores = Array.Empty<string>() },
            new DataWindowColumn { Nombre = "subrubrica03_nombre", DbName = "capitulaciones_matriz.subrubrica03_nombre", Tipo = "char(255)", Titulo = "Subrubrica  3:", TabOrder = 32766, Valores = Array.Empty<string>() },
            new DataWindowColumn { Nombre = "subrubrica04_nombre", DbName = "capitulaciones_matriz.subrubrica04_nombre", Tipo = "char(255)", Titulo = "Subrubrica  4:", TabOrder = 32766, Valores = Array.Empty<string>() },
            new DataWindowColumn { Nombre = "subrubrica05_nombre", DbName = "capitulaciones_matriz.subrubrica05_nombre", Tipo = "char(255)", Titulo = "Subrubrica  5:", TabOrder = 32766, Valores = Array.Empty<string>() },
            new DataWindowColumn { Nombre = "subrubrica06_nombre", DbName = "capitulaciones_matriz.subrubrica06_nombre", Tipo = "char(255)", Titulo = "Subrubrica  6:", TabOrder = 32766, Valores = Array.Empty<string>() },
            new DataWindowColumn { Nombre = "subrubrica07_nombre", DbName = "capitulaciones_matriz.subrubrica07_nombre", Tipo = "char(255)", Titulo = "Subrubrica  7:", TabOrder = 32766, Valores = Array.Empty<string>() },
            new DataWindowColumn { Nombre = "subrubrica08_nombre", DbName = "capitulaciones_matriz.subrubrica08_nombre", Tipo = "char(255)", Titulo = "Subrubrica  8:", TabOrder = 32766, Valores = Array.Empty<string>() },
            new DataWindowColumn { Nombre = "subrubrica09_nombre", DbName = "capitulaciones_matriz.subrubrica09_nombre", Tipo = "char(255)", Titulo = "Subrubrica  9:", TabOrder = 32766, Valores = Array.Empty<string>() },
            new DataWindowColumn { Nombre = "subrubrica10_nombre", DbName = "capitulaciones_matriz.subrubrica10_nombre", Tipo = "char(255)", Titulo = "Subrubrica 10:", TabOrder = 32766, Valores = Array.Empty<string>() },
            new DataWindowColumn { Nombre = "valor",              DbName = "capitulacion_med.valor",                 Tipo = "long",      Titulo = "Valor:",         TabOrder = 32766, Valores = Array.Empty<string>() }
        };

        // Solo si el SRD lo define explícitamente
        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;

        public string Sql => @"
  SELECT cap.capitulo_nombre,
         cap.rubrica_nombre,
         cap.subrubrica_nombre,
         cap.subrubrica01_nombre,
         cap.subrubrica02_nombre,
         cap.subrubrica03_nombre,
         cap.subrubrica04_nombre,
         cap.subrubrica05_nombre,
         cap.subrubrica06_nombre,
         cap.subrubrica07_nombre,
         cap.subrubrica08_nombre,
         cap.subrubrica09_nombre,
         cap.subrubrica10_nombre,
         cm.valor
    FROM capitulaciones_matriz cap
          , capitulacion_med cm
   WHERE cap.capitulo = :capitulo
     AND cap.capitulo = cm.capitulo
     AND cap.rubrica = cm.rubrica
     AND cm.medicamento = :medicamento
     AND cm.valor = :valor
UNION
  SELECT cap.capitulo_nombre,
         cap.rubrica_nombre,
         cap.subrubrica_nombre,
         cap.subrubrica01_nombre,
         cap.subrubrica02_nombre,
         cap.subrubrica03_nombre,
         cap.subrubrica04_nombre,
         cap.subrubrica05_nombre,
         cap.subrubrica06_nombre,
         cap.subrubrica07_nombre,
         cap.subrubrica08_nombre,
         cap.subrubrica09_nombre,
         cap.subrubrica10_nombre,
         cm.valor
    FROM capitulaciones_matriz cap
          , rubricacion_med cm
   WHERE cap.capitulo = :capitulo
     AND cap.rubrica = cm.rubrica
     AND cap.subrubrica = cm.subrubrica
     AND cm.medicamento = :medicamento
     AND cm.valor = :valor
UNION
  SELECT cap.capitulo_nombre,
         cap.rubrica_nombre,
         cap.subrubrica_nombre,
         cap.subrubrica01_nombre,
         cap.subrubrica02_nombre,
         cap.subrubrica03_nombre,
         cap.subrubrica04_nombre,
         cap.subrubrica05_nombre,
         cap.subrubrica06_nombre,
         cap.subrubrica07_nombre,
         cap.subrubrica08_nombre,
         cap.subrubrica09_nombre,
         cap.subrubrica10_nombre,
         cm.valor
    FROM capitulaciones_matriz cap
          , subrubricacion_med cm
   WHERE cap.capitulo = :capitulo
     AND cap.subrubrica = cm.subrubrica_padre
     AND cap.subrubrica01 = cm.subrubrica_hija
     AND cm.medicamento = :medicamento
     AND cm.valor = :valor
UNION
  SELECT cap.capitulo_nombre,
         cap.rubrica_nombre,
         cap.subrubrica_nombre,
         cap.subrubrica01_nombre,
         cap.subrubrica02_nombre,
         cap.subrubrica03_nombre,
         cap.subrubrica04_nombre,
         cap.subrubrica05_nombre,
         cap.subrubrica06_nombre,
         cap.subrubrica07_nombre,
         cap.subrubrica08_nombre,
         cap.subrubrica09_nombre,
         cap.subrubrica10_nombre,
         cm.valor
    FROM capitulaciones_matriz cap
          , subrubricacion_med cm
   WHERE cap.capitulo = :capitulo
     AND cap.subrubrica01 = cm.subrubrica_padre
     AND cap.subrubrica02 = cm.subrubrica_hija
     AND cm.medicamento = :medicamento
     AND cm.valor = :valor
UNION
  SELECT cap.capitulo_nombre,
         cap.rubrica_nombre,
         cap.subrubrica_nombre,
         cap.subrubrica01_nombre,
         cap.subrubrica02_nombre,
         cap.subrubrica03_nombre,
         cap.subrubrica04_nombre,
         cap.subrubrica05_nombre,
         cap.subrubrica06_nombre,
         cap.subrubrica07_nombre,
         cap.subrubrica08_nombre,
         cap.subrubrica09_nombre,
         cap.subrubrica10_nombre,
         cm.valor
    FROM capitulaciones_matriz cap
          , subrubricacion_med cm
   WHERE cap.capitulo = :capitulo
     AND cap.subrubrica02 = cm.subrubrica_padre
     AND cap.subrubrica03 = cm.subrubrica_hija
     AND cm.medicamento = :medicamento
     AND cm.valor = :valor
UNION
  SELECT cap.capitulo_nombre,
         cap.rubrica_nombre,
         cap.subrubrica_nombre,
         cap.subrubrica01_nombre,
         cap.subrubrica02_nombre,
         cap.subrubrica03_nombre,
         cap.subrubrica04_nombre,
         cap.subrubrica05_nombre,
         cap.subrubrica06_nombre,
         cap.subrubrica07_nombre,
         cap.subrubrica08_nombre,
         cap.subrubrica09_nombre,
         cap.subrubrica10_nombre,
         cm.valor
    FROM capitulaciones_matriz cap
          , subrubricacion_med cm
   WHERE cap.capitulo = :capitulo
     AND cap.subrubrica03 = cm.subrubrica_padre
     AND cap.subrubrica04 = cm.subrubrica_hija
     AND cm.medicamento = :medicamento
     AND cm.valor = :valor
UNION
  SELECT cap.capitulo_nombre,
         cap.rubrica_nombre,
         cap.subrubrica_nombre,
         cap.subrubrica01_nombre,
         cap.subrubrica02_nombre,
         cap.subrubrica03_nombre,
         cap.subrubrica04_nombre,
         cap.subrubrica05_nombre,
         cap.subrubrica06_nombre,
         cap.subrubrica07_nombre,
         cap.subrubrica08_nombre,
         cap.subrubrica09_nombre,
         cap.subrubrica10_nombre,
         cm.valor
    FROM capitulaciones_matriz cap
          , subrubricacion_med cm
   WHERE cap.capitulo = :capitulo
     AND cap.subrubrica04 = cm.subrubrica_padre
     AND cap.subrubrica05 = cm.subrubrica_hija
     AND cm.medicamento = :medicamento
     AND cm.valor = :valor
UNION
  SELECT cap.capitulo_nombre,
         cap.rubrica_nombre,
         cap.subrubrica_nombre,
         cap.subrubrica01_nombre,
         cap.subrubrica02_nombre,
         cap.subrubrica03_nombre,
         cap.subrubrica04_nombre,
         cap.subrubrica05_nombre,
         cap.subrubrica06_nombre,
         cap.subrubrica07_nombre,
         cap.subrubrica08_nombre,
         cap.subrubrica09_nombre,
         cap.subrubrica10_nombre,
         cm.valor
    FROM capitulaciones_matriz cap
          , subrubricacion_med cm
   WHERE cap.capitulo = :capitulo
     AND cap.subrubrica05 = cm.subrubrica_padre
     AND cap.subrubrica06 = cm.subrubrica_hija
     AND cm.medicamento = :medicamento
     AND cm.valor = :valor
UNION
  SELECT cap.capitulo_nombre,
         cap.rubrica_nombre,
         cap.subrubrica_nombre,
         cap.subrubrica01_nombre,
         cap.subrubrica02_nombre,
         cap.subrubrica03_nombre,
         cap.subrubrica04_nombre,
         cap.subrubrica05_nombre,
         cap.subrubrica06_nombre,
         cap.subrubrica07_nombre,
         cap.subrubrica08_nombre,
         cap.subrubrica09_nombre,
         cap.subrubrica10_nombre,
         cm.valor
    FROM capitulaciones_matriz cap
          , subrubricacion_med cm
   WHERE cap.capitulo = :capitulo
     AND cap.subrubrica06 = cm.subrubrica_padre
     AND cap.subrubrica07 = cm.subrubrica_hija
     AND cm.medicamento = :medicamento
     AND cm.valor = :valor
UNION
  SELECT cap.capitulo_nombre,
         cap.rubrica_nombre,
         cap.subrubrica_nombre,
         cap.subrubrica01_nombre,
         cap.subrubrica02_nombre,
         cap.subrubrica03_nombre,
         cap.subrubrica04_nombre,
         cap.subrubrica05_nombre,
         cap.subrubrica06_nombre,
         cap.subrubrica07_nombre,
         cap.subrubrica08_nombre,
         cap.subrubrica09_nombre,
         cap.subrubrica10_nombre,
         cm.valor
    FROM capitulaciones_matriz cap
          , subrubricacion_med cm
   WHERE cap.capitulo = :capitulo
     AND cap.subrubrica07 = cm.subrubrica_padre
     AND cap.subrubrica08 = cm.subrubrica_hija
     AND cm.medicamento = :medicamento
     AND cm.valor = :valor
UNION
  SELECT cap.capitulo_nombre,
         cap.rubrica_nombre,
         cap.subrubrica_nombre,
         cap.subrubrica01_nombre,
         cap.subrubrica02_nombre,
         cap.subrubrica03_nombre,
         cap.subrubrica04_nombre,
         cap.subrubrica05_nombre,
         cap.subrubrica06_nombre,
         cap.subrubrica07_nombre,
         cap.subrubrica08_nombre,
         cap.subrubrica09_nombre,
         cap.subrubrica10_nombre,
         cm.valor
    FROM capitulaciones_matriz cap
          , subrubricacion_med cm
   WHERE cap.capitulo = :capitulo
     AND cap.subrubrica08 = cm.subrubrica_padre
     AND cap.subrubrica09 = cm.subrubrica_hija
     AND cm.medicamento = :medicamento
     AND cm.valor = :valor
UNION
  SELECT cap.capitulo_nombre,
         cap.rubrica_nombre,
         cap.subrubrica_nombre,
         cap.subrubrica01_nombre,
         cap.subrubrica02_nombre,
         cap.subrubrica03_nombre,
         cap.subrubrica04_nombre,
         cap.subrubrica05_nombre,
         cap.subrubrica06_nombre,
         cap.subrubrica07_nombre,
         cap.subrubrica08_nombre,
         cap.subrubrica09_nombre,
         cap.subrubrica10_nombre,
         cm.valor
    FROM capitulaciones_matriz cap
          , subrubricacion_med cm
   WHERE cap.capitulo = :capitulo
     AND cap.subrubrica09 = cm.subrubrica_padre
     AND cap.subrubrica10 = cm.subrubrica_hija
     AND cm.medicamento = :medicamento
     AND cm.valor = :valor
ORDER BY 1,2,3
";
    }
}
