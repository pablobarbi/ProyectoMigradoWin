﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class d_operacion : IDataWindowMetadata
    {
        public string DataObject => "d_operacion";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "operacion",
                DbName = "acc_operaciones.operacion",
                Tipo = "char(8)",
                EsClave = true,
                TabOrder = 10
            },
            new DataWindowColumn
            {
                Nombre = "nombre",
                DbName = "acc_operaciones.nombre",
                Tipo = "char(40)",
                TabOrder = 20
            },
            new DataWindowColumn
            {
                Nombre = "bitmap",
                DbName = "acc_operaciones.bitmap",
                Tipo = "char(40)",
                TabOrder = null // no está en orden visual
            }
        };

        public string Sql => @"
SELECT dba.acc_operaciones.operacion,
       dba.acc_operaciones.nombre,
       dba.acc_operaciones.bitmap
  FROM dba.acc_operaciones
 WHERE dba.acc_operaciones.operacion = :operacion
 ORDER BY operacion ASC
";

        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
