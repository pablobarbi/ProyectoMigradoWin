﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    /// <summary>
    /// Metadata para d_system_error
    /// </summary>
    public class d_system_error : IDataWindowMetadata
    {
        public string DataObject => "d_system_error";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "nro_error",
                DbName = "errores_sistema.nro_error",
                Tipo = "long",
                EsClave = true
            },
            new DataWindowColumn
            {
                Nombre = "fecha_hora",
                DbName = "errores_sistema.fecha_hora",
                Tipo = "datetime",
                EsClave = true
            },
            new DataWindowColumn
            {
                Nombre = "lugar",
                DbName = "errores_sistema.lugar",
                Tipo = "char(255)"
            },
            new DataWindowColumn
            {
                Nombre = "evento",
                DbName = "errores_sistema.evento",
                Tipo = "char(255)"
            },
            new DataWindowColumn
            {
                Nombre = "objeto",
                DbName = "errores_sistema.objeto",
                Tipo = "char(255)"
            },
            new DataWindowColumn
            {
                Nombre = "linea_script",
                DbName = "errores_sistema.linea_script",
                Tipo = "long"
            },
            new DataWindowColumn
            {
                Nombre = "mensaje_error",
                DbName = "errores_sistema.mensaje_error",
                Tipo = "char(255)"
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
