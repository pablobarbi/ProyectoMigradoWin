﻿using System.Collections.Generic;
using System.Security.Principal;

namespace Minotti.Metadata.Generated
{
    public class dw_submodulos : IDataWindowMetadata
    {
        public string DataObject => "dw_submodulos";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn("submodulo", "string")
            {
                EsClavePrimaria= true,
                EsIdentity= false
            },
            new DataWindowColumn( "nombre", "string")
            {
                EsClavePrimaria= false,
                EsIdentity= false
            }
        };

        public string sql => @"
SELECT acc_submodulos.submodulo,   
       acc_submodulos.nombre  
  FROM acc_submodulos
";

        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
