﻿using Minotti.Metadata;
using System.Collections.Generic;

namespace MinottiApp.Metadata.Generated
{
    public class dsto_actualiza_subrubricas : IDataWindowMetadata
    {
        public string DataObject => "dsto_actualiza_subrubricas";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn("subrubrica", "decimal(0)")
            {
                DbName = "subrubricas.subrubrica",
                EsClave = true,
                EsIdentity = true
            },
            new DataWindowColumn("nombre", "char(255)")
            {
                DbName = "subrubricas.nombre"
            }
        };

        public string Sql => @"
SELECT subrubricas.subrubrica,
       subrubricas.nombre
  FROM subrubricas
";

        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
