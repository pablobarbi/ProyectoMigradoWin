﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    /// <summary>
    /// Metadata para d_usuario
    /// </summary>
    public class d_usuario : IDataWindowMetadata
    {
        public string DataObject => "d_usuario";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "usuario",
                DbName = "acc_usuarios.usuario",
                Tipo = "char(8)",
                EsClave = true,
                ObjetoSeleccion = null,
                EsRequerido = true,
                TabOrder = 10
            },
            new DataWindowColumn
            {
                Nombre = "nombre",
                DbName = "acc_usuarios.nombre",
                Tipo = "char(50)",
                EsRequerido = true,
                TabOrder = 20
            },
            new DataWindowColumn
            {
                Nombre = "clave",
                DbName = "acc_usuarios.clave",
                Tipo = "char(40)",
                EsRequerido = true,
                TabOrder = 30
            },
            new DataWindowColumn
            {
                Nombre = "perfil",
                DbName = "acc_usuarios.perfil",
                Tipo = "char(8)",
                ObjetoSeleccion = "dw_perfiles",
                TabOrder = 40
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
