﻿using Minotti.Metadata;

namespace MinottiApp.Metadata.Generated
{
    public class dks_modulos_no_estan_perfil : IDataWindowMetadata
    {
        public string DataObject => "dks_modulos_no_estan_perfil";

        public List<DataWindowColumn> Columns { get; } = new()
        {
            new DataWindowColumn("modulo", "char(8)")
            {
                DbName = "acc_modulos.modulo",
                EsClave = true
            },
            new DataWindowColumn("nombre", "char(40)")
            {
                DbName = "acc_modulos.nombre"
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
