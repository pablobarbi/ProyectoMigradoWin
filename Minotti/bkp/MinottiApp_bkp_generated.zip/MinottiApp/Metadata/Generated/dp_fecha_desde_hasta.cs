﻿using Minotti.Metadata;
using System;
using System.Collections.Generic;

namespace Minotti.Metadata.Generated
{
    public class dp_fecha_desde_hasta : IDataWindowMetadata
    {
        public string DataObject => "dp_fecha_desde_hasta";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "fecha_desde",
                DbName = "diagnosticos.fecha_desde",
                Tipo = "date",
                Titulo = "Fecha Desde",
                EsClave = true,
                EsRequerido = true,
                TabOrder = 10,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "fecha_hasta",
                DbName = "diagnosticos.fecha_hasta",
                Tipo = "date",
                Titulo = "Fecha Hasta",
                EsClave = true,
                EsRequerido = true,
                TabOrder = 20,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            }
        };

        // ⇩ Propiedades según SRD ⇩
        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;

        public string Sql => @"
SELECT diagnosticos.fecha_visita as fecha_desde,
       diagnosticos.fecha_visita as fecha_hasta
  FROM diagnosticos
";
    }
}
