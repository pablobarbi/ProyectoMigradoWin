﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class d_buscar : IDataWindowMetadata
    {
        public string DataObject => "d_buscar";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "campo",
                Tipo = "char(60)",
                Titulo = string.Empty,
                EsClave = false,
                EsRequerido = false,
                //Estilos = null,
                ObjetoSeleccion = null,
                Operacion = null,
                NivelOperacion = null,
                TabOrder = 10
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
