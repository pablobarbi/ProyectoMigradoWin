﻿using Minotti.Metadata;
using System;
using System.Collections.Generic;

namespace Minotti.Metadata.Generated
{
    public class dr_actualizar_matriz : IDataWindowMetadata
    {
        public string DataObject => "dr_actualizar_matriz";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "renglon",
                DbName = "renglon",
                Tipo = "char(150)",
                Titulo = string.Empty,
                EsClave = false,
                EsClavePrimaria = false,
                EsIdentity = false,
                EsRequerido = false,
                TabOrder = 10,
                Valores = Array.Empty<string>()
            }
        };

        // ⇩ Metadata no definida en el SRD ⇩
        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;

        // ⇩ No hay SQL retrieve ⇩
        public string Sql => string.Empty;
    }
}
