﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    /// <summary>
    /// Menúes. Lista de los submódulos que tienen asignados las operaciones de los distintos módulos.
    /// </summary>
    public class d_sub_modulos_x_perfil : IDataWindowMetadata
    {
        public string DataObject => "d_sub_modulos_x_perfil";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "submodulo",
                DbName = "submodulo",
                Tipo = "char(18)"
            },
            new DataWindowColumn
            {
                Nombre = "nombre",
                DbName = "acc_submodulos.nombre",
                Tipo = "char(40)"
            },
            new DataWindowColumn
            {
                Nombre = "acc_operaciones_x_modulo_modulo",
                DbName = "acc_operaciones_x_modulo.modulo",
                Tipo = "char(5)"
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
