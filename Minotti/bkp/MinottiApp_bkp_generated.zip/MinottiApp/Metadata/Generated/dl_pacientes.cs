﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class dl_pacientes : IDataWindowMetadata
    {
        public string DataObject => "dl_pacientes";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "paciente",
                DbName = "pacientes.paciente",
                Tipo = "long",
                Titulo = string.Empty,
                EsClave = true,
                EsRequerido = false,
                ObjetoSeleccion = null,
                Operacion = null,
                NivelOperacion = null,
                TabOrder = null,
                EsClavePrimaria = true,
                EsIdentity = true,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "nombre",
                DbName = "pacientes.nombre",
                Tipo = "char(50)",
                Titulo = "Nombre y Apellido:",
                EsClave = false,
                EsRequerido = false,
                ObjetoSeleccion = null,
                Operacion = null,
                NivelOperacion = null,
                TabOrder = 32766,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "domicilio",
                DbName = "pacientes.domicilio",
                Tipo = "char(50)",
                Titulo = "Domicilio:",
                EsClave = false,
                EsRequerido = false,
                ObjetoSeleccion = null,
                Operacion = null,
                NivelOperacion = null,
                TabOrder = 32766,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "telefono",
                DbName = "pacientes.telefono",
                Tipo = "char(15)",
                Titulo = "Telefono:",
                EsClave = false,
                EsRequerido = false,
                ObjetoSeleccion = null,
                Operacion = null,
                NivelOperacion = null,
                TabOrder = 32766,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "sexo",
                DbName = "pacientes.sexo",
                Tipo = "char(1)",
                Titulo = "Sexo:",
                EsClave = false,
                EsRequerido = false,
                ObjetoSeleccion = null,
                Operacion = null,
                NivelOperacion = null,
                TabOrder = 32766,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = new[] { "Masculino\tM", "Femenino\tF" }
            },
            new DataWindowColumn
            {
                Nombre = "fecha_nacimiento",
                DbName = "pacientes.fecha_nacimiento",
                Tipo = "date",
                Titulo = "Fecha Nacimiento:",
                EsClave = false,
                EsRequerido = false,
                ObjetoSeleccion = null,
                Operacion = null,
                NivelOperacion = null,
                TabOrder = 32766,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "ultima_visita",
                DbName = "pacientes.ultima_visita",
                Tipo = "date",
                Titulo = "Ultima Visita:",
                EsClave = false,
                EsRequerido = false,
                ObjetoSeleccion = null,
                Operacion = null,
                NivelOperacion = null,
                TabOrder = 32766,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "ocupacion",
                DbName = "pacientes.ocupacion",
                Tipo = "char(50)",
                Titulo = "Ocupación:",
                EsClave = false,
                EsRequerido = false,
                ObjetoSeleccion = null,
                Operacion = null,
                NivelOperacion = null,
                TabOrder = 32766,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "estado_civil",
                DbName = "pacientes.estado_civil",
                Tipo = "long",
                Titulo = "Estado Civil:",
                EsClave = false,
                EsRequerido = false,
                ObjetoSeleccion = "dw_estado_civil",
                Operacion = null,
                NivelOperacion = null,
                TabOrder = 32766,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "cantidad_hijos",
                DbName = "pacientes.cantidad_hijos",
                Tipo = "long",
                Titulo = "Cantidad Hijos:",
                EsClave = false,
                EsRequerido = false,
                ObjetoSeleccion = null,
                Operacion = null,
                NivelOperacion = null,
                TabOrder = 32766,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;

        public string Sql => @"
SELECT pacientes.paciente,
       pacientes.nombre,
       pacientes.domicilio,
       pacientes.telefono,
       pacientes.sexo,
       pacientes.fecha_nacimiento,
       pacientes.ultima_visita,
       pacientes.ocupacion,
       pacientes.estado_civil,
       pacientes.cantidad_hijos
  FROM pacientes
 WHERE (pacientes.paciente = :paciente) OR (:paciente = '')
";
    }
}
