﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class d_agregar_capitulos : IDataWindowMetadata
    {
        public string DataObject => "d_agregar_capitulos";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "nombre",
                Tipo = "char(255)",
                Titulo = "Capitulo:",
                EsClave = false,
                EsRequerido = false,
                //Estilos = null,
                ObjetoSeleccion = null,
                Operacion = null,
                NivelOperacion = null,
                TabOrder = 10
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;

        public string SQL = @"
SELECT capitulos.nombre
  FROM capitulos
 WHERE capitulos.capitulo = ?
";

        // 🔴 ESTO ES LO NUEVO 🔴
        // === PB: table.update ===
        public string Update => "capitulos";

        // === PB: updatewhere ===
        // 0 = usa claves
        // 1 = usa todas las columnas
        public int UpdateWhere => 0;
    }
}
