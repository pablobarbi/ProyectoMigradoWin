﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    /// <summary>
    /// Metadata para dk_mig_subrubricas
    /// </summary>
    public class dk_mig_subrubricas : IDataWindowMetadata
    {
        public string DataObject => "dk_mig_subrubricas";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "capitulo",
                DbName = "mig_subrubricas.capitulo",
                Tipo = "number",
                TabOrder = 10
            },
            new DataWindowColumn
            {
                Nombre = "padre",
                DbName = "mig_subrubricas.padre",
                Tipo = "number",
                TabOrder = 20
            },
            new DataWindowColumn
            {
                Nombre = "codigo",
                DbName = "mig_subrubricas.codigo",
                Tipo = "number",
                TabOrder = 30
            },
            new DataWindowColumn
            {
                Nombre = "descripcio",
                DbName = "mig_subrubricas.descripcio",
                Tipo = "char(255)",
                TabOrder = 40
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
