﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class dp_capitulos : IDataWindowMetadata
    {
        public string DataObject => "dp_capitulos";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "capitulo",
                DbName = "capitulos.capitulo",
                Tipo = "decimal(0)",
                Titulo = "Capítulo",
                EsClave = true,
                EsRequerido = false,
                TabOrder = 10,
                EsClavePrimaria = true,
                EsIdentity = true,
                Valores = Array.Empty<string>()
            }
        };

        // ⇩ El SRD no define nada adicional ⇩
        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;

        public string Sql => @"
SELECT capitulos.capitulo
  FROM capitulos
";
    }
}
