﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class dl_pacientes_historia_clinica : IDataWindowMetadata
    {
        public string DataObject => "dl_pacientes_historia_clinica";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "paciente",
                DbName = "pacientes_historias.paciente",
                Tipo = "long",
                Titulo = "Paciente:",
                EsClave = true,
                EsRequerido = false,
                ObjetoSeleccion = "dw_pacientes",
                Operacion = null,
                NivelOperacion = null,
                TabOrder = 32766,
                EsClavePrimaria = true,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            },
            new DataWindowColumn
            {
                Nombre = "hist_clin",
                DbName = "pacientes_historias.hist_clin",
                Tipo = "char(32766)",
                Titulo = "Detalle",
                EsClave = false,
                EsRequerido = true,
                ObjetoSeleccion = null,
                Operacion = null,
                NivelOperacion = null,
                TabOrder = 32766,
                EsClavePrimaria = false,
                EsIdentity = false,
                Valores = Array.Empty<string>()
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;

        public string Sql => @"
SELECT pacientes_historias.paciente,
       pacientes_historias.hist_clin
  FROM pacientes_historias
 WHERE pacientes_historias.paciente = :paciente
";
    }
}
