﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class d_pacientes_hist_clinica : IDataWindowMetadata
    {
        public string DataObject => "d_pacientes_hist_clinica";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "paciente",
                DbName = "pacientes_historias.paciente",
                Tipo = "long",
                EsClavePrimaria = true
            },
            new DataWindowColumn
            {
                Nombre = "hist_clin",
                DbName = "pacientes_historias.hist_clin",
                Tipo = "char(32766)"
            }
        };

        public string Sql => @"
SELECT pacientes_historias.paciente,
       pacientes_historias.hist_clin
  FROM pacientes_historias
 WHERE pacientes_historias.paciente = :paciente
";

        public string[] Estilos => Array.Empty<string>();
        public string[] SeleccionFila => Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
