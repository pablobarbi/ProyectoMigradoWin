﻿using System.Collections.Generic;
using System.Security.Principal;

namespace Minotti.Metadata.Generated
{
    public class dw_pacientes : IDataWindowMetadata
    {
        public string DataObject => "dw_pacientes";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn("nombre", "string")
            {
                EsClavePrimaria= false,
                EsIdentity= false
            }
        };

        public string sql => @"
SELECT nombre
  FROM pacientes
 ORDER BY 1
";

        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
