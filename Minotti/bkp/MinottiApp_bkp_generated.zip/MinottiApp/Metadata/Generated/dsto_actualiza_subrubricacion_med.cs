﻿using Minotti.Metadata;
using System.Collections.Generic;

namespace MinottiApp.Metadata.Generated
{
    public class dsto_actualiza_subrubricacion_med : IDataWindowMetadata
    {
        public string DataObject => "dsto_actualiza_subrubricacion_med";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn("subrubrica_padre", "decimal(0)")
            {
                DbName = "subrubricacion_med.subrubrica_padre",
                EsClave = true
            },
            new DataWindowColumn("subrubrica_hija", "decimal(0)")
            {
                DbName = "subrubricacion_med.subrubrica_hija",
                EsClave = true
            },
            new DataWindowColumn("medicamento", "char(10)")
            {
                DbName = "subrubricacion_med.medicamento",
                EsClave = true
            },
            new DataWindowColumn("valor", "long")
            {
                DbName = "subrubricacion_med.valor"
            }
        };

        public string Sql => @"
SELECT subrubricacion_med.subrubrica_padre,
       subrubricacion_med.subrubrica_hija,
       subrubricacion_med.medicamento,
       subrubricacion_med.valor
  FROM subrubricacion_med
WHERE subrubricacion_med.subrubrica_padre = :padre
 AND   subrubricacion_med.subrubrica_hija = :hija
";

        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();
        public string Operaciones => string.Empty;
        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
