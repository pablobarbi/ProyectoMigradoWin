﻿using System.Collections.Generic;
using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    public class dr_operaciones : IDataWindowMetadata
    {
        public string DataObject => "dr_operaciones";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "operacion",
                DbName = "acc_operaciones.operacion",
                Tipo = "char(8)",
                Titulo = "Operación",
                EsClave = true,
                EsClavePrimaria = true,
                EsIdentity = false,
                TabOrder = 10
            },
            new DataWindowColumn
            {
                Nombre = "nombre",
                DbName = "acc_operaciones.nombre",
                Tipo = "char(40)",
                Titulo = "Nombre",
                TabOrder = 20
            },
            new DataWindowColumn
            {
                Nombre = "bitmap",
                DbName = "acc_operaciones.bitmap",
                Tipo = "char(40)",
                Titulo = "Bitmap"
            }
        };

        public string[] Estilos => System.Array.Empty<string>();

        public string[] SeleccionFila => System.Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;

        public string Sql => @"
SELECT dba.acc_operaciones.operacion,
       dba.acc_operaciones.nombre,
       dba.acc_operaciones.bitmap
  FROM dba.acc_operaciones
 ORDER BY dba.acc_operaciones.nombre
";
    }
}
