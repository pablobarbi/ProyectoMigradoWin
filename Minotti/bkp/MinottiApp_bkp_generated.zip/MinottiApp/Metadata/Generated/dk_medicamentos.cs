﻿using Minotti.Metadata;

namespace Minotti.Metadata.Generated
{
    /// <summary>
    /// Metadata para dk_medicamentos
    /// </summary>
    public class dk_medicamentos : IDataWindowMetadata
    {
        public string DataObject => "dk_medicamentos";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn
            {
                Nombre = "medicamento",
                DbName = "medicamentos.medicamento",
                Tipo = "char(10)",
                EsClave = true,
                TabOrder = 10
            },
            new DataWindowColumn
            {
                Nombre = "descripcion",
                DbName = "medicamentos.descripcion",
                Tipo = "char(50)",
                TabOrder = 20
            }
        };

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
