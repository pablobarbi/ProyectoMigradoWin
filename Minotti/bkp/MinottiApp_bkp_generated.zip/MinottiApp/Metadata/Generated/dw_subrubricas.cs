﻿using System.Collections.Generic;
using System.Security.Principal;

namespace Minotti.Metadata.Generated
{
    public class dw_subrubricas : IDataWindowMetadata
    {
        public string DataObject => "dw_subrubricas";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn("subrubrica", "decimal")
            {
                EsClavePrimaria= true,
                EsIdentity= true
            },
            new DataWindowColumn("nombre", "string")
            {
                EsClavePrimaria= true,
                EsIdentity= true
            }
                
        };

        public string sql => @"
SELECT subrubricas.subrubrica,
       subrubricas.nombre
  FROM subrubricas
ORDER BY 2
";

        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
