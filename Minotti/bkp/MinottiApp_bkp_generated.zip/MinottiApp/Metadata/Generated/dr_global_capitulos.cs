﻿using Minotti.Metadata;
using System;
using System.Collections.Generic;

namespace Minotti.Metadata.Generated
{
    public class dr_global_capitulos : IDataWindowMetadata
    {
        public string DataObject => "dr_global_capitulos";

        public List<DataWindowColumn> Columns => new()
        {
                new()
                {
                    Nombre = "capitulo",
                    DbName = "capitulos.capitulo",
                    Tipo = "decimal(0)",
                    EsClave = true,
                    EsClavePrimaria = true,
                    EsIdentity = true
                },
                new()
                {
                    Nombre = "nombre",
                    DbName = "capitulos.nombre",
                    Tipo = "char(255)"
                }
        };

        public string Sql => @"SELECT capitulos.capitulo,
                                      capitulos.nombre
                              FROM capitulos
                             WHERE capitulos.nombre LIKE :campo";

        public string[] Estilos => Array.Empty<string>();

        public string[] SeleccionFila => Array.Empty<string>();

        public string Operaciones => "update";

        public bool UsaUsuario => false;

        public bool UsaFecha => false;
    }
}
