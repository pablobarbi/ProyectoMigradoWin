﻿using System.Collections.Generic;
using System.Security.Principal;

namespace Minotti.Metadata.Generated
{
    public class dw_perfiles : IDataWindowMetadata
    {
        public string DataObject => "dw_perfiles";

        public List<DataWindowColumn> Columns => new()
        {
            new DataWindowColumn("perfil", "string")
            {
                
                EsClavePrimaria= true,
                EsIdentity= false
            },
            new DataWindowColumn( "nombre", "string")
            {
                EsClavePrimaria= false,
                EsIdentity= false
            }
                
            
        };

        public string sql => @"
SELECT dba.acc_perfiles.perfil,
       dba.acc_perfiles.nombre
  FROM dba.acc_perfiles
 ORDER BY dba.acc_perfiles.nombre
";

        public string[] Estilos => System.Array.Empty<string>();
        public string[] SeleccionFila => System.Array.Empty<string>();

        public string Operaciones => string.Empty;

        public bool UsaUsuario => false;
        public bool UsaFecha => false;
    }
}
