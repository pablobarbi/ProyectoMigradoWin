﻿

namespace Minotti.Metadata
{
    public interface IDataWindowMetadata
    {
        // ===============================
        // Identidad
        // ===============================
        string DataObject { get; }

        // ===============================
        // Columnas (table.column)
        // ===============================
        List<DataWindowColumn> Columns { get; }

        // ===============================
        // PB: table.retrieve
        // ===============================
        string? Retrieve { get; }

        // ===============================
        // PB: table.update
        // ===============================
        string? Update { get; }

        // ===============================
        // PB: updatewhere
        // 0 = claves
        // 1 = todas las columnas
        // ===============================
        int? UpdateWhere { get; }

        // ===============================
        // PB: updatekeyinplace
        // ===============================
        bool? UpdateKeyInPlace { get; }

        // ===============================
        // Metadata funcional existente
        // ===============================
        string[] Estilos { get; }
        string[] SeleccionFila { get; }
        string Operaciones { get; }
        bool UsaUsuario { get; }
        bool UsaFecha { get; }
    }


    public class DataWindowColumn
    {
        public DataWindowColumn() { }

        public DataWindowColumn(string nombre, string tipo)
        {
            Nombre = nombre;
            Tipo = tipo;
        }

        // ===============================
        // PB: column(name=)
        // ===============================
        public string Nombre { get; set; } = string.Empty;

        // PB: column(dbname=)
        public string DbName { get; set; } = string.Empty;

        // PB: column(type=)
        public string Tipo { get; set; } = string.Empty;

        // PB: text(... name=xxx_t)
        public string Titulo { get; set; } = string.Empty;

        // PB: key=yes
        public bool EsClave { get; set; } = false;

        // PB: edit.required / ddlb.required / dddw.required
        public bool EsRequerido { get; set; } = false;

        // PB: xx_recuperar_fk
        public string? ObjetoSeleccion { get; set; }

        // PB: xx_operaciones
        public string? Operacion { get; set; }
        public string? NivelOperacion { get; set; }

        // PB: tabsequence
        public int? TabOrder { get; set; }

        // ===============================
        // Flags internos PB
        // ===============================
        public bool EsClavePrimaria { get; set; } = false;
        public bool EsIdentity { get; set; } = false;

        // PB: DDDW / valores
        public string[] Valores { get; set; } = Array.Empty<string>();
    }



}

