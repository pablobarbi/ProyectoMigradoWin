﻿using Minotti.Data;
using Minotti.Metadata;
using Minotti.Metadata.Generated;
using Minotti.utils;
using MinottiApp.Metadata.Generated;
using System.Collections.Generic;
using System.Data.Common;
using System.Transactions;

namespace MinottiApp.Metadata
{
    public static class MetadataFactory
    {
        private static readonly Dictionary<string, IDataWindowMetadata> _map = new()
        {


            {"d_valor_inicial", new d_valor_inicial() },


            // =========================
            // Catálogo general
            // =========================
            { "d_agregar_capitulos", new d_agregar_capitulos() },
            { "d_agregar_rubricas", new d_agregar_rubricas() },
            { "d_agregar_subrubricas", new d_agregar_subrubricas() },
            { "d_ayuda", new d_ayuda() },
            { "d_buscar", new d_buscar() },
            { "d_campos_invisibles", new d_campos_invisibles() },
            { "d_carpetas", new d_carpetas() },
            { "d_diagnosticos", new d_diagnosticos() },
            { "d_medicamentos", new d_medicamentos() },
            { "d_medicamentos_sin_blob", new d_medicamentos_sin_blob() },
            { "d_modulo", new d_modulo() },
            { "d_modulos_por_perfil", new d_modulos_por_perfil() },
            { "d_modulos_x_perfil2", new d_modulos_x_perfil2() },
            { "d_operacion", new d_operacion() },
            { "d_operaciones", new d_operaciones() },
            { "d_operaciones_x_modulo", new d_operaciones_x_modulo() },
            { "d_operaciones_x_modulo__", new d_operaciones_x_modulo__() },
            { "d_operaciones_x_perfil", new d_operaciones_x_perfil() },
            { "d_operaciones_x_perfil_sub_modulo", new d_operaciones_x_perfil_sub_modulo() },
            { "d_pacientes", new d_pacientes() },
            { "d_pacientes_hist_clinica", new d_pacientes_hist_clinica() },
            { "d_param_x_operacion", new d_param_x_operacion() },
            { "d_parametros", new d_parametros() },
            { "d_parametros_x_operacion", new d_parametros_x_operacion() },
            { "d_perfil", new d_perfil() },
            { "d_perfiles_x_usuario", new d_perfiles_x_usuario() },

            // =========================
            // Repertorios
            // =========================
            { "d_reperto_total", new d_reperto_total() },
            { "d_reperto_total_diagnosticos", new d_reperto_total_diagnosticos() },
            { "d_reperto_total_diagnosticos_multiple", new d_reperto_total_diagnosticos_multiple() },
            { "d_reperto_total_diagnosticos_ver", new d_reperto_total_diagnosticos_ver() },
            { "d_reperto_total_medicamentos", new d_reperto_total_medicamentos() },
            { "d_reperto_total_sintomas", new d_reperto_total_sintomas() },

            // =========================
            // DataStores / DataWindows
            // =========================
            { "dsto_reperto_total", new dsto_reperto_total() },

            // =========================
            // Duo / relaciones
            // =========================
            { "duo_capitulaciones", new duo_capitulaciones() },
            { "duo_capitulaciones_med", new duo_capitulaciones_med() },
            { "duo_rubricaciones", new duo_rubricaciones() },
            { "duo_rubricaciones_med", new duo_rubricaciones_med() },
            { "duo_subrubricaciones_med", new duo_subrubricaciones_med() },

            // =========================
            // Calendarios
            // =========================
            { "dw_calendar_anterior", new dw_calendar_anterior() },
            { "dw_calendar_bak", new dw_calendar_bak() },

            // =========================
            // Catálogos simples
            // =========================
            { "dw_capitulos", new dw_capitulos() },
            { "dw_estado_civil", new dw_estado_civil() },
            { "dw_medicamentos", new dw_medicamentos() },
            { "dw_modulos", new dw_modulos() },
            { "dw_operaciones", new dw_operaciones() },
            { "dw_pacientes", new dw_pacientes() },
            { "dw_pacientes_mas_todos", new dw_pacientes_mas_todos() },
            { "dw_perfiles", new dw_perfiles() },
            { "dw_rubricas", new dw_rubricas() },
            { "dw_submodulos", new dw_submodulos() },
            { "dw_subrubricas", new dw_subrubricas() },
            { "dw_usuarios", new dw_usuarios() },

            // =========================
            // Reportes
            // =========================
            { "r_header", new r_header() },
            { "r_header_landscape", new r_header_landscape() },
            { "r_summary", new r_summary() },



            { "dk_pacientes", new dk_pacientes() },
        };

        public static IDataWindowMetadata Get(string dataObject)
        {
            if (!_map.TryGetValue(dataObject, out var metadata))
                throw new KeyNotFoundException($"No se encontró metadata para el DataObject '{dataObject}'.");

            return metadata;
        }


        /// <summary>
        /// PB-like: crea un datastore usando metadata + SQLCA
        /// El SQL se toma del SRD asociado al DataObject
        /// </summary>
        public static datastore CreateDataStore(string dataObject)
        {
            if (string.IsNullOrWhiteSpace(dataObject))
                throw new ArgumentException("DataObject vacío", nameof(dataObject));

            // valida que exista metadata
            var metadata = Get(dataObject);

            var ds = new datastore();
            ds.SetTransObject(SQLCA.Instance);
            ds.DataObject = metadata.DataObject;

            return ds;
        }


    }
}
