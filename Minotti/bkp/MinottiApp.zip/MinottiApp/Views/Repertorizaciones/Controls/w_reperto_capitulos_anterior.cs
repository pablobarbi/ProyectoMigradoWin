using Minotti.Data;
using Minotti.Views.Basicos;
using Minotti.Views.Pbl.Views;
using System;
using System.Data;
using System.Data.Odbc;
using System.Windows.Forms;

namespace Minotti.Views.Repertorizaciones.Controls

{
    /// <summary>
    /// Migrado desde PB Window 'w_reperto_capitulos_anterior' (deriva de w_abm_lista_seleccion).
    /// Se preservan nombres y se integra la lógica visible (sin inventar).
    /// </summary>
    public partial class w_reperto_capitulos_anterior : w_operacion
    {
        public w_reperto_capitulos_anterior()
        {
            InitializeComponent();
        }

        // =================================================
        // PB: create
        // =================================================
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
        }

        // =================================================
        // PB: ue_leer_parametros
        // =================================================
        protected override void ue_leer_parametros()
        {
            base.ue_leer_parametros();

            /*
             * DataObject tomado del SRW:
             * w_reperto_capitulos_anterior.srw
             */
            dw_1.uof_setdataobject("dk_reperto_capitulos_anterior");
            dw_1.SetTransObject(SQLCA.Instance);

            dw_1.uof_marcar_seleccion(1);

            dw_1.Border = true;
            dw_1.BorderStyle = BorderStyle.Fixed3D;

            dw_1.cant_filas = 5;
        }

        // =================================================
        // PB: ue_iniciar
        // =================================================
        protected override void ue_iniciar()
        {
            base.ue_iniciar();

            // Retrieve SIN parámetros
            dw_1.uof_retrieve();
        }

        // =================================================
        // PB: destroy
        // =================================================
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            base.OnFormClosed(e);
        }
    }
}