using System.Windows.Forms;

namespace Minotti.Controls
{
    partial class uo_tp
    {
        /// <summary> 
        /// Método requerido para compatibilidad con el Diseñador.
        /// No modificar el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // uo_tp
            // 
            this.Name = "uo_tp";
            this.Text = "uo_tp";
            this.UseVisualStyleBackColor = true;
            this.ResumeLayout(false);
        }
    }
}
