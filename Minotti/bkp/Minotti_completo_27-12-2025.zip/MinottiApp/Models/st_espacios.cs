using System;

namespace Minotti.Models
{
    // Migración de PowerBuilder: st_espacios.srs (structure)
    // Se mantienen los nombres de los campos tal cual.
    public class st_espacios
    {
        public int ancho { get; set; }
        public int largo { get; set; }
        public int borde { get; set; }
    }
}
