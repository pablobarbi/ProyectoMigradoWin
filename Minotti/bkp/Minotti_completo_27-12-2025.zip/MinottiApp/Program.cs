﻿ 
using Minotti.Views.Basicos;
using Minotti.Views.Pbl.Controls;
using Minotti.Views.Pbl.Views;
using System;
using System.Windows.Forms;

namespace Minotti
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // === Application Object (PB: create sepad) ===
            var app = new uo_sepad();
            app.Open();

            AppDomain.CurrentDomain.UnhandledException += (sender, args) =>
            {
                if (args.ExceptionObject is Exception ex)
                {
                    Globales.error.number = ex.HResult;
                    Globales.error.text = ex.Message;
                }

                app.SystemError();
            };

            // === SPLASH ===
            var splash = new Minotti.Views.Basicos.w_splash();
            splash.Show();
            Application.DoEvents();

            // === LOGIN (MODAL) ===
            using var login = new w_coneccion_sepad();
            var loginResult = login.ShowDialog();

            // Canceló login → cerrar app
            if (loginResult != DialogResult.OK)
            {
                splash.Close();
                app.Close();
                app.Destroy();
                return;
            }

            // === MDI PRINCIPAL ===
            var mdi = new w_mdi();

            splash.Close();

            // 🔴 ESTE ES EL LOOP REAL DE LA APP
            Application.Run(mdi);

            // === Cleanup PB ===
            app.Close();
            app.Destroy();
        }
    }



}

