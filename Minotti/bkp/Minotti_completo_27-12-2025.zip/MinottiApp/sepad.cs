using Minotti.Views.Basicos;
using System;
using Minotti.Views.Pbl.Controls;
using System.Windows.Forms;

namespace Minotti
{
    // PB: global type sepad from application
    public class sepad  
    {
         
        public string appname { get; private set; } = "sepad";
        public bool toolbartext { get; private set; } = true;
        public string displayname { get; private set; } = "Minotti";

        public sepad()
        {
            // PB: on sepad.create
            Create();
        }

        // PB: on sepad.create
        private void Create()
        {
            appname = "sepad";

            // En PB: message=create message, sqlca=create transaction, etc.
            // En C# ya están instanciados en Globales, pero si querés
            // re-inicializarlos acá, lo podés hacer:
            Globales.message = new MessageState();
           // Globales.SQLCA = new SQLCAProxy();
            


            Globales.SQLDA = new DynamicDescriptionArea();
            Globales.SQLSA = new DynamicStagingArea();
            Globales.error = new ErrorState();
        }

        // PB: on sepad.destroy
        public void Destroy()
        {
            // En C# el GC se encarga, pero dejamos el patrón
            Globales.message = null;
           // Globales.SQLCA = null;
            Globales.SQLDA = null;
            Globales.SQLSA = null;
            Globales.error = null;
        }

        // PB: event open;
        // /* Crea el objeto con todas las facilidades de la aplicación */
        // guo_app = CREATE uo_sepad
        // guo_app.Event Trigger ue_Open()
        public void Open()
        {
            Globales.guo_app = new uo_sepad();
            Globales.guo_app.ue_open();
        }

        // PB: event close; DESTROY uo_app
        public void Close()
        {
            if (Globales.guo_app != null)
            {
                Globales.guo_app.Dispose();
                Globales.guo_app = null;
            }
        }

        // PB: event systemerror; Open(w_system_error)
        public void SystemError()
        {
            using (var frm = new w_system_error())
            {
                frm.ShowDialog();
            }
        }

        // Si querés un Run equivalente al ciclo principal de la app:
        public void Run()
        {
            //Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);

            System.Windows.Forms.Application.EnableVisualStyles();
            System.Windows.Forms.Application.SetCompatibleTextRenderingDefault(false);

            // Hook de errores globales → w_system_error (como systemerror)
            AppDomain.CurrentDomain.UnhandledException += (sender, args) =>
            {
                // Podés llenar Globales.error con info del Exception si querés
                var ex = args.ExceptionObject as Exception;
                if (ex != null)
                {
                    Globales.error.number = ex.HResult;
                    Globales.error.text = ex.Message;
                    // El resto (windowmenu, objeto, etc.) lo podés completar
                    // desde donde captures la excepción o dentro del form.
                }

                SystemError();
            };

            // Equivalente al open del application
            Open();

            // Importante: acá deberías pasar tu ventana MDI principal.
            // Asumo que uo_sepad en ue_Open abre y muestra una MDI (w_mdi)
            // y la deja como MainForm. Si no, podés exponerla desde uo_sepad.
            Application.Run();
        }

        


    }
}