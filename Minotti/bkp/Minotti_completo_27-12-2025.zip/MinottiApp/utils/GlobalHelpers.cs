﻿using Minotti.Views.Pbl.Views;

namespace Minotti.utils
{
    public static class PBGlobals
    {
        // emula: global m_mdi m_mdi
        public static m_mdi? m_mdi;
    }
}
