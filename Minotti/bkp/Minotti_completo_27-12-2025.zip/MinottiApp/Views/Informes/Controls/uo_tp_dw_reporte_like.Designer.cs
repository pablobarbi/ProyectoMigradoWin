using System.Windows.Forms;
using System.ComponentModel;
using System.Drawing;

namespace Minotti.Views.Informes.Controls
{
    partial class uo_tp_dw_reporte_like
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Designer generated code

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // uo_tp_dw_reporte_like
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Name = "uo_tp_dw_reporte_like";
            this.ResumeLayout(false);
        }

        #endregion
    }
}