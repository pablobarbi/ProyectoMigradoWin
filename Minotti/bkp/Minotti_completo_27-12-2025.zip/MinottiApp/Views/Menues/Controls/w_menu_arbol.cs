using System.Windows.Forms;

namespace Minotti.Views.Menues.Controls
{
    /// <summary>
    /// Migración de PowerBuilder: w_menu_arbol.srw
    /// Hereda de w_menu y contiene el control TreeView llamado 'tv_1'.
    /// </summary>
    public partial class w_menu_arbol : w_menu
    {
        public w_menu_arbol()
        {
            InitializeComponent();
        }
    }
}
