using Minotti.Views.Basicos.Controls;

namespace Minotti.Views.Capitulos.Controls
{
    partial class w_carga_nombres
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // w_carga_nombres
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Name = "w_carga_nombres";
            this.Text = "w_carga_nombres";
            this.ResumeLayout(false);
        }

        #endregion
    }
}
