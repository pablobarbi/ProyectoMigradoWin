using System.Windows.Forms;

namespace Minotti.Views.Pacientes.Controls
{
    partial class w_abm_diagnosticos
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();

            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            //
            // w_abm_diagnosticos
            //
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Name = "w_abm_diagnosticos";
            this.Text = "w_abm_diagnosticos";
            this.ResumeLayout(false);
        }
    }
}