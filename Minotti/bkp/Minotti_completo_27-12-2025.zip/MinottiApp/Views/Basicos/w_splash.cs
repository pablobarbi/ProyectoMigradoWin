using Minotti.Views.Basicos.Models;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Minotti.Views.Basicos
{
    public partial class w_splash : w_principal
    {
        // Equivalente a "cat_splash at_splash" en PB
        public cat_splash at_splash { get; set; }

        public w_splash()
        {
            InitializeComponent();
        }

        // PB: event open; call super::open; ...
        protected  override void OnLoad(EventArgs e)
        {
            // call super::open
            base.OnLoad(e);

            /* Centra la ventana de splash */
            // PB:
            // real Y_desviacion = 0.6
            // real X_desviacion = 1
            // this.x = int ((PixelsToUnits(env.ScreenWidth) - this.Width) / 2 * X_desviacion)
            // this.y = int ((PixelsToUnits(env.ScreenHeight) - this.Height) / 2 * Y_desviacion)

            double Y_desviacion = 0.6;
            double X_desviacion = 1.0;

            Rectangle screen = Screen.FromControl(this).WorkingArea;
            int newX = (int)((screen.Width - this.Width) / 2.0 * X_desviacion);
            int newY = (int)((screen.Height - this.Height) / 2.0 * Y_desviacion);
            this.Location = new Point(newX, newY);

            /* Recibe los parámetros necesarios */
            // at_splash = Message.PowerObjectParm
            // -> en .NET lo seteás desde afuera usando la propiedad at_splash

            /* Carga el Nombre de la Aplicación, la Versión, el Logo, el Copyright */
            if (at_splash != null)
            {
                if (!string.IsNullOrEmpty(at_splash.Nombre))
                    st_nombre.Text = at_splash.Nombre;

                if (!string.IsNullOrEmpty(at_splash.Version))
                    st_version.Text = "Versión: " + at_splash.Version;

                if (!string.IsNullOrEmpty(at_splash.Copyright))
                    st_copyright.Text = at_splash.Copyright;

                if (!string.IsNullOrWhiteSpace(at_splash.Logo))
                {
                    try
                    {
                        p_logo.ImageLocation = at_splash.Logo;
                        p_logo.SizeMode = PictureBoxSizeMode.StretchImage;
                    }
                    catch
                    {
                        // Igual que PB: si falla, no hace nada visible
                    }
                }

                /* Fija el tiempo en el que se cerrará la ventana */
                // PB: Timer(at_splash.segundos)   -> segundos
                timer1.Interval = at_splash.segundos * 1000;
            }

            timer1.Tick += timer1_Tick;
            timer1.Start();

            /* Posiciona la ventana */
            // this.SetPosition (TopMost!)
            this.TopMost = true;

            // gb_borde.SetPosition(ToBottom!)
            gb_borde.SendToBack();

            // BringToTop de los demás controles
            st_nombre.BringToFront();
            st_version.BringToFront();
            st_copyright.BringToFront();
            p_logo.BringToFront();
        }

        // PB: event timer; call super::timer; Timer(0); Close(this)
        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop(); // Timer(0)
            this.Close();
        }
    }
}