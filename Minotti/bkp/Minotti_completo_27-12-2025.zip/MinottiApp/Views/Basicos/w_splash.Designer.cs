﻿ 
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Minotti.Views.Basicos
{
    // Mismo partial de arriba
    public partial class w_splash
    {
        private GroupBox gb_borde;
        private Label st_nombre;
        private Label st_version;
        private Label st_copyright;
        private PictureBox p_logo;
        private Timer timer1;

        private void InitializeComponent()
        {
            this.gb_borde = new System.Windows.Forms.GroupBox();
            this.st_nombre = new System.Windows.Forms.Label();
            this.st_version = new System.Windows.Forms.Label();
            this.st_copyright = new System.Windows.Forms.Label();
            this.p_logo = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer();
            ((System.ComponentModel.ISupportInitialize)(this.p_logo)).BeginInit();
            this.SuspendLayout();
            // 
            // Form w_splash (propiedades de la ventana)
            // PB:
            // int X=60, Y=49, Width=2433, Height=1201, BackColor=15793151
            // Hereda de w_principal pero acá seteamos tamaño/color específico
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Location = new System.Drawing.Point(60, 49);
            this.ClientSize = new System.Drawing.Size(2433, 1201);
            this.BackColor = System.Drawing.ColorTranslator.FromWin32(15793151);
            this.Name = "w_splash";
            this.Text = "w_splash";

            // 
            // gb_borde
            // PB:
            // int X=37, Y=25, Width=2323, Height=1057
            // BorderStyle=StyleLowered!, BackColor=12632256,
            // TextSize=-10, Weight=400, FaceName="Arial"
            this.gb_borde.Location = new System.Drawing.Point(37, 25);
            this.gb_borde.Name = "gb_borde";
            this.gb_borde.Size = new System.Drawing.Size(2323, 1057);
            this.gb_borde.TabIndex = 1;
            this.gb_borde.TabStop = false;
            this.gb_borde.BackColor = System.Drawing.ColorTranslator.FromWin32(12632256);
            this.gb_borde.FlatStyle = System.Windows.Forms.FlatStyle.Standard; // Lowered ≈ borde 3D si quisieras: Fixed3D en un Panel, etc.

            // 
            // st_nombre
            // PB:
            // X=183, Y=457, Width=2030, Height=105
            // Enabled=false, BringToTop=true, Alignment=Center!,
            // BackColor=12632256, TextSize=-14, Weight=700,
            // FaceName="Arial Narrow"
            this.st_nombre.Location = new System.Drawing.Point(183, 457);
            this.st_nombre.Name = "st_nombre";
            this.st_nombre.Size = new System.Drawing.Size(2030, 105);
            this.st_nombre.Enabled = false;
            this.st_nombre.BackColor = System.Drawing.ColorTranslator.FromWin32(12632256);
            this.st_nombre.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.st_nombre.Font = new System.Drawing.Font("Arial Narrow", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));

            // 
            // st_version
            // PB:
            // X=183, Y=565, Width=2030, Height=89
            // Enabled=false, Alignment=Center!,
            // BackColor=12632256, TextSize=-12, Weight=400,
            // FaceName="Arial"
            this.st_version.Location = new System.Drawing.Point(183, 565);
            this.st_version.Name = "st_version";
            this.st_version.Size = new System.Drawing.Size(2030, 89);
            this.st_version.Enabled = false;
            this.st_version.BackColor = System.Drawing.ColorTranslator.FromWin32(12632256);
            this.st_version.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.st_version.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));

            // 
            // st_copyright
            // PB:
            // X=298, Y=993, Width=2030, Height=73
            // Enabled=false, Alignment=Right!,
            // BackColor=12632256, TextSize=-9, Weight=400,
            // FaceName="Arial"
            this.st_copyright.Location = new System.Drawing.Point(298, 993);
            this.st_copyright.Name = "st_copyright";
            this.st_copyright.Size = new System.Drawing.Size(2030, 73);
            this.st_copyright.Enabled = false;
            this.st_copyright.BackColor = System.Drawing.ColorTranslator.FromWin32(12632256);
            this.st_copyright.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.st_copyright.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));

            // 
            // p_logo
            // PB:
            // X=92, Y=109, Width=417, Height=297
            // BringToTop=true, FocusRectangle=false
            this.p_logo.Location = new System.Drawing.Point(92, 109);
            this.p_logo.Name = "p_logo";
            this.p_logo.Size = new System.Drawing.Size(417, 297);
            this.p_logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.p_logo.TabStop = false;

            // 
            // timer1
            // 
            this.timer1.Enabled = false; // se setea/activa en OnLoad según at_splash.segundos

            // 
            // Add controls
            // 
            this.Controls.Add(this.p_logo);
            this.Controls.Add(this.st_copyright);
            this.Controls.Add(this.st_version);
            this.Controls.Add(this.st_nombre);
            this.Controls.Add(this.gb_borde);

            ((System.ComponentModel.ISupportInitialize)(this.p_logo)).EndInit();
            this.ResumeLayout(false);
        }
    }
}