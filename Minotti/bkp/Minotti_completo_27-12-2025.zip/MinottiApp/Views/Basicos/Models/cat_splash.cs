﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Minotti.Views.Basicos.Models
{
    /// <summary>
    /// Equivalente PowerBuilder: cat_splash (from cat_app)
    /// </summary>
    public class cat_splash : cat_app
    {
        // integer segundos
        public int segundos { get; set; }

        public cat_splash()
        {
        }
    }
}
