﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Minotti.Views.Basicos.Models
{
    public class st_espacios
    {

        public int ancho { get; set; }

        public int largo { get; set; }

        public int borde { get; set; }
    }
}
