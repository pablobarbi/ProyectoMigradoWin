﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Minotti.Views.Basicos.Models
{
    internal class st_mensajes
    {

        public string confirmar { get; set; } = string.Empty;   
        public string borrar { get; set; } = string.Empty;
        public string cancelar { get; set; } = string.Empty;

    }
}
