using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace Minotti.Views.Basicos
{
    public partial class w_coneccion
    {
        private System.ComponentModel.IContainer components = null!;

        // Controles PB
        public GroupBox gb_base = null!;
        public GroupBox gb_aplicacion = null!;

        public TextBox sle_usuario_base = null!;
        public TextBox sle_clave_base = null!;
        public Label st_usuario_base = null!;
        public Label st_clave_base = null!;

        public Label st_usuario_aplicacion = null!;
        public Label st_clave_aplicacion = null!;
        public TextBox sle_usuario_aplicacion = null!;
        public TextBox sle_clave_aplicacion = null!;

        public PictureBox p_1 = null!;

        // Botones (PB: heredados de w_response, acá los declaro en esta ventana)
        private Button pb_continuar = null!;
        private Button pb_cancelar = null!;

        protected  override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();

            // === gb_base ===
            this.gb_base = new GroupBox();
            this.gb_base.SuspendLayout();

            this.gb_base.Name = "gb_base";
            this.gb_base.Text = "Base de Datos";
            this.gb_base.Left = 51;
            this.gb_base.Top = 805;
            this.gb_base.Width = 1057;
            this.gb_base.Height = 329;
            this.gb_base.TabIndex = 70;

            // === gb_aplicacion ===
            this.gb_aplicacion = new GroupBox();
            this.gb_aplicacion.SuspendLayout();

            this.gb_aplicacion.Name = "gb_aplicacion";
            this.gb_aplicacion.Text = "Aplicación";
            this.gb_aplicacion.Left = 1203;
            this.gb_aplicacion.Top = 805;
            this.gb_aplicacion.Width = 1057;
            this.gb_aplicacion.Height = 329;
            this.gb_aplicacion.TabIndex = 80;

            // === st_usuario_base ===
            this.st_usuario_base = new Label();
            this.st_usuario_base.Name = "st_usuario_base";
            this.st_usuario_base.Text = "Usuario:";
            this.st_usuario_base.Left = 202;
            this.st_usuario_base.Top = 905;
            this.st_usuario_base.Width = 247;
            this.st_usuario_base.Height = 77;
            this.st_usuario_base.Enabled = false;
            this.st_usuario_base.TextAlign = System.Drawing.ContentAlignment.MiddleRight;

            // === st_clave_base ===
            this.st_clave_base = new Label();
            this.st_clave_base.Name = "st_clave_base";
            this.st_clave_base.Text = "Clave:";
            this.st_clave_base.Left = 202;
            this.st_clave_base.Top = 1005;
            this.st_clave_base.Width = 247;
            this.st_clave_base.Height = 77;
            this.st_clave_base.Enabled = false;
            this.st_clave_base.TextAlign = System.Drawing.ContentAlignment.MiddleRight;

            // === sle_usuario_base ===
            this.sle_usuario_base = new TextBox();
            this.sle_usuario_base.Name = "sle_usuario_base";
            this.sle_usuario_base.Left = 467;
            this.sle_usuario_base.Top = 905;
            this.sle_usuario_base.Width = 467;
            this.sle_usuario_base.Height = 77;
            this.sle_usuario_base.TabIndex = 30;

            // === sle_clave_base ===
            this.sle_clave_base = new TextBox();
            this.sle_clave_base.Name = "sle_clave_base";
            this.sle_clave_base.Left = 467;
            this.sle_clave_base.Top = 1005;
            this.sle_clave_base.Width = 467;
            this.sle_clave_base.Height = 77;
            this.sle_clave_base.TabIndex = 40;
            this.sle_clave_base.UseSystemPasswordChar = true;

            // === st_usuario_aplicacion ===
            this.st_usuario_aplicacion = new Label();
            this.st_usuario_aplicacion.Name = "st_usuario_aplicacion";
            this.st_usuario_aplicacion.Text = "Usuario:";
            this.st_usuario_aplicacion.Left = 1354;
            this.st_usuario_aplicacion.Top = 905;
            this.st_usuario_aplicacion.Width = 247;
            this.st_usuario_aplicacion.Height = 77;
            this.st_usuario_aplicacion.Enabled = false;
            this.st_usuario_aplicacion.TextAlign = System.Drawing.ContentAlignment.MiddleRight;

            // === st_clave_aplicacion ===
            this.st_clave_aplicacion = new Label();
            this.st_clave_aplicacion.Name = "st_clave_aplicacion";
            this.st_clave_aplicacion.Text = "Clave:";
            this.st_clave_aplicacion.Left = 1354;
            this.st_clave_aplicacion.Top = 1005;
            this.st_clave_aplicacion.Width = 247;
            this.st_clave_aplicacion.Height = 77;
            this.st_clave_aplicacion.Enabled = false;
            this.st_clave_aplicacion.TextAlign = System.Drawing.ContentAlignment.MiddleRight;

            // === sle_usuario_aplicacion ===
            this.sle_usuario_aplicacion = new TextBox();
            this.sle_usuario_aplicacion.Name = "sle_usuario_aplicacion";
            this.sle_usuario_aplicacion.Left = 1619;
            this.sle_usuario_aplicacion.Top = 905;
            this.sle_usuario_aplicacion.Width = 467;
            this.sle_usuario_aplicacion.Height = 77;
            this.sle_usuario_aplicacion.TabIndex = 50;

            // === sle_clave_aplicacion ===
            this.sle_clave_aplicacion = new TextBox();
            this.sle_clave_aplicacion.Name = "sle_clave_aplicacion";
            this.sle_clave_aplicacion.Left = 1619;
            this.sle_clave_aplicacion.Top = 1005;
            this.sle_clave_aplicacion.Width = 467;
            this.sle_clave_aplicacion.Height = 77;
            this.sle_clave_aplicacion.TabIndex = 60;
            this.sle_clave_aplicacion.UseSystemPasswordChar = true;

            // === p_1 ===
            this.p_1 = new PictureBox();
            this.p_1.Name = "p_1";
            this.p_1.Left = 247;
            this.p_1.Top = 49;
            this.p_1.Width = 1847;
            this.p_1.Height = 701;
            this.p_1.SizeMode = PictureBoxSizeMode.Zoom;
            this.p_1.TabStop = false;

            // === pb_continuar ===
            this.pb_continuar = new Button();
            this.pb_continuar.Name = "pb_continuar";
            this.pb_continuar.Left = 371;
            this.pb_continuar.Top = 1173;
            this.pb_continuar.Width = 180;
            this.pb_continuar.Height = 45;
            this.pb_continuar.Text = "Continuar";
            this.pb_continuar.TabIndex = 20;
            this.pb_continuar.Click += pb_continuar_Click;

            // === pb_cancelar ===
            this.pb_cancelar = new Button();
            this.pb_cancelar.Name = "pb_cancelar";
            this.pb_cancelar.Left = 1294;
            this.pb_cancelar.Top = 1181;
            this.pb_cancelar.Width = 180;
            this.pb_cancelar.Height = 45;
            this.pb_cancelar.Text = "Cancelar";
            this.pb_cancelar.TabIndex = 10;
            this.pb_cancelar.Click += pb_cancelar_Click;

            // === Form ===
            this.SuspendLayout();
            this.Name = "w_coneccion";
            this.Text = "w_coneccion";
            this.StartPosition = FormStartPosition.Manual;

            // Controles al form
            this.Controls.Add(this.gb_base);
            this.Controls.Add(this.gb_aplicacion);

            this.Controls.Add(this.st_usuario_base);
            this.Controls.Add(this.st_clave_base);
            this.Controls.Add(this.sle_usuario_base);
            this.Controls.Add(this.sle_clave_base);

            this.Controls.Add(this.st_usuario_aplicacion);
            this.Controls.Add(this.st_clave_aplicacion);
            this.Controls.Add(this.sle_usuario_aplicacion);
            this.Controls.Add(this.sle_clave_aplicacion);

            this.Controls.Add(this.p_1);

            this.Controls.Add(this.pb_continuar);
            this.Controls.Add(this.pb_cancelar);

            // GroupBoxes NO contienen los controles en PB (están “within” la ventana),
            // pero en WinForms visualmente suelen contenerlos. Como en PB NO hay "Add",
            // los dejo al Form tal cual.

            this.gb_base.ResumeLayout(false);
            this.gb_aplicacion.ResumeLayout(false);

            this.ResumeLayout(false);
        }
    }
}
