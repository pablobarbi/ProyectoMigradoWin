namespace Minotti
{
    partial class MainForm
    {
        private void InitializeComponent()
        {
            this.Text = "Minotti - Main Form";
            this.Width = 800;
            this.Height = 600;
        }
    }
}
