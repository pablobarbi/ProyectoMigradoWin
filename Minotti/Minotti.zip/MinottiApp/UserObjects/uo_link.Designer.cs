namespace Minotti.UserObjects
{
    partial class uo_link
    {
        protected  override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // uo_link
            // 
            this.Name = "uo_link";
            this.TabStop = true;
            this.AutoSize = true;
            this.ResumeLayout(false);
        }
    }
}
