using System.Windows.Forms;

namespace Minotti
{
    /// <summary>
    /// Migración de PowerBuilder: uo_tp_dw_reporte.sru
    /// Hereda de uo_tp_dw y contiene un control DataWindow llamado 'dw_1'.
    /// </summary>
    public partial class uo_tp_dw_reporte : uo_tp_dw
    {
        public uo_tp_dw_reporte()
        {
            InitializeComponent();
        }
    }
}
