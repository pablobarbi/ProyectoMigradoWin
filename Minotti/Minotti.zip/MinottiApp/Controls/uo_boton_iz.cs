using System.Windows.Forms;

namespace Minotti.Controls
{
    // Migración de PowerBuilder: uo_boton_iz.sru (picturebutton)
    // Se mantiene el nombre del tipo: uo_boton_iz
    public partial class uo_boton_iz : Button
    {
        public uo_boton_iz()
        {
            InitializeComponent();
        }
    }
}
