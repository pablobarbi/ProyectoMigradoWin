using System.Windows.Forms;

namespace Minotti.Controls
{
    // Migración de PowerBuilder: uo_boton_der.sru (picturebutton)
    // Se mantiene el nombre del tipo: uo_boton_der
    public partial class uo_boton_der : Button
    {
        public uo_boton_der()
        {
            InitializeComponent();
        }
    }
}
