using System.Windows.Forms;
using System.ComponentModel;
using System.Drawing;

namespace Minotti.Views.Informes.Controls
{
    partial class w_buscador_general
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // w_buscador_general
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Name = "w_buscador_general";
            this.Text = "w_buscador_general";
            this.ResumeLayout(false);
        }

        #endregion
    }
}