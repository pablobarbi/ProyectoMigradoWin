﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Minotti.Views.Basicos.Models
{
    /// <summary>
    /// Equivalente PowerBuilder: cat_s_det (nonvisualobject autoinstantiate)
    /// </summary>
    public class cat_s_det
    {
        // string s_det[]
        public string[] s_det { get; set; } = Array.Empty<string>();

        public cat_s_det()
        {
        }
    }
}
