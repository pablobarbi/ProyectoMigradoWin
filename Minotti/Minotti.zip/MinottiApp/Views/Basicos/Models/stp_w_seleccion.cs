﻿ 

namespace Minotti.Views.Basicos.Models
{
    public class stp_w_seleccion
    {
        public string titulo { get; set; }
        public string objeto { get; set; }
        public string dataobject { get; set; }
        public int? cant_filas { get; set; }
        public string[] parametros { get; set; }
        public string mensaje { get; set; }
        public int? fila_default { get; set; }
    }
}


 