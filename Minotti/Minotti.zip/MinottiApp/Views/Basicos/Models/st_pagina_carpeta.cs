﻿ 

namespace Minotti.Views.Basicos.Models
{
    public class st_pagina_carpeta
    {

        public string titulo { get; set; }
        public string bitmap { get; set; }
        public string parametros { get; set; }

    }
}
