﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Minotti.Views.LegacyPB
{
    public class dwobject
    {
        public string name { get; set; } = string.Empty;
        public string type { get; set; } = string.Empty;
    }

    //public class uo_dw
    //{
    //    // Stub vacío
    //}
}
