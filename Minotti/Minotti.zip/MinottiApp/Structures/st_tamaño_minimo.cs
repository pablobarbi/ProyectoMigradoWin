﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Minotti.Structures
{
    public class st_tamaño_minimo
    {
        public int ancho { get; set; }  
        public int largo { get; set; }

    }
}
