using MinottiApp.utils;

namespace Minotti.Metadata.GeneratedSru
{
    /// <summary>
    /// PB:
    /// $PBExportComments$
    /// Contiene la un array de string. Esta es usada en el objeto cat_rw_seleccion.
    /// </summary>
    public class cat_s_det : nonvisualobject
    {
        // === VARIABLES (type variables) ===

        // PB:
        // string s_det[]
        public string[] s_det;

        // ==== CONSTRUCTOR (event constructor) ====
        public override void constructor()
        {
            // PB: sin l�gica
        }

        // ==== DESTRUCTOR (event destructor) ====
        public override void destructor()
        {
            // PB: sin l�gica
        }

        // ==== PB: on create ====
        public cat_s_det()
        {
            // PB:
            // TriggerEvent( this, "constructor" )
            constructor();
        }

        // ==== PB: on destroy ====
        public void destroy()
        {
            // PB:
            // TriggerEvent( this, "destructor" )
            destructor();
        }
    }
}
