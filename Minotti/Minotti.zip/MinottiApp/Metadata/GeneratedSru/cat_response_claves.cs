using MinottiApp.utils;

namespace Minotti.Metadata.GeneratedSru
{
    public class cat_response_claves : cat_response
    {
        // === VARIABLES (type variables) ===
        public string[] claves;

        // ==== CONSTRUCTOR (event constructor) ====
        public override void constructor()
        {
            // PB: sin l�gica
        }

        // ==== DESTRUCTOR (event destructor) ====
        public override void destructor()
        {
            // PB: sin l�gica
        }

        // ==== PB: on create ====
        public cat_response_claves()
        {
            // PB:
            // TriggerEvent( this, "constructor" )
            constructor();
        }

        // ==== PB: on destroy ====
        public void destroy()
        {
            // PB:
            // TriggerEvent( this, "destructor" )
            destructor();
        }
    }
}
