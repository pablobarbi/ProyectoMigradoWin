using MinottiApp.utils;

namespace Minotti.Metadata.GeneratedSru
{
    // PB: $PBExportComments$ Clase con los atributos de una aplicaci�n.
    public class cat_app : nonvisualobject
    {
        // === VARIABLES (type variables) ===
        // PB: Public:
        public string Nombre;
        public string Version;
        public string Logo;
        public string Copyright;

        // ==== CONSTRUCTOR (event constructor) ====
        public override void constructor()
        {
            // PB: TriggerEvent( this, "constructor" )
            // No hay l�gica en el constructor en PB
        }

        // ==== DESTRUCTOR (event destructor) ====
        public override void destructor()
        {
            // PB: vac�o
        }
    }
}
