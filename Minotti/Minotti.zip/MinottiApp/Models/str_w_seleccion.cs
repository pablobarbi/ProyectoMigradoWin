using System;

namespace Minotti.Models
{
    // Migración de PowerBuilder: str_w_seleccion.srs (structure)
    // Se mantienen los nombres de los campos tal cual.
    public class str_w_seleccion
    {
        public int opcion { get; set; } = 0;
        public string s_det { get; set; } = string.Empty;
    }
}
