using Minotti.utils;
using Minotti.Views.Pbl.Views;
using System;
using System.Windows.Forms;

namespace Minotti.Views.Basicos
{
    public partial class w_mdi : Form
    {
        public m_mdi MenuPB { get; private set; }
        // ===============================
        // PB compatibility
        // ===============================

        public int WorkSpaceWidth
        {
            get
            {
                return this.ClientSize.Width;
            }
        }

        public int WorkSpaceHeight
        {
            get
            {
                return this.ClientSize.Height;
            }
        }






        public w_mdi()
        {
            InitializeComponent();

            // PB-like globals: si tenés PBGlobals, setealo acá.
            // Si no existe, comentá estas 2 líneas.
            PBGlobals.w_mdi = this;
            MenuPB = new m_mdi(this);
            PBGlobals.m_mdi = MenuPB;

            WireMenuEvents();
        }

        // ===============================
        // PB: wf_GetAreaTrabajo
        // ===============================

        // Variante simple
        public Control wf_GetAreaTrabajo()
        {

            return this;
        }

        // Variante con parámetros (PB legacy)
        public Control wf_GetAreaTrabajo(out int width, out int height)
        {
            width = WorkSpaceWidth;
            height = WorkSpaceHeight;
            return this;
        }


        private void WireMenuEvents()
        {
            if (m_salir != null)
                m_salir.Click += (_, _) => Close();

            if (m_layer != null)
                m_layer.Click += (_, _) => LayoutMdi(MdiLayout.TileVertical);

            if (m_mosaico != null)
                m_mosaico.Click += (_, _) => LayoutMdi(MdiLayout.TileHorizontal);

            if (m_casacada != null)
                m_casacada.Click += (_, _) => LayoutMdi(MdiLayout.Cascade);

            if (m_acercade != null)
                m_acercade.Click += (_, _) =>
                {
                    // PB: uof_mostrar_datos_sistema()
                    try
                    {
                        Globales.guo_app?.uof_mostrar_datos_sistema();
                    }
                    catch
                    {
                        // stub silencioso PB-like
                    }
                };
        }
    } 
 
}
